import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Valida que quem chama está autenticado como planejador ou manager
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Não autorizado' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Cliente admin (service_role) — variável de ambiente injetada pelo Supabase
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // Cliente para verificar quem está chamando (usa o JWT do usuário logado)
    const supabaseUser = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user: caller } } = await supabaseUser.auth.getUser();
    if (!caller) {
      return new Response(JSON.stringify({ error: 'Sessão inválida' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Verifica se quem chama é planejador ou manager
    const { data: perfil } = await supabaseAdmin
      .from('planejadores')
      .select('role')
      .eq('id', caller.id)
      .single();

    if (!perfil || !['planejador', 'manager'].includes(perfil.role)) {
      return new Response(JSON.stringify({ error: 'Sem permissão' }), {
        status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = await req.json();
    const { action } = body;

    // ── CRIAR ACESSO ──────────────────────────────────────────────────────────
    if (action === 'criar') {
      const { email, senha, nome, clienteId } = body;

      if (!email || !senha || !nome || !clienteId) {
        return new Response(JSON.stringify({ error: 'Campos obrigatórios ausentes' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Cria usuário via Admin API (GoTrue — hash correto)
      const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
        email,
        password: senha,
        email_confirm: true,
        user_metadata: { nome, role: 'cliente' },
      });

      if (createError) {
        return new Response(JSON.stringify({ error: createError.message }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Insere em cliente_acessos
      const { error: acessoError } = await supabaseAdmin
        .from('cliente_acessos')
        .insert({ cliente_id: clienteId, user_id: newUser.user.id, nome });

      if (acessoError) {
        // Rollback: remove o usuário criado
        await supabaseAdmin.auth.admin.deleteUser(newUser.user.id);
        return new Response(JSON.stringify({ error: acessoError.message }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({
        user_id: newUser.user.id, email, nome,
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // ── RESETAR SENHA ─────────────────────────────────────────────────────────
    if (action === 'resetar_senha') {
      const { userId, novaSenha } = body;

      const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        password: novaSenha,
      });

      if (error) {
        return new Response(JSON.stringify({ error: error.message }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // ── EXCLUIR ACESSO ────────────────────────────────────────────────────────
    if (action === 'excluir') {
      const { userId } = body;

      // Remove de cliente_acessos primeiro
      await supabaseAdmin.from('cliente_acessos').delete().eq('user_id', userId);

      // Remove do Auth
      const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);
      if (error) {
        return new Response(JSON.stringify({ error: error.message }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Ação desconhecida' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
