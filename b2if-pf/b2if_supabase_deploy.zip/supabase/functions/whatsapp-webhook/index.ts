/**
 * whatsapp-webhook
 * Supabase Edge Function — recebe eventos da Meta Cloud API
 *
 * GET  /functions/v1/whatsapp-webhook  → verificação do webhook Meta
 * POST /functions/v1/whatsapp-webhook  → mensagens recebidas
 *
 * Variáveis de ambiente (Supabase → Project Settings → Edge Functions → Secrets):
 *   META_VERIFY_TOKEN     — token de verificação (b2if_verify_2025)
 *   META_ACCESS_TOKEN     — token de acesso gerado na Meta
 *   META_PHONE_NUMBER_ID  — 111838774685525
 *   GEMINI_API_KEY        — chave gratuita em aistudio.google.com
 *   SUPABASE_URL          — preenchido automaticamente pelo Supabase
 *   SUPABASE_SERVICE_ROLE_KEY — preenchido automaticamente pelo Supabase
 */

import { serve }        from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

// ─── Configuração ──────────────────────────────────────────────────────────────
const META_VERIFY_TOKEN    = Deno.env.get('META_VERIFY_TOKEN')        ?? 'b2if_verify_2025';
const META_ACCESS_TOKEN    = Deno.env.get('META_ACCESS_TOKEN')        ?? '';
const META_PHONE_NUMBER_ID = Deno.env.get('META_PHONE_NUMBER_ID')     ?? '111838774685525';
const META_API_VERSION     = 'v20.0';
const GEMINI_API_KEY       = Deno.env.get('GEMINI_API_KEY')           ?? '';
const SUPABASE_URL         = Deno.env.get('SUPABASE_URL')             ?? '';
const SUPABASE_SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';

// Modelo Gemini — flash é grátis e rápido, pro é mais preciso
const GEMINI_MODEL         = 'gemini-2.0-flash';
const GEMINI_BASE          = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}`;

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// ─── Servidor principal ────────────────────────────────────────────────────────
serve(async (req: Request) => {

  // ── GET: verificação de webhook pela Meta ──────────────────────────────────
  if (req.method === 'GET') {
    const url       = new URL(req.url);
    const mode      = url.searchParams.get('hub.mode');
    const token     = url.searchParams.get('hub.verify_token');
    const challenge = url.searchParams.get('hub.challenge');

    if (mode === 'subscribe' && token === META_VERIFY_TOKEN) {
      console.log('[webhook] Verificação Meta OK ✔');
      return new Response(challenge, { status: 200 });
    }
    return new Response(JSON.stringify({ status: 'ok' }), {
      status: 200, headers: { 'Content-Type': 'application/json' },
    });
  }

  // ── POST: mensagens recebidas ──────────────────────────────────────────────
  if (req.method === 'POST') {
    // Lê o body antes de responder (Deno exige isso)
    let body: any;
    try { body = await req.json(); } catch { body = {}; }

    // Responde 200 imediatamente para evitar retry da Meta (prazo: 20s)
    const response = new Response(JSON.stringify({ received: true }), {
      status: 200, headers: { 'Content-Type': 'application/json' },
    });

    // Processa em background (não bloqueia a resposta)
    handleMeta(body).catch(err => console.error('[webhook] Erro geral:', err.message));

    return response;
  }

  return new Response('Method Not Allowed', { status: 405 });
});

// ═══════════════════════════════════════════════════════════════════════════════
// HANDLER PRINCIPAL — Meta Cloud API
// ═══════════════════════════════════════════════════════════════════════════════
async function handleMeta(body: any) {
  if (body.object !== 'whatsapp_business_account') return;

  for (const entry of body.entry ?? []) {
    for (const change of entry.changes ?? []) {
      if (change.field !== 'messages') continue;

      const messages = change.value?.messages ?? [];

      for (const msg of messages) {
        if (msg.from === META_PHONE_NUMBER_ID) continue; // ignora mensagens do próprio bot

        const telefone = normalizarTelefone(msg.from);
        if (!telefone) continue;

        // Busca a sessão (vínculo telefone → cliente → assessor)
        const sessao = await buscarSessao(telefone);

        if (!sessao) {
          console.log(`[webhook] Número sem sessão: ${telefone}`);
          await enviarMensagem(telefone,
            '👋 Seu número ainda não está vinculado ao B2IF.\n' +
            'Solicite ao seu assessor financeiro que faça a vinculação.'
          );
          await salvarMensagem(null, telefone, msg);
          continue;
        }

        await salvarMensagem(sessao.id, telefone, msg);
        await processarMensagem(sessao, telefone, msg);
      }
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// PROCESSAMENTO POR TIPO DE MENSAGEM
// ═══════════════════════════════════════════════════════════════════════════════
async function processarMensagem(sessao: any, telefone: string, msg: any) {
  const clienteId = sessao.cliente_id;

  try {
    switch (msg.type) {

      // ── Texto ────────────────────────────────────────────────────────────────
      case 'text': {
        const texto = msg.text?.body ?? '';
        const cmd   = texto.trim().toLowerCase();

        if (cmd === 'resumo' || cmd === 'extrato') {
          return await enviarResumoSemanal(telefone, clienteId);
        }
        if (cmd === 'ajuda' || cmd === 'menu') {
          return await enviarAjuda(telefone);
        }

        const transacao = await geminiParsearTexto(texto);
        if (transacao) {
          const salva = await salvarTransacao(clienteId, telefone, transacao);
          if (salva) {
            await confirmarTransacao(telefone, transacao);
          } else {
            await enviarMensagem(telefone, 'ℹ️ Essa transação já foi registrada recentemente. Nada duplicado foi salvo.');
          }
        } else {
          await enviarMensagem(telefone,
            '⚠️ Não consegui identificar uma transação.\n\n' +
            'Exemplos que funcionam:\n' +
            '  • "Almoço 45"\n' +
            '  • "Mercado R$ 128,50"\n' +
            '  • "Salário 3200"\n\n' +
            'Digite _ajuda_ para ver todas as opções.'
          );
        }
        break;
      }

      // ── Imagem (comprovante/nota fiscal) ────────────────────────────────────
      case 'image': {
        const mediaId  = msg.image?.id;
        const legenda  = msg.image?.caption ?? '';
        if (!mediaId) break;

        await enviarMensagem(telefone, '🔍 Analisando comprovante...');

        const transacao = await geminiParsearImagem(mediaId, legenda);
        if (transacao) {
          const salva = await salvarTransacao(clienteId, telefone, transacao);
          if (salva) {
            await confirmarTransacao(telefone, transacao);
          } else {
            await enviarMensagem(telefone, 'ℹ️ Parece que essa transação já foi registrada. Nada duplicado foi salvo.');
          }
        } else {
          await enviarMensagem(telefone,
            '⚠️ Não consegui extrair os dados do comprovante.\n' +
            'Tente enviar em texto: "Mercado 128,50"'
          );
        }
        break;
      }

      // ── Áudio (voz) ─────────────────────────────────────────────────────────
      case 'audio': {
        const mediaId = msg.audio?.id;
        if (!mediaId) break;

        await enviarMensagem(telefone, '🎙️ Transcrevendo áudio...');

        const transcricao = await geminiTranscreverAudio(mediaId);
        if (transcricao) {
          const transacao = await geminiParsearTexto(transcricao);
          if (transacao) {
            const salva = await salvarTransacao(clienteId, telefone, transacao);
            if (salva) {
              await confirmarTransacao(telefone, { ...transacao, descricao: `🎙️ ${transacao.descricao}` });
            } else {
              await enviarMensagem(telefone, 'ℹ️ Essa transação já foi registrada recentemente.');
            }
          } else {
            await enviarMensagem(telefone,
              `📝 Ouvi: _"${transcricao}"_\n\n` +
              '⚠️ Não identifiquei uma transação. Tente ser mais direto:\n' +
              '  Ex: "Gastei quarenta e cinco reais no almoço"'
            );
          }
        } else {
          await enviarMensagem(telefone, '⚠️ Não consegui entender o áudio. Tente enviar em texto.');
        }
        break;
      }

      // ── Documento (PDF de extrato) ───────────────────────────────────────────
      case 'document': {
        const mime = msg.document?.mime_type ?? '';
        if (!mime.includes('pdf')) {
          await enviarMensagem(telefone, '📄 Só aceito PDFs de extratos bancários por aqui.\nPara outros arquivos, use o sistema B2IF no computador.');
          break;
        }
        await enviarMensagem(telefone,
          '📄 Para extratos PDF, use o sistema B2IF no computador:\n' +
          '🖥️ planfinb2pessoal.netlify.app\n\n' +
          'Vá em *Fluxo Financeiro → Importar PDF*.\nO resultado aparece aqui também! ✅'
        );
        break;
      }

      default:
        console.log(`[webhook] Tipo não tratado: ${msg.type}`);
    }
  } catch (err: any) {
    console.error('[processarMensagem] Erro:', err.message);
    await enviarMensagem(telefone, '⚠️ Ocorreu um erro interno. Tente novamente em alguns instantes.');
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// GEMINI — Parsing de texto
// ═══════════════════════════════════════════════════════════════════════════════
async function geminiParsearTexto(texto: string): Promise<any | null> {
  const hoje = new Date().toISOString().substring(0, 10);

  const prompt = `Você é um assistente financeiro brasileiro. Analise a mensagem abaixo e extraia os dados de uma transação financeira.

Mensagem: "${texto}"
Data de hoje: ${hoje}

Responda SOMENTE com um JSON válido neste formato exato (sem markdown, sem explicação):
{"descricao":"nome curto","valor":-45.00,"data":"${hoje}","categoria":"alimentacao","conta":"dinheiro"}

Regras:
- valor NEGATIVO para despesa/saída, POSITIVO para receita/entrada
- data: use a data mencionada ou a de hoje (${hoje})
- conta: "dinheiro" | "pix" | "cartao_credito" | "cartao_debito"
- categoria sugerida: alimentacao | transporte | moradia | saude | lazer | educacao | salario | outros
- Se NÃO for uma transação financeira clara, responda exatamente: null`;

  return await chamarGeminiTexto(prompt);
}

// ═══════════════════════════════════════════════════════════════════════════════
// GEMINI — Parsing de imagem (comprovante)
// ═══════════════════════════════════════════════════════════════════════════════
async function geminiParsearImagem(mediaId: string, legenda: string): Promise<any | null> {
  try {
    // 1. Resolver URL da mídia na Meta
    const mediaUrl = await resolverMediaUrl(mediaId);
    if (!mediaUrl) return null;

    // 2. Baixar a imagem
    const imgRes = await fetch(mediaUrl, {
      headers: { Authorization: `Bearer ${META_ACCESS_TOKEN}` },
    });
    if (!imgRes.ok) return null;

    const imgBuf = await imgRes.arrayBuffer();
    const base64 = btoa(String.fromCharCode(...new Uint8Array(imgBuf)));
    const mime   = imgRes.headers.get('content-type') ?? 'image/jpeg';
    const hoje   = new Date().toISOString().substring(0, 10);

    const promptTexto = legenda
      ? `Comprovante com legenda: "${legenda}". Extraia os dados da transação.`
      : 'Extraia os dados da transação financeira deste comprovante ou nota fiscal.';

    // 3. Enviar para Gemini Vision (multimodal)
    const body = {
      contents: [{
        parts: [
          {
            text: `${promptTexto}\n\nData de hoje: ${hoje}\n\nResponda SOMENTE com JSON (sem markdown):\n{"descricao":"nome curto","valor":-45.00,"data":"${hoje}","categoria":"alimentacao","conta":"pix"}\n\nSe não conseguir identificar, responda: null`
          },
          {
            inline_data: { mime_type: mime, data: base64 }
          }
        ]
      }],
      generationConfig: { temperature: 0, maxOutputTokens: 200 },
    };

    const res = await fetch(
      `${GEMINI_BASE}:generateContent?key=${GEMINI_API_KEY}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    );

    return await extrairJsonGemini(res);
  } catch (err: any) {
    console.error('[geminiParsearImagem]', err.message);
    return null;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// GEMINI — Transcrição de áudio
// ═══════════════════════════════════════════════════════════════════════════════
async function geminiTranscreverAudio(mediaId: string): Promise<string | null> {
  try {
    const mediaUrl = await resolverMediaUrl(mediaId);
    if (!mediaUrl) return null;

    const audioRes = await fetch(mediaUrl, {
      headers: { Authorization: `Bearer ${META_ACCESS_TOKEN}` },
    });
    if (!audioRes.ok) return null;

    const audioBuf = await audioRes.arrayBuffer();
    const base64   = btoa(String.fromCharCode(...new Uint8Array(audioBuf)));

    // Gemini Flash suporta áudio nativo
    const body = {
      contents: [{
        parts: [
          { text: 'Transcreva este áudio em português do Brasil. Retorne APENAS o texto transcrito, sem pontuação extra.' },
          { inline_data: { mime_type: 'audio/ogg', data: base64 } }
        ]
      }],
      generationConfig: { temperature: 0, maxOutputTokens: 300 },
    };

    const res = await fetch(
      `${GEMINI_BASE}:generateContent?key=${GEMINI_API_KEY}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    );

    const data    = await res.json();
    const content = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() ?? '';
    return content || null;
  } catch (err: any) {
    console.error('[geminiTranscreverAudio]', err.message);
    return null;
  }
}

// ─── Helpers Gemini ────────────────────────────────────────────────────────────

async function chamarGeminiTexto(prompt: string): Promise<any | null> {
  try {
    const body = {
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0, maxOutputTokens: 200 },
    };

    const res = await fetch(
      `${GEMINI_BASE}:generateContent?key=${GEMINI_API_KEY}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    );

    return await extrairJsonGemini(res);
  } catch (err: any) {
    console.error('[chamarGeminiTexto]', err.message);
    return null;
  }
}

async function extrairJsonGemini(res: Response): Promise<any | null> {
  try {
    const data    = await res.json();
    const content = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() ?? '';

    if (!content || content === 'null') return null;

    // Remove markdown code block se vier com ```json ... ```
    const limpo = content
      .replace(/```json\n?/g, '')
      .replace(/```\n?/g, '')
      .trim();

    return JSON.parse(limpo);
  } catch {
    return null;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// META — Envio de mensagens
// ═══════════════════════════════════════════════════════════════════════════════
async function enviarMensagem(telefone: string, texto: string) {
  if (!telefone || !META_ACCESS_TOKEN) return;

  try {
    const res = await fetch(
      `https://graph.facebook.com/${META_API_VERSION}/${META_PHONE_NUMBER_ID}/messages`,
      {
        method: 'POST',
        headers: {
          'Content-Type':  'application/json',
          'Authorization': `Bearer ${META_ACCESS_TOKEN}`,
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          recipient_type:    'individual',
          to:                telefone,
          type:              'text',
          text:              { preview_url: false, body: texto },
        }),
      }
    );
    if (!res.ok) {
      const err = await res.text();
      console.error(`[enviarMensagem] HTTP ${res.status}:`, err);
    }
  } catch (err: any) {
    console.error('[enviarMensagem]', err.message);
  }
}

async function resolverMediaUrl(mediaId: string): Promise<string | null> {
  try {
    const res  = await fetch(
      `https://graph.facebook.com/${META_API_VERSION}/${mediaId}`,
      { headers: { Authorization: `Bearer ${META_ACCESS_TOKEN}` } }
    );
    const data = await res.json();
    return data.url ?? null;
  } catch (err: any) {
    console.error('[resolverMediaUrl]', err.message);
    return null;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SUPABASE — Sessões, Mensagens e Transações
// ═══════════════════════════════════════════════════════════════════════════════
async function buscarSessao(telefone: string): Promise<any | null> {
  const { data, error } = await supabase
    .from('bot_sessions')
    .select('id, cliente_id, assessor_id')
    .eq('telefone', telefone)
    .eq('ativo', true)
    .maybeSingle();

  if (error) console.error('[buscarSessao]', error.message);
  return data ?? null;
}

async function salvarMensagem(sessionId: string | null, telefone: string, msg: any) {
  const tipo     = msg.type ?? 'text';
  const conteudo = tipo === 'text' ? (msg.text?.body ?? '') : `[${tipo}]`;

  const { error } = await supabase.from('bot_messages').insert({
    session_id: sessionId,
    de:         telefone,
    tipo,
    conteudo,
    meta:       msg,
    lida:       false,
  });

  if (error) console.error('[salvarMensagem]', error.message);
}

async function salvarTransacao(clienteId: string, telefone: string, t: any): Promise<boolean> {
  // Deduplicação: mesma descrição + valor + data nas últimas 6 horas
  const seisHorasAtras = new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString();
  const { data: existente } = await supabase
    .from('transacoes')
    .select('id')
    .eq('cliente_id', clienteId)
    .eq('descricao', t.descricao)
    .eq('valor', t.valor)
    .gte('created_at', seisHorasAtras)
    .maybeSingle();

  if (existente) {
    console.log(`[salvarTransacao] Duplicata ignorada: ${t.descricao} ${t.valor}`);
    return false;
  }

  // Mapear conta para formato
  const formatoMap: Record<string, string> = {
    pix:           'Pix',
    cartao_credito: 'Crédito',
    cartao_debito:  'Débito',
    dinheiro:       'Dinheiro',
  };

  const { error } = await supabase.from('transacoes').insert({
    cliente_id: clienteId,
    descricao:  t.descricao,
    valor:      t.valor,
    data:       t.data ?? new Date().toISOString().substring(0, 10),
    categoria:  t.categoria ?? null,
    conta:      t.conta ?? 'dinheiro',
    formato:    formatoMap[t.conta] ?? 'Dinheiro',
    origem:     'whatsapp',
    status:     'pendente',
    fonte:      `whatsapp:${telefone}`,
  });

  if (error) {
    console.error('[salvarTransacao]', error.message);
    return false;
  }
  return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
// HELPERS — Mensagens e formatação
// ═══════════════════════════════════════════════════════════════════════════════
function normalizarTelefone(raw: string): string {
  if (!raw) return '';
  const n = raw.replace(/\D/g, '');
  if (n.length >= 10 && n.length <= 11 && !n.startsWith('55')) return `55${n}`;
  return n;
}

async function confirmarTransacao(telefone: string, t: any) {
  const sinal = t.valor < 0 ? '📤' : '📥';
  const tipo  = t.valor < 0 ? 'Saída' : 'Entrada';
  const valor = `R$ ${Math.abs(t.valor).toFixed(2).replace('.', ',')}`;
  const data  = t.data
    ? new Date(t.data + 'T12:00:00').toLocaleDateString('pt-BR')
    : new Date().toLocaleDateString('pt-BR');

  const msg = [
    `${sinal} *${tipo} registrada!*`,
    `📝 ${t.descricao}`,
    `💰 ${valor}`,
    `📅 ${data}`,
    t.categoria ? `🏷️ ${t.categoria}` : null,
    ``,
    `_Já aparece no sistema B2IF ✅_`,
  ].filter(Boolean).join('\n');

  return enviarMensagem(telefone, msg);
}

async function enviarAjuda(telefone: string) {
  const msg = [
    '📲 *B2IF Mobile – Como usar:*',
    '',
    '✏️ *Texto:* "Almoço 45" ou "Salário 3200"',
    '📸 *Foto:* Mande foto do comprovante ou nota',
    '🎙️ *Áudio:* Descreva o gasto por voz',
    '',
    '📊 *Comandos:*',
    '  • _resumo_ → gastos da semana',
    '  • _ajuda_ → este menu',
    '',
    '💡 Os lançamentos aparecem no B2IF em instantes!',
  ].join('\n');

  return enviarMensagem(telefone, msg);
}

async function enviarResumoSemanal(telefone: string, clienteId: string) {
  const seteDiasAtras = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    .toISOString().substring(0, 10);

  const { data } = await supabase
    .from('transacoes')
    .select('valor, descricao, data')
    .eq('cliente_id', clienteId)
    .gte('data', seteDiasAtras)
    .lt('valor', 0)
    .order('data', { ascending: false });

  if (!data || data.length === 0) {
    return enviarMensagem(telefone, '📊 Nenhuma despesa registrada nos últimos 7 dias.');
  }

  const total  = data.reduce((s: number, t: any) => s + Math.abs(t.valor), 0);
  const linhas = (data as any[])
    .slice(0, 8)
    .map((t: any) => `• ${t.descricao}: *R$ ${Math.abs(t.valor).toFixed(2).replace('.', ',')}*`);

  return enviarMensagem(telefone, [
    '📊 *Resumo dos últimos 7 dias:*',
    '',
    ...linhas,
    data.length > 8 ? `... e mais ${data.length - 8} transações` : '',
    '',
    `💰 *Total: R$ ${total.toFixed(2).replace('.', ',')}*`,
  ].filter(l => l !== '').join('\n'));
}
