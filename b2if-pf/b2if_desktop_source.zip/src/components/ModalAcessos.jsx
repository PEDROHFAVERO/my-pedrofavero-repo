/**
 * ModalAcessos — gerencia logins de cliente
 * Usado em: PageHub (planejador) e PageManagerHub (manager → modal clientes)
 *
 * Props:
 *   open       boolean
 *   clienteId  string
 *   clienteNome string
 *   onClose    () => void
 */
import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { C, FONT, RADIUS } from '../design/tokens.js';

export default function ModalAcessos({ open, clienteId, clienteNome, onClose }) {
  const { listarAcessosCliente, criarAcessoCliente, resetarSenhaCliente, excluirAcessoCliente } = useAuth();

  const [acessos, setAcessos]         = useState([]);
  const [carregando, setCarregando]   = useState(false);
  const [erro, setErro]               = useState('');

  // Sub-formulário: novo acesso
  const [showForm, setShowForm]       = useState(false);
  const [fNome, setFNome]             = useState('');
  const [fEmail, setFEmail]           = useState('');
  const [fSenha, setFSenha]           = useState('');
  const [fLoad, setFLoad]             = useState(false);
  const [fErro, setFErro]             = useState('');

  // Sub-modal: resetar senha
  const [modalReset, setModalReset]   = useState(null); // { userId, nome }
  const [novaSenha, setNovaSenha]     = useState('');
  const [resetLoad, setResetLoad]     = useState(false);
  const [resetErro, setResetErro]     = useState('');

  // Sub-modal: confirmar exclusão
  const [modalExcluir, setModalExcluir] = useState(null); // { userId, nome }
  const [excluirLoad, setExcluirLoad]   = useState(false);

  // Carrega acessos quando abre
  useEffect(() => {
    if (!open || !clienteId) return;
    carregar();
  }, [open, clienteId]);

  async function carregar() {
    setCarregando(true);
    setErro('');
    try {
      const lista = await listarAcessosCliente(clienteId);
      setAcessos(lista);
    } catch (e) {
      setErro(e.message);
    } finally {
      setCarregando(false);
    }
  }

  function resetForm() {
    setFNome(''); setFEmail(''); setFSenha(''); setFErro(''); setShowForm(false);
  }

  async function handleCriar(e) {
    e.preventDefault();
    setFErro('');
    if (!fNome.trim())  { setFErro('Informe o nome.'); return; }
    if (!fEmail.trim()) { setFErro('Informe o e-mail.'); return; }
    if (fSenha.length < 6) { setFErro('Senha deve ter ao menos 6 caracteres.'); return; }
    setFLoad(true);
    try {
      await criarAcessoCliente({ clienteId, nome: fNome.trim(), email: fEmail.trim().toLowerCase(), senha: fSenha });
      resetForm();
      await carregar();
    } catch (e) {
      setFErro(e.message);
    } finally {
      setFLoad(false);
    }
  }

  async function handleResetar() {
    if (!novaSenha || novaSenha.length < 6) { setResetErro('Senha deve ter ao menos 6 caracteres.'); return; }
    setResetErro('');
    setResetLoad(true);
    try {
      await resetarSenhaCliente(modalReset.userId, novaSenha);
      setModalReset(null);
      setNovaSenha('');
    } catch (e) {
      setResetErro(e.message);
    } finally {
      setResetLoad(false);
    }
  }

  async function handleExcluir() {
    setExcluirLoad(true);
    try {
      await excluirAcessoCliente(modalExcluir.userId);
      setModalExcluir(null);
      await carregar();
    } catch (e) {
      setErro(e.message);
    } finally {
      setExcluirLoad(false);
    }
  }

  if (!open) return null;

  const inputSt = {
    width: '100%', boxSizing: 'border-box',
    background: C.bg, border: `1px solid ${C.border}`,
    borderRadius: RADIUS.md, padding: '9px 12px',
    color: C.text, fontSize: FONT.sm,
    fontFamily: "'Inter',sans-serif", outline: 'none',
  };
  const labelSt = {
    fontSize: FONT.xs, color: C.textMuted,
    fontWeight: 600, display: 'block', marginBottom: 5,
  };

  return (
    <>
      {/* Overlay principal */}
      <div
        style={{
          position: 'fixed', inset: 0, zIndex: 1000,
          background: 'rgba(0,0,0,0.65)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: 24,
        }}
        onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      >
        <div style={{
          background: C.card, border: `1px solid ${C.border}`,
          borderRadius: RADIUS.lg, padding: '28px 28px',
          width: '100%', maxWidth: 480,
          maxHeight: '90vh', display: 'flex', flexDirection: 'column',
        }}>
          {/* Cabeçalho */}
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
            <div>
              <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text }}>👤 Acessos do Cliente</div>
              <div style={{ fontSize: FONT.xs, color: C.textMuted, marginTop: 3 }}>
                Cliente: <strong style={{ color: C.brand }}>{clienteNome}</strong>
              </div>
            </div>
            <button onClick={onClose} style={{ background: 'none', border: 'none', color: C.textMuted, cursor: 'pointer', fontSize: 18 }}>×</button>
          </div>

          {/* Erro global */}
          {erro && (
            <div style={{ fontSize: FONT.xs, color: C.desp, background: C.desp + '15', padding: '8px 12px', borderRadius: RADIUS.sm, marginBottom: 14 }}>
              {erro}
            </div>
          )}

          {/* Lista de acessos */}
          <div style={{ flex: 1, overflowY: 'auto', marginBottom: 16 }}>
            {carregando ? (
              <div style={{ textAlign: 'center', color: C.textMuted, fontSize: FONT.sm, padding: 24 }}>Carregando...</div>
            ) : acessos.length === 0 ? (
              <div style={{
                border: `1px dashed ${C.border}`, borderRadius: RADIUS.md,
                padding: '24px', textAlign: 'center', color: C.textMuted, fontSize: FONT.sm,
              }}>
                <div style={{ fontSize: 28, marginBottom: 8 }}>🔐</div>
                Nenhum acesso criado ainda.<br />
                <span style={{ fontSize: FONT.xs }}>Clique em "+ Novo acesso" para criar o primeiro login.</span>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {acessos.map(a => (
                  <div key={a.id} style={{
                    background: C.bg, border: `1px solid ${C.border}`,
                    borderRadius: RADIUS.md, padding: '12px 16px',
                    display: 'flex', alignItems: 'center', gap: 12,
                  }}>
                    {/* Avatar */}
                    <div style={{
                      width: 36, height: 36, borderRadius: '50%',
                      background: C.brand + '22', color: C.brand,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontWeight: 700, fontSize: FONT.sm, flexShrink: 0,
                    }}>
                      {a.nome.charAt(0).toUpperCase()}
                    </div>
                    {/* Info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 600, fontSize: FONT.sm, color: C.text }}>{a.nome}</div>
                      <div style={{ fontSize: FONT.xs, color: C.textMuted, marginTop: 1 }}>
                        Criado em {new Date(a.criado_em).toLocaleDateString('pt-BR')}
                      </div>
                    </div>
                    {/* Ações */}
                    <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                      <SmBtn onClick={() => { setModalReset({ userId: a.user_id, nome: a.nome }); setNovaSenha(''); setResetErro(''); }}>
                        🔑 Resetar senha
                      </SmBtn>
                      <SmBtn danger onClick={() => setModalExcluir({ userId: a.user_id, nome: a.nome })}>
                        🗑
                      </SmBtn>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Formulário novo acesso */}
          {showForm ? (
            <form onSubmit={handleCriar} style={{ borderTop: `1px solid ${C.border}`, paddingTop: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ fontSize: FONT.sm, fontWeight: 700, color: C.text, marginBottom: 4 }}>Novo acesso</div>
              <div>
                <label style={labelSt}>NOME</label>
                <input value={fNome} onChange={e => setFNome(e.target.value)} placeholder="Ex: Andrea" style={inputSt} />
              </div>
              <div>
                <label style={labelSt}>E-MAIL</label>
                <input type="email" value={fEmail} onChange={e => setFEmail(e.target.value)} placeholder="andrea@email.com" style={inputSt} />
              </div>
              <div>
                <label style={labelSt}>SENHA INICIAL</label>
                <input type="password" value={fSenha} onChange={e => setFSenha(e.target.value)} placeholder="Mínimo 6 caracteres" style={inputSt} />
              </div>
              {fErro && <div style={{ fontSize: FONT.xs, color: C.desp }}>{fErro}</div>}
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                <GhBtn onClick={resetForm}>Cancelar</GhBtn>
                <PrBtn type="submit" disabled={fLoad}>{fLoad ? 'Criando...' : 'Criar acesso'}</PrBtn>
              </div>
            </form>
          ) : (
            <button
              onClick={() => setShowForm(true)}
              style={{
                width: '100%', padding: '10px', borderRadius: RADIUS.md,
                border: `1px dashed ${C.brand}66`, background: C.brand + '0d',
                color: C.brand, fontSize: FONT.sm, fontWeight: 600,
                fontFamily: "'Inter',sans-serif", cursor: 'pointer',
              }}
            >+ Novo acesso</button>
          )}
        </div>
      </div>

      {/* Sub-modal: Resetar senha */}
      {modalReset && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1100, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}
          onClick={e => { if (e.target === e.currentTarget) setModalReset(null); }}>
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.lg, padding: '28px', width: '100%', maxWidth: 380 }}>
            <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text, marginBottom: 4 }}>🔑 Resetar Senha</div>
            <div style={{ fontSize: FONT.xs, color: C.textMuted, marginBottom: 16 }}>
              Definir nova senha para <strong style={{ color: C.text }}>{modalReset.nome}</strong>
            </div>
            <label style={labelSt}>NOVA SENHA</label>
            <input
              type="password"
              value={novaSenha}
              onChange={e => setNovaSenha(e.target.value)}
              placeholder="Mínimo 6 caracteres"
              style={{ ...inputSt, marginBottom: 12 }}
            />
            {resetErro && <div style={{ fontSize: FONT.xs, color: C.desp, marginBottom: 10 }}>{resetErro}</div>}
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <GhBtn onClick={() => setModalReset(null)}>Cancelar</GhBtn>
              <PrBtn onClick={handleResetar} disabled={resetLoad}>{resetLoad ? 'Salvando...' : 'Salvar senha'}</PrBtn>
            </div>
          </div>
        </div>
      )}

      {/* Sub-modal: Confirmar exclusão */}
      {modalExcluir && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1100, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}
          onClick={e => { if (e.target === e.currentTarget) setModalExcluir(null); }}>
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.lg, padding: '28px', width: '100%', maxWidth: 360 }}>
            <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text, marginBottom: 12 }}>Excluir acesso</div>
            <div style={{ fontSize: FONT.sm, color: C.textMuted, marginBottom: 20, lineHeight: 1.6 }}>
              Tem certeza que deseja remover o acesso de <strong style={{ color: C.text }}>{modalExcluir.nome}</strong>?<br />
              <span style={{ fontSize: FONT.xs, color: C.desp }}>⚠️ O login será excluído permanentemente.</span>
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <GhBtn onClick={() => setModalExcluir(null)}>Cancelar</GhBtn>
              <button
                onClick={handleExcluir}
                disabled={excluirLoad}
                style={{ background: excluirLoad ? C.desp + '66' : C.desp, color: '#fff', border: 'none', borderRadius: RADIUS.md, padding: '8px 18px', fontSize: FONT.sm, fontWeight: 700, fontFamily: "'Inter',sans-serif", cursor: excluirLoad ? 'not-allowed' : 'pointer' }}
              >{excluirLoad ? 'Excluindo...' : 'Excluir acesso'}</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ── Botões auxiliares ────────────────────────────────────────────────────────
function SmBtn({ children, onClick, danger }) {
  const [hov, setHov] = useState(false);
  const col = danger ? C.desp : C.textMuted;
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        fontSize: FONT.xs, color: col,
        background: hov ? col + '18' : 'transparent',
        border: `1px solid ${col + '44'}`,
        borderRadius: RADIUS.sm, padding: '4px 10px',
        cursor: 'pointer', fontFamily: "'Inter',sans-serif",
        transition: 'background .12s', whiteSpace: 'nowrap',
      }}
    >{children}</button>
  );
}

function PrBtn({ children, onClick, type = 'button', disabled }) {
  return (
    <button type={type} onClick={onClick} disabled={disabled}
      style={{
        background: disabled ? C.brand + '66' : C.brand,
        color: C.bg, border: 'none', borderRadius: RADIUS.md,
        padding: '8px 18px', fontSize: FONT.sm, fontWeight: 700,
        fontFamily: "'Inter',sans-serif",
        cursor: disabled ? 'not-allowed' : 'pointer',
      }}
    >{children}</button>
  );
}

function GhBtn({ children, onClick }) {
  return (
    <button onClick={onClick}
      style={{
        background: 'transparent', color: C.textMuted,
        border: `1px solid ${C.border}`, borderRadius: RADIUS.md,
        padding: '8px 18px', fontSize: FONT.sm,
        fontFamily: "'Inter',sans-serif", cursor: 'pointer',
      }}
    >{children}</button>
  );
}
