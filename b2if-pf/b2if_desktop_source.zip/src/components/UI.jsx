import { C, RADIUS, SHADOW, FONT } from '../design/tokens.js';

// ── Button ─────────────────────────────────────────────────────────────────
export function Btn({ children, onClick, variant = 'primary', size = 'md', disabled, style, type = 'button', icon }) {
  const variants = {
    primary:  { background: C.brand,      color: C.bg,    border: 'none' },
    danger:   { background: C.red,        color: C.white, border: 'none' },
    ghost:    { background: 'transparent',color: C.text,  border: `1px solid ${C.border}` },
    outline:  { background: 'transparent',color: C.brand, border: `1px solid ${C.brand}` },
    muted:    { background: C.card,       color: C.textMuted, border: `1px solid ${C.border}` },
  };
  const sizes = {
    sm: { padding: '5px 12px', fontSize: FONT.sm, borderRadius: RADIUS.sm },
    md: { padding: '8px 18px', fontSize: FONT.base, borderRadius: RADIUS.md },
    lg: { padding: '12px 28px', fontSize: FONT.lg, borderRadius: RADIUS.md },
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      style={{
        ...variants[variant],
        ...sizes[size],
        fontFamily: FONT.family,
        fontWeight: 600,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        display: 'inline-flex',
        alignItems: 'center',
        gap: '6px',
        transition: 'opacity .15s, filter .15s',
        whiteSpace: 'nowrap',
        ...style,
      }}
    >
      {icon && <span style={{ display: 'flex', alignItems: 'center' }}>{icon}</span>}
      {children}
    </button>
  );
}

// ── Card ──────────────────────────────────────────────────────────────────
export function Card({ children, style, padding = '20px', onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: C.card,
        border: `1px solid ${C.border}`,
        borderRadius: RADIUS.lg,
        padding,
        boxShadow: SHADOW.card,
        cursor: onClick ? 'pointer' : 'default',
        transition: onClick ? 'border-color .15s, background .15s' : undefined,
        ...style,
      }}
      onMouseEnter={onClick ? e => { e.currentTarget.style.borderColor = C.brand; e.currentTarget.style.background = C.cardHover; } : undefined}
      onMouseLeave={onClick ? e => { e.currentTarget.style.borderColor = C.border; e.currentTarget.style.background = C.card; } : undefined}
    >
      {children}
    </div>
  );
}

// ── Modal ────────────────────────────────────────────────────────────────
export function Modal({ open, onClose, title, children, width = '480px' }) {
  if (!open) return null;
  return (
    <div
      style={{ position: 'fixed', inset: 0, background: C.overlay, zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.xl, padding: '28px', width, maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto', boxShadow: SHADOW.modal }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
          <span style={{ fontSize: FONT.xl, fontWeight: 700, color: C.text }}>{title}</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: C.textMuted, cursor: 'pointer', fontSize: '20px', lineHeight: 1 }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ── Badge ────────────────────────────────────────────────────────────────
export function Badge({ children, color = C.brand, bg }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center',
      padding: '2px 8px',
      borderRadius: RADIUS.full,
      fontSize: FONT.xs,
      fontWeight: 600,
      color,
      background: bg || color + '22',
    }}>{children}</span>
  );
}

// ── KPI Card ─────────────────────────────────────────────────────────────
export function KPICard({ label, value, color = C.text, sub, icon }) {
  return (
    <Card padding="16px 20px">
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: FONT.sm, color: C.textMuted, marginBottom: '6px', fontWeight: 500 }}>{label}</div>
          <div style={{ fontSize: FONT.xxl, fontWeight: 700, color, lineHeight: 1 }}>{value}</div>
          {sub && <div style={{ fontSize: FONT.sm, color: C.textDim, marginTop: '6px' }}>{sub}</div>}
        </div>
        {icon && <div style={{ fontSize: '22px', color, opacity: 0.7 }}>{icon}</div>}
      </div>
    </Card>
  );
}

// ── Input ────────────────────────────────────────────────────────────────
export function Input({ label, value, onChange, placeholder, type = 'text', style }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', ...style }}>
      {label && <label style={{ fontSize: FONT.sm, color: C.textMuted, fontWeight: 500 }}>{label}</label>}
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          background: C.bg,
          border: `1px solid ${C.border}`,
          borderRadius: RADIUS.md,
          padding: '9px 12px',
          color: C.text,
          fontSize: FONT.base,
          fontFamily: FONT.family,
          outline: 'none',
          width: '100%',
          boxSizing: 'border-box',
        }}
      />
    </div>
  );
}

// ── Select ───────────────────────────────────────────────────────────────
export function Select({ label, value, onChange, options, style, placeholder }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', ...style }}>
      {label && <label style={{ fontSize: FONT.sm, color: C.textMuted, fontWeight: 500 }}>{label}</label>}
      <select
        value={value}
        onChange={e => onChange(e.target.value)}
        style={{
          background: C.bg,
          border: `1px solid ${C.border}`,
          borderRadius: RADIUS.md,
          padding: '9px 12px',
          color: value ? C.text : C.textDim,
          fontSize: FONT.base,
          fontFamily: FONT.family,
          outline: 'none',
          width: '100%',
          cursor: 'pointer',
        }}
      >
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(o => (
          <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>
        ))}
      </select>
    </div>
  );
}

// ── Tabs ─────────────────────────────────────────────────────────────────
export function Tabs({ tabs, active, onChange }) {
  return (
    <div style={{ display: 'flex', gap: '2px', background: C.bg, borderRadius: RADIUS.md, padding: '4px', border: `1px solid ${C.border}` }}>
      {tabs.map(t => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          style={{
            flex: 1,
            padding: '8px 14px',
            borderRadius: RADIUS.sm,
            border: 'none',
            background: active === t.id ? C.card : 'transparent',
            color: active === t.id ? C.brand : C.textMuted,
            fontWeight: active === t.id ? 700 : 500,
            fontSize: FONT.sm,
            cursor: 'pointer',
            fontFamily: FONT.family,
            transition: 'all .15s',
            whiteSpace: 'nowrap',
          }}
        >
          {t.icon && <span style={{ marginRight: 5 }}>{t.icon}</span>}
          {t.label}
        </button>
      ))}
    </div>
  );
}

// ── Section Title ─────────────────────────────────────────────────────────
export function SectionTitle({ title, sub, action }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '16px' }}>
      <div>
        <div style={{ fontSize: FONT.lg, fontWeight: 700, color: C.text }}>{title}</div>
        {sub && <div style={{ fontSize: FONT.sm, color: C.textMuted, marginTop: '3px' }}>{sub}</div>}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}

// ── Semáforo bar ──────────────────────────────────────────────────────────
export function ProgressBar({ value, max, color, height = 6 }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  const cor = pct >= 100 ? C.red : pct >= 85 ? C.yellow : C.green;
  return (
    <div style={{ background: C.bg, borderRadius: RADIUS.full, height, overflow: 'hidden', border: `1px solid ${C.border}` }}>
      <div style={{ width: `${pct}%`, height: '100%', background: color || cor, borderRadius: RADIUS.full, transition: 'width .3s' }} />
    </div>
  );
}

// ── Formata valor em BRL ──────────────────────────────────────────────────
export function fmtBRL(v = 0) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);
}

export function fmtNum(v = 0, casas = 0) {
  return new Intl.NumberFormat('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas }).format(v);
}

// ── Empty State ────────────────────────────────────────────────────────────
export function Empty({ icon = '📂', title, sub }) {
  return (
    <div style={{ textAlign: 'center', padding: '48px 24px', color: C.textMuted }}>
      <div style={{ fontSize: '40px', marginBottom: '12px' }}>{icon}</div>
      {title && <div style={{ fontSize: FONT.lg, fontWeight: 600, marginBottom: '6px', color: C.text }}>{title}</div>}
      {sub && <div style={{ fontSize: FONT.sm }}>{sub}</div>}
    </div>
  );
}

// ── Tooltip simples ───────────────────────────────────────────────────────
export function Tooltip({ text, children }) {
  const [show, setShow] = useState(false);
  return (
    <div style={{ position: 'relative', display: 'inline-flex' }}
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      {children}
      {show && (
        <div style={{
          position: 'absolute', bottom: '110%', left: '50%', transform: 'translateX(-50%)',
          background: '#1E2D45', color: C.text, padding: '5px 10px',
          borderRadius: RADIUS.sm, fontSize: FONT.xs, whiteSpace: 'nowrap',
          zIndex: 100, pointerEvents: 'none', boxShadow: SHADOW.card,
        }}>{text}</div>
      )}
    </div>
  );
}

// ── Spinner ────────────────────────────────────────────────────────────────
export function Spinner() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px' }}>
      <div style={{
        width: 32, height: 32, border: `3px solid ${C.border}`,
        borderTopColor: C.brand, borderRadius: '50%',
        animation: 'spin 0.7s linear infinite',
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

// needed for Tooltip
import { useState } from 'react';
