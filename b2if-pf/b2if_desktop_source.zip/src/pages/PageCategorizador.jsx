import { useState, useRef, useMemo, useEffect, useCallback } from 'react';
import { C, FONT, RADIUS } from '../design/tokens.js';
import { useApp } from '../context/AppContext.jsx';
import { Btn, Card, Modal, Input, Select, Badge, fmtBRL, Empty, Spinner } from '../components/UI.jsx';
import { parseCSV, parseXLSM, autoCategorizar } from '../utils/parser.js';
import { parsePDF } from '../utils/pdfParser.js';
import { GRUPOS, REGRAS_PADRAO } from '../data/categorias.js';
import { gerarId } from '../utils/clienteStorage.js';

// useVirtualList desativado: renderiza tudo diretamente.
// Com ate ~500 linhas, o DOM direto e mais confiavel que virtualizar.
function useVirtualList(allItems) {
  const containerRef = useRef(null);
  const visibleItems = allItems.map((item, index) => ({ item, index }));
  return { containerRef, totalHeight: 0, offsetTop: 0, offsetBottom: 0, visibleItems };
}

// ── ColFilter — filtro por coluna tipo "Excel" ────────────────────────────────
const PARC_VAZIO = '__vazio__'; // sentinela para "sem parcelamento"

function ColFilter({ label, valores, selecionados, onChange, categorias: cats, numeric }) {
  const [aberto, setAberto] = useState(false);
  const [pos, setPos]       = useState(null);   // { top, left } em coords fixed
  const [busca, setBusca]   = useState('');
  const [sortDir, setSortDir] = useState(null); // null | 'asc' | 'desc'
  const btnRef  = useRef();
  const dropRef = useRef();

  // Calcula posição e abre o dropdown
  function abrirDropdown() {
    if (!btnRef.current) return;
    const r = btnRef.current.getBoundingClientRect();
    setPos({ top: r.bottom + 4, left: r.left });
    setAberto(true);
  }
  function fecharDropdown() { setAberto(false); setPos(null); }

  // Fecha ao clicar fora
  useEffect(() => {
    if (!aberto) return;
    function handler(e) {
      if (
        dropRef.current && !dropRef.current.contains(e.target) &&
        btnRef.current  && !btnRef.current.contains(e.target)
      ) fecharDropdown();
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [aberto]);

  // Fecha ao rolar a PÁGINA — ignora scroll dentro do próprio dropdown
  useEffect(() => {
    if (!aberto) return;
    const handler = (e) => {
      // Se o scroll aconteceu dentro do dropdown, não fecha
      if (dropRef.current && dropRef.current.contains(e.target)) return;
      fecharDropdown();
    };
    window.addEventListener('scroll', handler, true);
    return () => window.removeEventListener('scroll', handler, true);
  }, [aberto]);

  const temFiltro = selecionados.size > 0;

  const valoresFiltrados = useMemo(() => {
    const list = [...valores];
    if (numeric) {
      const vazio = list.includes(PARC_VAZIO) ? [PARC_VAZIO] : [];
      const nums  = list.filter(v => v !== PARC_VAZIO);
      if (sortDir === 'asc')  nums.sort((a, b) => Number(a) - Number(b));
      if (sortDir === 'desc') nums.sort((a, b) => Number(b) - Number(a));
      const sorted = [...vazio, ...nums];
      if (!busca.trim()) return sorted;
      const q = busca.trim().toLowerCase();
      return sorted.filter(v => rotulo(v).toLowerCase().includes(q));
    }
    // Ordena pelo rótulo legível (nome da categoria), não pelo valor bruto (UUID)
    if (sortDir === 'asc')  list.sort((a, b) => rotulo(a).localeCompare(rotulo(b), 'pt'));
    if (sortDir === 'desc') list.sort((a, b) => rotulo(b).localeCompare(rotulo(a), 'pt'));
    if (!busca.trim()) return list;
    const q = busca.trim().toLowerCase();
    return list.filter(v => rotulo(v).toLowerCase().includes(q));
  }, [valores, busca, sortDir, numeric, cats]);

  function toggleValor(v) {
    const next = new Set(selecionados);
    next.has(v) ? next.delete(v) : next.add(v);
    onChange(next);
  }
  function toggleTodos() {
    if (selecionados.size === valores.size) onChange(new Set());
    else onChange(new Set(valores));
  }
  function limpar() { onChange(new Set()); }

  function rotulo(v) {
    if (v === PARC_VAZIO) return '— Vazio (sem parcelas) —';
    if (cats) { const c = cats.find(x => x.id === v); if (c) return c.nome; }
    if (numeric) return `${v} parcela${Number(v) !== 1 ? 's' : ''}`;
    return String(v);
  }

  return (
    <th style={{ padding: '10px 10px', textAlign: 'left', whiteSpace: 'nowrap', position: 'relative', userSelect: 'none', background: 'inherit' }}>
      {/* Botão do cabeçalho */}
      <button
        ref={btnRef}
        onClick={() => aberto ? fecharDropdown() : abrirDropdown()}
        style={{
          background: 'none', border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 4,
          color: temFiltro ? C.brand : C.textMuted,
          fontWeight: 600, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif",
          padding: 0, width: '100%',
        }}
      >
        {label}
        <span style={{
          fontSize: 9, opacity: temFiltro ? 1 : 0.5,
          color: temFiltro ? C.brand : C.textMuted,
          transform: aberto ? 'rotate(180deg)' : 'none', transition: 'transform .15s',
        }}>&#9660;</span>
        {temFiltro && (
          <span style={{ background: C.brand, color: '#fff', borderRadius: 10, fontSize: 9, padding: '1px 5px', fontWeight: 700 }}>
            {selecionados.size}
          </span>
        )}
      </button>

      {/* Dropdown — renderizado direto no body via position:fixed para não ser cortado pelo overflow do container */}
      {aberto && pos && (
        <div
          ref={dropRef}
          style={{
            position: 'fixed',
            top: pos.top,
            left: pos.left,
            zIndex: 99999,
            background: C.card,
            border: `1px solid ${C.border}`,
            borderRadius: RADIUS.lg,
            boxShadow: '0 8px 32px rgba(0,0,0,0.45)',
            minWidth: 240,
            maxHeight: 360,
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          {/* Toolbar: ordenar + limpar */}
          <div style={{ display: 'flex', gap: 4, padding: '8px 10px', borderBottom: `1px solid ${C.border}` }}>
            <button onClick={() => setSortDir(sortDir === 'asc' ? null : 'asc')}
              style={{ flex: 1, padding: '4px 0', borderRadius: 4, border: `1px solid ${sortDir === 'asc' ? C.brand : C.border}`, background: sortDir === 'asc' ? C.brand + '22' : 'transparent', color: sortDir === 'asc' ? C.brand : C.textMuted, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", cursor: 'pointer' }}>A&#8594;Z</button>
            <button onClick={() => setSortDir(sortDir === 'desc' ? null : 'desc')}
              style={{ flex: 1, padding: '4px 0', borderRadius: 4, border: `1px solid ${sortDir === 'desc' ? C.brand : C.border}`, background: sortDir === 'desc' ? C.brand + '22' : 'transparent', color: sortDir === 'desc' ? C.brand : C.textMuted, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", cursor: 'pointer' }}>Z&#8594;A</button>
            {temFiltro && (
              <button onClick={() => { limpar(); fecharDropdown(); }}
                style={{ flex: 1, padding: '4px 0', borderRadius: 4, border: `1px solid ${C.desp}55`, background: C.desp + '18', color: C.desp, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", cursor: 'pointer', fontWeight: 700 }}>Limpar</button>
            )}
          </div>

          {/* Busca */}
          <div style={{ padding: '6px 10px', borderBottom: `1px solid ${C.border}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: C.bg, borderRadius: 6, padding: '4px 8px' }}>
              <input
                autoFocus
                value={busca}
                onChange={e => setBusca(e.target.value)}
                placeholder="Filtrar..."
                style={{ background: 'none', border: 'none', outline: 'none', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", width: '100%' }}
              />
            </div>
          </div>

          {/* Selecionar todos */}
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 12px', borderBottom: `1px solid ${C.border}`, cursor: 'pointer', color: C.textMuted, fontSize: FONT.xs }}>
            <input type="checkbox"
              checked={selecionados.size === 0}
              onChange={toggleTodos}
              style={{ accentColor: C.brand }}
            />
            <span style={{ fontWeight: 600 }}>{selecionados.size === 0 ? '✓ Todos' : 'Selecionar todos'}</span>
          </label>

          {/* Lista de valores */}
          <div style={{ overflowY: 'auto', flex: 1 }}>
            {valoresFiltrados.length === 0 ? (
              <div style={{ padding: '10px 12px', color: C.textMuted, fontSize: FONT.xs, textAlign: 'center' }}>Nenhum resultado</div>
            ) : valoresFiltrados.map(v => (
              <label key={v} style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '5px 12px', cursor: 'pointer',
                background: selecionados.has(v) ? C.brand + '14' : 'transparent', transition: 'background .1s',
              }}>
                <input type="checkbox"
                  checked={selecionados.has(v)}
                  onChange={() => toggleValor(v)}
                  style={{ accentColor: C.brand }}
                />
                <span style={{ color: C.text, fontSize: FONT.xs, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {rotulo(v)}
                </span>
              </label>
            ))}
          </div>

          {/* Rodapé */}
          <div style={{ padding: '6px 12px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 10, color: C.textMuted }}>Mostrando {valoresFiltrados.length} de {valores.size}</span>
            <button onClick={fecharDropdown}
              style={{ background: C.brand, color: '#fff', border: 'none', borderRadius: 5, padding: '3px 12px', fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", cursor: 'pointer', fontWeight: 700 }}>OK</button>
          </div>
        </div>
      )}
    </th>
  );
}

export default function PageCategorizador() {
  const { clienteAtivo, setClienteAtivo, setPaginaAtual, modoLeitura, salvando } = useApp();
  const [aba, setAba] = useState('transacoes');
  const [filtroStatus, setFiltroStatus] = useState('todos');
  const [filtroConta, setFiltroConta] = useState('');
  const [filtroCategoria, setFiltroCategoria] = useState('');
  const [filtroFormato, setFiltroFormato] = useState('');
  const [filtroTempo, setFiltroTempo] = useState('competencia'); // competencia | data
  const [filtroMes, setFiltroMes] = useState('');  // YYYY-MM
  const [filtroOrigem, setFiltroOrigem] = useState('');         // '' | 'whatsapp' | 'outros'
  const [busca, setBusca] = useState('');
  const [selecionados, setSelecionados] = useState(new Set());
  const [macroTemp, setMacroTemp] = useState({}); // { [id]: grupo temporário para filtrar cats
  const [aprendizadoOk, setAprendizadoOk] = useState({}); // { [id]: true } regra criada manualmente
  // ── Filtros por coluna (multi-select, tipo Excel) ────────────────────────
  const [filtrosColuna, setFiltrosColuna] = useState({
    conta:     new Set(), // Set de strings
    formato:   new Set(),
    macro:     new Set(),
    categoria: new Set(), // Set de IDs de categoria
    parcela:   new Set(), // Set de strings: números ou PARC_VAZIO
  });
  function setFiltroCol(col, nextSet) {
    setFiltrosColuna(prev => ({ ...prev, [col]: nextSet }));
  }
  const [modalEditar, setModalEditar] = useState(null);
  const [modalRegra, setModalRegra] = useState(null);
  const [modalCategoria, setModalCategoria] = useState(null);
  const [confirmDeleteCat, setConfirmDeleteCat] = useState(null); // { id, nome, qtdTrans }
  const [editandoCatNome, setEditandoCatNome] = useState(null);   // id em edição inline
  const [modalConta, setModalConta] = useState(null);
  const [modalRevisao, setModalRevisao] = useState(null); // { transacoes, banco, nomeConta }
  const [carregando, setCarregando] = useState(false);
  const [erroImport, setErroImport] = useState(null);
  const fileRef = useRef();

  if (!clienteAtivo) return null;
  const { transacoes, categorias, regras, contas } = clienteAtivo;

  // Filtros sincronos: garantem que todos os dados aparecem imediatamente.
  // useDeferredValue removido — causava exibicao incompleta dos dados.
  const buscaDeferred         = busca;
  const filtroStatusDeferred  = filtroStatus;
  const filtroMesDeferred     = filtroMes;
  const filtrosColDeferred    = filtrosColuna;

  // ── Upload PDF ou CSV ──────────────────────────────────────────────────
  async function handleUpload(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setCarregando(true);
    setErroImport(null);

    try {
      for (const file of files) {
        const nameLower = file.name.toLowerCase();
        const isPDF  = nameLower.endsWith('.pdf');
        const isCSV  = nameLower.endsWith('.csv');
        const isXLSX = nameLower.endsWith('.xlsx') || nameLower.endsWith('.xlsm');

        // Usa regras do cliente, ou as padrão se ainda não há regras
        const regrasEfetivas = (regras && regras.length > 0) ? regras : REGRAS_PADRAO;

        if (isPDF) {
          // Parseia PDF e abre modal de revisão
          const resultado = await parsePDF(file);
          const autocats = autoCategorizar(resultado.transacoes, regrasEfetivas);
          const nomeConta = resultado.banco || file.name.replace(/\.pdf$/i, '');
          setModalRevisao({ transacoes: autocats, banco: resultado.banco, nomeConta, textoOriginal: resultado.textoOriginal });
        } else if (isCSV) {
          const text = await file.text();
          const nomeConta = file.name.replace(/\.csv$/i, '');
          const { transacoes: parsed } = parseCSV(text, nomeConta);
          const autocats = autoCategorizar(parsed, regrasEfetivas);
          // CSV vai direto sem revisão
          confirmarImport(autocats, nomeConta);
        } else if (isXLSX) {
          // Planilha pré-tratada (XLSM/XLSX formato B2IF)
          const resultado = await parseXLSM(file);
          // Aplica auto-cat nas que ainda não têm categoria
          const autocats = autoCategorizar(resultado.transacoes, regrasEfetivas);
          setModalRevisao({
            transacoes: autocats,
            banco: resultado.banco,
            nomeConta: resultado.nomeConta,
            textoOriginal: null,
            isXLSM: true,
          });
        }
      }
    } catch (err) {
      console.error(err);
      setErroImport('Erro ao processar arquivo: ' + (err?.message || err));
    }

    setCarregando(false);
    e.target.value = '';
  }

  // ── Confirma import (vindo da revisão ou direto do CSV) ────────────────
  function confirmarImport(novasT, nomeConta) {
    let novasTransacoes = [...transacoes, ...novasT];
    let novasContas = [...contas];

    // Coleta TODAS as contas únicas presentes nas transações importadas
    // Cada transação pode ter uma conta diferente (ex: XLSM com múltiplas contas)
    const contasNasTransacoes = [...new Set(
      novasT.map(t => t.conta?.trim()).filter(Boolean)
    )];

    // Fallback: se nenhuma transação tem conta individual, usa nomeConta
    const contasParaCriar = contasNasTransacoes.length > 0
      ? contasNasTransacoes
      : [nomeConta].filter(Boolean);

    for (const nomeC of contasParaCriar) {
      if (!novasContas.find(c => c.nome === nomeC)) {
        novasContas.push({ id: gerarId(), nome: nomeC, banco: nomeC, tipo: 'corrente' });
      }
    }

    setClienteAtivo({ ...clienteAtivo, transacoes: novasTransacoes, contas: novasContas });
    setModalRevisao(null);
  }

  // ── helpers para categorias ordenadas por macro ─────────────────────

  // Map id → categoria: lookup O(1) em vez de .find() O(n) por linha
  const catPorId = useMemo(() => {
    const m = new Map();
    for (const c of categorias) m.set(c.id, c);
    return m;
  }, [categorias]);

  // Array de categorias já ordenado — evita .sort() inline a cada linha renderizada
  const categoriasOrdenadas = useMemo(
    () => [...categorias].sort((a, b) => a.nome.localeCompare(b.nome, 'pt')),
    [categorias]
  );

  const categoriasPorMacro = useMemo(() => {
    const ordem = Object.values(GRUPOS);
    const mapa = {};
    for (const g of ordem) mapa[g] = [];
    for (const c of categoriasOrdenadas) {
      if (mapa[c.grupo]) mapa[c.grupo].push(c);
      else mapa[c.grupo] = [c];
    }
    return mapa;
  }, [categoriasOrdenadas]);

  // Dado uma categoria id, retorna o grupo dela — usa Map O(1)
  function grupoDeCategoria(catId) {
    return catPorId.get(catId)?.grupo || '';
  }

  // ── Valores únicos por coluna (para o ColFilter) ─────────────────────
  const valoresColuna = useMemo(() => ({
    conta:     new Set(transacoes.map(t => t.conta).filter(Boolean)),
    formato:   new Set(transacoes.map(t => t.formato).filter(Boolean)),
    macro:     new Set(transacoes.map(t => {
      const cat = catPorId.get(t.categoria);
      return macroTemp[t.id] !== undefined ? macroTemp[t.id] : (cat?.grupo || t.grupoImportado || '');
    }).filter(Boolean)),
    categoria: new Set(transacoes.map(t => t.categoria).filter(Boolean)),
    // Parcelas: PARC_VAZIO para sem parcela, ou string do número (ex: '4')
    parcela:   new Set(transacoes.map(t =>
      t.parcelaTotal != null ? String(t.parcelaTotal) : PARC_VAZIO
    )),
  }), [transacoes, categorias, macroTemp]);

  // ── Helper: aplica filtros exceto o indicado (para cascata) ──────────
  function filtrarSem(excluir, ts) {
    return ts.filter(t => {
      if (excluir !== 'status' && filtroStatus !== 'todos') {
        const temCat = !!(t.categoria && t.categoria !== '');
        if (filtroStatus === 'pendente'     &&  temCat) return false;
        if (filtroStatus === 'categorizado' && !temCat) return false;
      }
      if (excluir !== 'conta'    && filtroConta && t.conta !== filtroConta) return false;
      if (excluir !== 'categoria'&& filtroCategoria && t.categoria !== filtroCategoria) return false;
      if (excluir !== 'formato'  && filtroFormato && (t.formato||'').toLowerCase() !== filtroFormato.toLowerCase()) return false;
      if (excluir !== 'contaCol' && filtrosColuna.conta.size > 0 && !filtrosColuna.conta.has(t.conta || '')) return false;
      if (excluir !== 'formatoCol'&& filtrosColuna.formato.size > 0 && !filtrosColuna.formato.has(t.formato || '')) return false;
      if (excluir !== 'macroCol') {
        if (filtrosColuna.macro.size > 0) {
          const cat = catPorId.get(t.categoria);
          const m = macroTemp[t.id] !== undefined ? macroTemp[t.id] : (cat?.grupo || t.grupoImportado || '');
          if (!filtrosColuna.macro.has(m)) return false;
        }
      }
      if (excluir !== 'categoriaCol' && filtrosColuna.categoria.size > 0 && !filtrosColuna.categoria.has(t.categoria || '')) return false;
      return true;
    });
  }

  // ── Valores disponíveis em cascata (cada filtro vê o resultado dos outros) ──
  const valoresCascata = useMemo(() => {
    const getMacro = t => {
      const cat = catPorId.get(t.categoria);
      return macroTemp[t.id] !== undefined ? macroTemp[t.id] : (cat?.grupo || t.grupoImportado || '');
    };
    // Conta: filtra tudo exceto o próprio filtro de conta
    const tsConta     = filtrarSem('conta',        transacoes);
    const tsFormato   = filtrarSem('formato',       transacoes);
    const tsContaCol  = filtrarSem('contaCol',      transacoes);
    const tsFormatoCol= filtrarSem('formatoCol',    transacoes);
    const tsMacroCol  = filtrarSem('macroCol',      transacoes);
    const tsCatCol    = filtrarSem('categoriaCol',  transacoes);
    return {
      // Dropdowns principais
      contas:     [...new Set(tsConta.map(t => t.conta).filter(Boolean))].sort(),
      formatos:   [...new Set(tsFormato.map(t => t.formato).filter(Boolean))].sort(),
      // ColFilter: cada coluna vê o resultado sem ela mesma
      contaCol:     new Set(tsContaCol.map(t => t.conta).filter(Boolean)),
      formatoCol:   new Set(tsFormatoCol.map(t => t.formato).filter(Boolean)),
      macroCol:     new Set(tsMacroCol.map(getMacro).filter(Boolean)),
      categoriaCol: new Set(tsCatCol.map(t => t.categoria).filter(Boolean)),
      parcela:      valoresColuna.parcela, // parcela não participa da cascata
    };
  }, [transacoes, filtroStatus, filtroConta, filtroCategoria, filtroFormato,
      filtrosColuna, macroTemp, catPorId, valoresColuna.parcela]);

  // Categorias disponíveis no dropdown principal — filtradas pelo macro selecionado nas colunas
  const categoriasCascata = useMemo(() => {
    // Se há filtro de macro ativo (ColFilter), só mostra cats daquele grupo
    if (filtrosColuna.macro.size > 0) {
      return categorias.filter(c => filtrosColuna.macro.has(c.grupo));
    }
    return categorias;
  }, [categorias, filtrosColuna.macro]);

  // ── Filtro de transações — usa valores deferred para não bloquear UI ─────
  const transacoesFiltradas = useMemo(() => transacoes.filter(t => {
    // Filtro de status: usa presença de categoria como fonte da verdade,
    // não t.status (que pode estar dessincronizado por dados antigos).
    if (filtroStatusDeferred !== 'todos') {
      const temCat = !!(t.categoria && t.categoria !== '');
      if (filtroStatusDeferred === 'pendente'    &&  temCat) return false;
      if (filtroStatusDeferred === 'categorizado' && !temCat) return false;
    }
    if (filtroConta && t.conta !== filtroConta) return false;
    if (filtroCategoria && t.categoria !== filtroCategoria) return false;
    if (filtroFormato && (t.formato || '').toLowerCase() !== filtroFormato.toLowerCase()) return false;
    if (buscaDeferred && !(t.descricao || '').toLowerCase().includes(buscaDeferred.toLowerCase())) return false;
    if (filtroOrigem === 'whatsapp' && t.origem !== 'whatsapp') return false;
    if (filtroOrigem === 'outros'   && t.origem === 'whatsapp') return false;
    // ── Filtros por coluna (multi-select) ──
    if (filtrosColDeferred.conta.size > 0     && !filtrosColDeferred.conta.has(t.conta || '')) return false;
    if (filtrosColDeferred.formato.size > 0   && !filtrosColDeferred.formato.has(t.formato || '')) return false;
    if (filtrosColDeferred.macro.size > 0) {
      const cat = catPorId.get(t.categoria);
      const macroResolvido = macroTemp[t.id] !== undefined ? macroTemp[t.id] : (cat?.grupo || t.grupoImportado || '');
      if (!filtrosColDeferred.macro.has(macroResolvido)) return false;
    }
    if (filtrosColDeferred.categoria.size > 0 && !filtrosColDeferred.categoria.has(t.categoria || '')) return false;
    if (filtrosColDeferred.parcela.size > 0) {
      const chave = t.parcelaTotal != null ? String(t.parcelaTotal) : PARC_VAZIO;
      if (!filtrosColDeferred.parcela.has(chave)) return false;
    }
    if (filtroMesDeferred) {
      const campo = filtroTempo === 'competencia' ? (t.competencia || t.periodoLabel || t.conta) : t.data;
      if (!campo) return false;
      if (filtroTempo === 'competencia') {
        const mesStr = String(campo);
        const [yyyy, mm] = filtroMesDeferred.split('-');
        if (mesStr.startsWith(filtroMesDeferred)) return true;
        const mesesNomes = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
        const nomesMes = mesesNomes[parseInt(mm,10)-1];
        if (mesStr.toLowerCase().includes(nomesMes) && mesStr.includes(yyyy)) return true;
        return false;
      } else {
        return (t.data || '').startsWith(filtroMesDeferred);
      }
    }
    return true;
  }), [transacoes, filtroStatusDeferred, filtroConta, filtroCategoria, filtroFormato, buscaDeferred, filtroMesDeferred, filtroTempo, filtrosColDeferred, macroTemp, catPorId, filtroOrigem]);

  // Contadores memoizados — conta nas transações FILTRADAS para que os números
  // sempre correspondam ao que está visível na tabela.
  const { semCategoria, comCategoria } = useMemo(() => {
    let sem = 0, com = 0;
    for (const t of transacoesFiltradas) {
      if (t.categoria && t.categoria !== '') com++; else sem++;
    }
    return { semCategoria: sem, comCategoria: com };
  }, [transacoesFiltradas]);

  // Totais globais (todas as transações, ignora filtros) — usados no badge do cabeçalho
  const { totalCategorizados } = useMemo(() => {
    let cat = 0;
    for (const t of transacoes) {
      if (t.categoria && t.categoria !== '') cat++;
    }
    return { totalCategorizados: cat };
  }, [transacoes]);

  // Saldo dinâmico das transações filtradas
  const saldoFiltrado = useMemo(() => {
    let rec = 0, desp = 0;
    for (const t of transacoesFiltradas) {
      if (t.tipo === 'receita') rec += t.valor;
      else if (t.tipo === 'despesa') desp += t.valor;
    }
    return rec - desp;
  }, [transacoesFiltradas]);

  // Todos os meses disponíveis (competência ou data)
  const mesesDisponiveis = useMemo(() => {
    const set = new Set();
    for (const t of transacoes) {
      if (filtroTempo === 'competencia') {
        const comp = t.competencia || (t.data ? t.data.slice(0,7) : null);
        if (comp) set.add(comp);
      } else {
        if (t.data) set.add(t.data.slice(0,7));
      }
    }
    return [...set].sort();
  }, [transacoes, filtroTempo]);

  // ── Aprender: cria regra a partir de uma transação categorizada ─────────
  function extrairKeyword(descricao = '') {
    const limpo = descricao.trim()
      .replace(/\s*PARC\s+\d{1,2}\/\d{1,2}/gi, '')
      .replace(/\s+\d{1,2}\/\d{1,2}$/g, '')
      .replace(/\s+(BR|SP|RJ|MG|RS|SC|PR|BA|CE|GO|DF)$/gi, '')
      .replace(/\s+[A-Z]{2}\s*$/g, '')
      .trim();
    return limpo.split(/\s+/).filter(Boolean).slice(0, 3).join(' ').slice(0, 30).toLowerCase();
  }

  // Verifica se já existe regra que cobre a descrição desta transação
  // (mantido para uso pontual em salvarAprendizado)
  function temRegraParaTransacao(t) {
    const desc = (t.descricao || '').toLowerCase();
    return regras.some(r => r.keyword && desc.includes(r.keyword.toLowerCase()));
  }

  // Set pré-computado: ids de transações que já têm alguma regra cobrindo-as.
  // Evita chamar temRegraParaTransacao() (O(regras)) dentro do render de cada linha.
  const transComRegra = useMemo(() => {
    const keywords = regras.filter(r => r.keyword).map(r => r.keyword.toLowerCase());
    const set = new Set();
    for (const t of transacoes) {
      const desc = (t.descricao || '').toLowerCase();
      if (keywords.some(k => desc.includes(k))) set.add(t.id);
    }
    return set;
  }, [transacoes, regras]);

  // ── Virtualização da tabela de transações ─────────────────────────────────
  // ROW_HEIGHT deve corresponder à altura real da linha (padding 7px×2 + fonte ~18px + border ~1px = ~44px)
  // Usamos 46 para garantir margem e evitar gap no fundo.
  const ROW_HEIGHT = 46;
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const virt = useVirtualList(transacoesFiltradas, ROW_HEIGHT);

  // Filtros sincronos — isFiltering sempre false
  const isFiltering = false;

  // Salva regra imediatamente ao clicar 🧠 — sem modal de confirmação
  function salvarAprendizado(t) {
    if (!t.categoria) return;
    const keyword = extrairKeyword(t.descricao);
    if (!keyword) return;
    const jaExiste = regras.find(r => r.keyword.toLowerCase() === keyword.toLowerCase());
    let novasRegras;
    if (jaExiste) {
      novasRegras = regras.map(r =>
        r.keyword.toLowerCase() === keyword.toLowerCase()
          ? { ...r, categoria: t.categoria }
          : r
      );
    } else {
      novasRegras = [...regras, { id: gerarId(), keyword, categoria: t.categoria, prioridade: 2 }];
    }
    setClienteAtivo({ ...clienteAtivo, regras: novasRegras });
    // Marca check permanente para esta transação nesta sessão
    setAprendizadoOk(prev => ({ ...prev, [t.id]: true }));
  }

  // ── Auto-categorizar tudo ──────────────────────────────────────────────
  function handleAutoCat() {
    const novas = autoCategorizar(transacoes, regras);
    setClienteAtivo({ ...clienteAtivo, transacoes: novas });
  }

  // ── Edição inline rápida (macro / categoria) ────────────────────────
  function salvarInline(id, campo, valor) {
    const novas = transacoes.map(t => t.id === id
      ? {
          ...t,
          [campo]: valor,
          // status: 'categorizado' só quando categoria foi preenchida; 'pendente' se foi apagada
          status: campo === 'categoria'
            ? (valor ? 'categorizado' : 'pendente')
            : t.status,
        }
      : t
    );
    setClienteAtivo({ ...clienteAtivo, transacoes: novas });
  }

  // Quando troca macro de uma linha, guarda temporariamente e limpa categoria
  function trocarMacroLinha(id, novoGrupo) {
    setMacroTemp(prev => ({ ...prev, [id]: novoGrupo }));
    const novas = transacoes.map(t => t.id === id
      ? { ...t, categoria: null, status: 'pendente' } : t
    );
    setClienteAtivo({ ...clienteAtivo, transacoes: novas });
  }

  // ── Ação em lote ──────────────────────────────────────────────────────
  function toggleSelecionar(id) {
    setSelecionados(prev => {
      const s = new Set(prev);
      s.has(id) ? s.delete(id) : s.add(id);
      return s;
    });
  }
  function toggleTodos() {
    if (selecionados.size === transacoesFiltradas.length) {
      setSelecionados(new Set());
    } else {
      setSelecionados(new Set(transacoesFiltradas.map(t => t.id)));
    }
  }
  function deletarSelecionados() {
    const novas = transacoes.filter(t => !selecionados.has(t.id));
    setClienteAtivo({ ...clienteAtivo, transacoes: novas });
    setSelecionados(new Set());
  }
  function categorizarSelecionados(catId) {
    const novas = transacoes.map(t => selecionados.has(t.id)
      ? { ...t, categoria: catId, status: 'categorizado' } : t
    );
    setClienteAtivo({ ...clienteAtivo, transacoes: novas });
    setSelecionados(new Set());
  }

  // ── Salvar edição de transação ─────────────────────────────────────────
  function salvarEdicao(t) {
    // status segue a presença da categoria — nunca marca 'categorizado' se não há categoria
    const novas = transacoes.map(x =>
      x.id === t.id ? { ...t, status: t.categoria ? 'categorizado' : 'pendente' } : x
    );
    setClienteAtivo({ ...clienteAtivo, transacoes: novas });
    setModalEditar(null);
  }

  // ── Deletar transação ──────────────────────────────────────────────────
  function deletarTransacao(id) {
    const novas = transacoes.filter(t => t.id !== id);
    setClienteAtivo({ ...clienteAtivo, transacoes: novas });
  }

  // ── Salvar regra ───────────────────────────────────────────────────────
  function salvarRegra(r) {
    const novas = r.id
      ? regras.map(x => x.id === r.id ? r : x)
      : [...regras, { ...r, id: gerarId() }];
    setClienteAtivo({ ...clienteAtivo, regras: novas });
    setModalRegra(null);
  }

  // ── Salvar categoria ───────────────────────────────────────────────────
  function salvarCategoria(c) {
    const novas = c.id && categorias.find(x => x.id === c.id)
      ? categorias.map(x => x.id === c.id ? c : x)
      : [...categorias, { ...c, id: c.id || gerarId() }];
    setClienteAtivo({ ...clienteAtivo, categorias: novas });
    setModalCategoria(null);
  }

  function deletarCategoria(id) {
    // Remove categoria e migra transações vinculadas para sem categoria
    const novasCats = categorias.filter(c => c.id !== id);
    const novasTrans = transacoes.map(t =>
      t.categoria === id ? { ...t, categoria: '', subcategoria: '' } : t
    );
    setClienteAtivo({ ...clienteAtivo, categorias: novasCats, transacoes: novasTrans });
    setConfirmDeleteCat(null);
  }

  function renomearCategoria(id, novoNome) {
    const nome = novoNome.trim();
    if (!nome) return;
    const novas = categorias.map(c => c.id === id ? { ...c, nome } : c);
    setClienteAtivo({ ...clienteAtivo, categorias: novas });
    setEditandoCatNome(null);
  }

  // ── Exportar CSV tratado ───────────────────────────────────────────────
  function exportarCSV() {
    const header = 'Data,Descrição,Valor,Tipo,Categoria,Subcategoria,Conta,Parcela Atual,Parcela Total\n';
    const linhas = transacoes.map(t => [
      t.data, `"${(t.descricao||'').replace(/"/g, '""')}"`,
      t.valor.toFixed(2), t.tipo,
      t.categoria || '',
      t.subcategoria || '',
      t.conta || '',
      t.parcelaAtual || '',
      t.parcelaTotal || '',
    ].join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + header + linhas], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `b2if_${clienteAtivo.nome.replace(/\s/g,'_')}_transacoes.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const gruposOpts = Object.values(GRUPOS).map(g => ({ value: g, label: g }));
  // catOpts memoizado — sort caro só roda quando categorias mudam
  const catOpts = useMemo(
    () => categoriasOrdenadas.map(c => ({ value: c.id, label: `${c.grupo} › ${c.nome}` })),
    [categoriasOrdenadas]
  );

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1200, margin: '0 auto' }}>
      {/* Header da ferramenta */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24, gap: 16 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
            <div style={{ fontSize: FONT.xl, fontWeight: 800, color: C.text }}>{clienteAtivo.nome}</div>
            {transacoes.length > 0 && (
              <span style={{
                fontSize: FONT.xs, fontWeight: 600, padding: '3px 10px',
                background: totalCategorizados === transacoes.length ? C.recBg : C.yellowBg,
                color: totalCategorizados === transacoes.length ? C.rec : C.yellow,
                borderRadius: 20, border: `1px solid ${totalCategorizados === transacoes.length ? C.rec : C.yellow}44`,
              }}>
                {transacoes.length} transações · {Math.round((totalCategorizados / transacoes.length) * 100)}% categorizadas
              </span>
            )}
            {/* Indicador de salvamento automático */}
            {salvando ? (
              <span style={{
                fontSize: FONT.xs, fontWeight: 600, padding: '3px 10px',
                background: C.brand + '18', color: C.brand,
                borderRadius: 20, border: `1px solid ${C.brand}44`,
                display: 'flex', alignItems: 'center', gap: 5,
              }}>
                <span style={{ display: 'inline-block', width: 7, height: 7, borderRadius: '50%', background: C.brand, animation: 'pulse 1s infinite' }} />
                Salvando...
              </span>
            ) : !modoLeitura && transacoes.length > 0 ? (
              <span style={{
                fontSize: FONT.xs, fontWeight: 500, padding: '3px 10px',
                background: C.recBg, color: C.rec,
                borderRadius: 20, border: `1px solid ${C.rec}33`,
              }}>
                ✓ Salvo
              </span>
            ) : null}
          </div>
          <div style={{ fontSize: FONT.sm, color: C.textMuted, marginTop: 4 }}>Categorizador de Transações</div>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexShrink: 0 }}>
          {!modoLeitura && transacoes.length > 0 && (
            <button onClick={exportarCSV} style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '10px 20px', borderRadius: 8,
              border: `2px solid ${C.rec}`, background: 'transparent',
              color: C.rec, fontWeight: 700, fontSize: FONT.base,
              fontFamily: "'Inter',sans-serif", cursor: 'pointer',
            }}>
              ⬇️ Exportar
            </button>
          )}
          {!modoLeitura && (
            <>
              <input ref={fileRef} type="file" accept=".pdf,.PDF,.csv,.CSV,.xlsx,.XLSX,.xlsm,.XLSM" multiple onChange={handleUpload} style={{ display: 'none' }} />
              <button
                onClick={() => fileRef.current?.click()}
                disabled={carregando}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  padding: '10px 20px', borderRadius: 8,
                  border: `2px solid ${carregando ? C.border : C.rec}`,
                  background: 'transparent',
                  color: carregando ? C.textMuted : C.rec,
                  fontWeight: 700, fontSize: FONT.base,
                  fontFamily: "'Inter',sans-serif", cursor: carregando ? 'not-allowed' : 'pointer',
                  opacity: carregando ? 0.5 : 1, transition: 'opacity 0.15s',
                }}
              >
                ⬆️ {carregando ? 'Processando...' : 'Importar'}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Abas */}
      <div style={{ display: 'flex', gap: 4, borderBottom: `1px solid ${C.border}`, marginBottom: 24 }}>
        {[
          { id: 'transacoes',  label: 'Transações' },
          { id: 'contas',      label: 'Contas' },
          { id: 'categorias',  label: 'Categorias' },
        ].map(a => (
          <button
            key={a.id}
            onClick={() => setAba(a.id)}
            style={{
              padding: '10px 18px', border: 'none', background: 'transparent',
              color: aba === a.id ? C.brand : C.textMuted,
              fontWeight: aba === a.id ? 700 : 500,
              fontSize: FONT.base, cursor: 'pointer', fontFamily: "'Inter',sans-serif",
              borderBottom: aba === a.id ? `2px solid ${C.brand}` : '2px solid transparent',
              marginBottom: -1,
            }}
          >{a.label}</button>
        ))}
      </div>

      {/* ── ABA: TRANSAÇÕES ──────────────────────────────────────────────── */}
      {aba === 'transacoes' && (
        <>
          {/* Stats rápidas */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
            <StatBox label={`Total${transacoesFiltradas.length !== transacoes.length ? ` (${transacoesFiltradas.length} filtradas)` : ''}`} value={transacoes.length} color={C.info} />
            <StatBox label="Categorizados" value={comCategoria} color={C.green} />
            <StatBox label="Sem categoria" value={semCategoria} color={semCategoria > 0 ? C.yellow : C.green} />
            <StatBox
              label="Saldo (filtro atual)"
              value={(saldoFiltrado >= 0 ? '+' : '') + fmtBRL(Math.abs(saldoFiltrado))}
              color={saldoFiltrado >= 0 ? C.rec : C.desp}
            />
          </div>

          {/* Barra de ações */}
          <div style={{ display: 'flex', gap: 8, marginBottom: selecionados.size > 0 ? 8 : 16, alignItems: 'center', flexWrap: 'wrap' }}>
            {/* Filtro de tempo */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, background: C.bg, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '2px 4px' }}>
              {[['competencia','Competência'],['data','Data Compra']].map(([v,l]) => (
                <button key={v} onClick={() => { setFiltroTempo(v); setFiltroMes(''); }}
                  style={{ padding: '5px 10px', borderRadius: RADIUS.sm, border: 'none', cursor: 'pointer', fontFamily: "'Inter',sans-serif", fontSize: FONT.xs, fontWeight: 600,
                    background: filtroTempo === v ? C.brand : 'transparent', color: filtroTempo === v ? C.bg : C.textMuted }}>
                  {l}
                </button>
              ))}
            </div>
            <select value={filtroMes} onChange={e => setFiltroMes(e.target.value)}
              style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '5px 6px', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none' }}>
              <option value="">Todos os períodos</option>
              {mesesDisponiveis.map(m => {
                const [yyyy, mm] = m.split('-');
                const nomes = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
                return <option key={m} value={m}>{nomes[parseInt(mm,10)-1]}/{yyyy}</option>;
              })}
            </select>
            <select value={filtroStatus} onChange={e => setFiltroStatus(e.target.value)}
              style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '5px 6px', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none' }}>
              <option value="todos">Todos os status</option>
              <option value="pendente">Sem categoria</option>
              <option value="categorizado">Categorizados</option>
            </select>
            <select value={filtroConta} onChange={e => setFiltroConta(e.target.value)}
              style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '5px 6px', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none' }}>
              <option value="">Todas as contas</option>
              {valoresCascata.contas.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            {/* Filtro por Formato — cascata */}
            {valoresCascata.formatos.length > 0 && (
              <select value={filtroFormato} onChange={e => setFiltroFormato(e.target.value)}
                style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '5px 6px', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none' }}>
                <option value="">Todos os formatos</option>
                {valoresCascata.formatos.map(f => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            )}
            {/* Filtro por Categoria — cascata (filtra por macro ativo) */}
            <select value={filtroCategoria} onChange={e => setFiltroCategoria(e.target.value)}
              style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '5px 6px', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none' }}>
              <option value="">Todas as categorias</option>
              {Object.entries(
                categoriasCascata.reduce((acc, c) => {
                  if (!acc[c.grupo]) acc[c.grupo] = [];
                  acc[c.grupo].push(c);
                  return acc;
                }, {})
              ).map(([grupo, cats]) => (
                <optgroup key={grupo} label={grupo}>
                  {cats.map(c => <option key={c.id} value={c.id}>{c.nome}</option>)}
                </optgroup>
              ))}
            </select>
            {/* Filtro por origem (WhatsApp vs manual) */}
            {transacoes.some(t => t.origem === 'whatsapp') && (
              <select value={filtroOrigem} onChange={e => setFiltroOrigem(e.target.value)}
                style={{ background: C.card, border: `1px solid ${filtroOrigem === 'whatsapp' ? C.brand : C.border}`, borderRadius: RADIUS.md, padding: '5px 6px', color: filtroOrigem === 'whatsapp' ? C.brand : C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none', fontWeight: filtroOrigem === 'whatsapp' ? 700 : 400 }}>
                <option value="">Todas as origens</option>
                <option value="whatsapp">📱 WhatsApp</option>
                <option value="outros">📂 Outros</option>
              </select>
            )}
            {!modoLeitura && semCategoria > 0 && (
              <Btn size="sm" variant="outline" onClick={handleAutoCat}>⚡ Auto ({semCategoria})</Btn>
            )}
            {/* Indicador: filtros de coluna ativos */}
            {Object.values(filtrosColuna).some(s => s.size > 0) && (
              <button
                onClick={() => setFiltrosColuna({ conta: new Set(), formato: new Set(), macro: new Set(), categoria: new Set(), parcela: new Set() })}
                style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 10px', borderRadius: RADIUS.md, border: `1px solid ${C.brand}55`, background: C.brand + '18', color: C.brand, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", cursor: 'pointer', fontWeight: 600 }}
              >
                ☰ {Object.values(filtrosColuna).reduce((a, s) => a + s.size, 0)} filtro(s) de coluna · Limpar ✕
              </button>
            )}
            {/* Busca compacta — sempre na mesma linha */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '4px 8px' }}>
              <span style={{ color: C.textMuted, fontSize: 12 }}>🔍</span>
              <input placeholder="Buscar..." value={busca} onChange={e => setBusca(e.target.value)}
                style={{ background: 'transparent', border: 'none', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none', width: 110 }} />
              {busca && (
                <button onClick={() => setBusca('')} style={{ background: 'none', border: 'none', color: C.textMuted, cursor: 'pointer', fontSize: 12, padding: 0 }}>✕</button>
              )}
            </div>
          </div>

          {/* Barra de ações em lote */}
          {selecionados.size > 0 && !modoLeitura && (
            <div style={{ display: 'flex', gap: 10, marginBottom: 12, alignItems: 'center', background: C.brand + '18', border: `1px solid ${C.brand}44`, borderRadius: RADIUS.md, padding: '8px 14px' }}>
              <span style={{ fontSize: FONT.sm, fontWeight: 600, color: C.brand }}>{selecionados.size} selecionadas</span>
              <select defaultValue="" onChange={e => { if(e.target.value) categorizarSelecionados(e.target.value); e.target.value=''; }}
                style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.sm, padding: '5px 10px', color: C.text, fontSize: FONT.sm, fontFamily: "'Inter',sans-serif", outline: 'none' }}>
                <option value="">Categorizar selecionadas como...</option>
                {Object.entries(categoriasPorMacro).map(([grupo, cats]) =>
                  cats.length === 0 ? null : (
                    <optgroup key={grupo} label={grupo}>
                      {cats.map(c => <option key={c.id} value={c.id}>{c.nome}</option>)}
                    </optgroup>
                  )
                )}
              </select>
              <Btn size="sm" variant="ghost" onClick={deletarSelecionados} style={{ color: C.desp }}>✕ Deletar</Btn>
              <Btn size="sm" variant="ghost" onClick={() => setSelecionados(new Set())}>Limpar seleção</Btn>
            </div>
          )}

          {/* Tabela */}
          {transacoesFiltradas.length === 0 ? (
            <Card>
              <Empty icon="📄" title="Nenhuma transação encontrada"
                sub={transacoes.length === 0 ? 'Importe um arquivo CSV para começar' : 'Tente ajustar os filtros'} />
            </Card>
          ) : (
            <div style={{ background: C.card, borderRadius: RADIUS.lg, border: `1px solid ${C.border}`, overflow: 'hidden', width: '100%' }}>
              {/* Filtros sincronos — nenhum indicador necessario */}
              {/* Único container de scroll: horizontal + vertical — thead sticky garante alinhamento */}
              <div
                ref={virt.containerRef}
                style={{ overflowX: 'auto', overflowY: 'auto', maxHeight: 560, background: C.card, display: 'block', width: '100%' }}
              >
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: FONT.sm }}>
                  <colgroup>
                    <col style={{ width: 36, minWidth: 36 }} />
                    <col style={{ width: 110, minWidth: 110 }} />
                    <col style={{ width: 80, minWidth: 80 }} />
                    <col style={{ width: 90, minWidth: 90 }} />
                    <col />
                    <col style={{ width: 80, minWidth: 80 }} />
                    <col style={{ width: 120, minWidth: 120 }} />
                    <col style={{ width: 150, minWidth: 150 }} />
                    <col style={{ width: 70, minWidth: 70 }} />
                    {!modoLeitura && <col style={{ width: 80, minWidth: 80 }} />}
                  </colgroup>
                  <thead style={{ position: 'sticky', top: 0, zIndex: 2 }}>
                    <tr style={{ borderBottom: `1px solid ${C.border}`, background: C.bg }}>
                      <th style={{ padding: '10px 10px', width: 36, background: C.bg }}>
                        {!modoLeitura && (
                          <input type="checkbox"
                            checked={selecionados.size === transacoesFiltradas.length && transacoesFiltradas.length > 0}
                            onChange={toggleTodos} style={{ cursor: 'pointer', accentColor: C.brand }} />
                        )}
                      </th>
                      {/* Conta — com filtro por coluna (cascata) */}
                      <ColFilter label="Conta" valores={valoresCascata.contaCol}
                        selecionados={filtrosColuna.conta}
                        onChange={s => setFiltroCol('conta', s)} />
                      {/* Data — estático */}
                      <th style={{ padding: '10px 10px', textAlign: 'left', color: C.textMuted, fontWeight: 600, fontSize: FONT.xs, whiteSpace: 'nowrap', background: C.bg }}>Data</th>
                      {/* Valor — estático */}
                      <th style={{ padding: '10px 10px', textAlign: 'left', color: C.textMuted, fontWeight: 600, fontSize: FONT.xs, whiteSpace: 'nowrap', background: C.bg }}>Valor</th>
                      {/* Descrição — estático */}
                      <th style={{ padding: '10px 10px', textAlign: 'left', color: C.textMuted, fontWeight: 600, fontSize: FONT.xs, whiteSpace: 'nowrap', background: C.bg }}>Descrição</th>
                      {/* Formato — com filtro por coluna (cascata) */}
                      <ColFilter label="Formato" valores={valoresCascata.formatoCol}
                        selecionados={filtrosColuna.formato}
                        onChange={s => setFiltroCol('formato', s)} />
                      {/* Macro — com filtro por coluna (cascata) */}
                      <ColFilter label="Macro" valores={valoresCascata.macroCol}
                        selecionados={filtrosColuna.macro}
                        onChange={s => setFiltroCol('macro', s)} />
                      {/* Categoria — com filtro por coluna (cascata) */}
                      <ColFilter label="Categoria" valores={valoresCascata.categoriaCol}
                        selecionados={filtrosColuna.categoria}
                        onChange={s => setFiltroCol('categoria', s)}
                        categorias={categorias} />
                      {/* Parc. — com filtro por coluna */}
                      <ColFilter label="Parc." valores={valoresCascata.parcela}
                        selecionados={filtrosColuna.parcela}
                        onChange={s => setFiltroCol('parcela', s)}
                        numeric />
                      {/* Ações — oculto no modo cliente */}
                      {!modoLeitura && <th style={{ padding: '10px 10px', textAlign: 'right', color: C.textMuted, fontWeight: 600, fontSize: FONT.xs, whiteSpace: 'nowrap', background: C.bg }}>Ações</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {/* Virtualização desativada: todas as linhas renderizadas diretamente */}
                    {virt.visibleItems.map(({ item: t, index: i }) => {
                    const cat = catPorId.get(t.categoria);
                    // Macro da linha: usa macroTemp se o usuário já escolheu um, senão o do cat
                    const grupoAtual = macroTemp[t.id] !== undefined ? macroTemp[t.id] : (cat?.grupo || t.grupoImportado || '');
                    const catsDoGrupo = grupoAtual ? (categoriasPorMacro[grupoAtual] || []) : categoriasOrdenadas;
                    const sel = selecionados.has(t.id);
                    // Regra: já aprendeu manualmente OU já existe regra que cobre essa descrição
                    const jaAprendeu = aprendizadoOk[t.id] || transComRegra.has(t.id);
                    return (
                      <tr key={t.id} style={{
                        borderBottom: `1px solid ${C.border}20`,
                        background: sel ? C.brand + '18' : i % 2 === 0 ? 'transparent' : C.bg + '44',
                      }}>
                        {/* Checkbox */}
                        <td style={{ padding: '7px 10px', textAlign: 'center', width: 36 }}>
                          {!modoLeitura && (
                            <input type="checkbox" checked={sel} onChange={() => toggleSelecionar(t.id)}
                              style={{ cursor: 'pointer', accentColor: C.brand }} />
                          )}
                        </td>
                        {/* Conta */}
                        <td style={{ padding: '7px 10px', minWidth: 90, maxWidth: 130, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          <span style={{ fontSize: FONT.xs, color: C.textMuted }}>{t.conta || '—'}</span>
                        </td>
                        {/* Data */}
                        <td style={{ padding: '7px 10px', whiteSpace: 'nowrap', fontSize: FONT.xs }}>
                          <span style={{ color: C.textMuted }}>{t.data ? t.data.split('-').reverse().join('/') : '—'}</span>
                          {/* Competência: mês que vale para o dashboard */}
                          {(() => {
                            const periodo = t.competencia || (t.data ? t.data.slice(0, 7) : null);
                            if (!periodo) return null;
                            const [y, m] = periodo.split('-');
                            const ns = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
                            const label = `${ns[parseInt(m,10)-1]}/${y}`;
                            // Destaca em laranja se competência difere da data de compra
                            const diffComp = t.competencia && t.data && t.competencia !== t.data.slice(0, 7);
                            return (
                              <span style={{ display: 'block', fontSize: 10, color: diffComp ? C.yellow : C.brand + 'aa', fontWeight: 600 }}
                                title={diffComp ? `Competência: ${label} (difere da data de compra)` : `Competência: ${label}`}>
                                {label}{diffComp ? ' *' : ''}
                              </span>
                            );
                          })()}
                        </td>
                        {/* Valor */}
                        <td style={{ padding: '7px 10px', fontWeight: 600, color: t.tipo === 'receita' ? C.rec : t.tipo === 'neutro' ? C.textMuted : C.desp, whiteSpace: 'nowrap' }}>
                          {t.tipo === 'receita' ? '+' : t.tipo === 'despesa' ? '−' : ''}{fmtBRL(t.valor)}
                        </td>
                        {/* Descrição */}
                        <td title={t.descricao} style={{ padding: '7px 10px', color: C.text, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', cursor: 'default' }}>
                          {t.origem === 'whatsapp' && <span title="Lançado via WhatsApp" style={{ marginRight: 5, fontSize: 12 }}>📱</span>}
                          {t.descricao}
                        </td>
                        {/* Formato (Pix / Débito / Crédito / Dinheiro) */}
                        <td style={{ padding: '7px 8px', minWidth: 70 }}>
                          {t.formato ? (
                            <span style={{
                              fontSize: FONT.xs, fontWeight: 600, padding: '2px 7px',
                              borderRadius: 10, background: formatoColor(t.formato) + '22',
                              color: formatoColor(t.formato), whiteSpace: 'nowrap',
                            }}>{t.formato}</span>
                          ) : <span style={{ color: C.textMuted, fontSize: FONT.xs }}>—</span>}
                        </td>
                        {/* Macro – dropdown clicável sempre visível */}
                        <td style={{ padding: '7px 8px', minWidth: 120 }}>
                          {modoLeitura ? (
                            <span style={{ fontSize: FONT.xs, fontWeight: grupoAtual ? 700 : 400, color: grupoAtual ? grupoColor(grupoAtual) : C.textMuted }}>
                              {grupoAtual || '—'}
                            </span>
                          ) : (
                            <select
                              value={grupoAtual}
                              onChange={e => trocarMacroLinha(t.id, e.target.value)}
                              style={{
                                background: 'transparent',
                                border: `1px solid ${grupoAtual ? grupoColor(grupoAtual) + '55' : C.border}`,
                                borderRadius: 6,
                                padding: '3px 6px',
                                color: grupoAtual ? grupoColor(grupoAtual) : C.textMuted,
                                fontSize: FONT.xs,
                                fontFamily: "'Inter',sans-serif",
                                fontWeight: grupoAtual ? 700 : 400,
                                outline: 'none',
                                cursor: 'pointer',
                                width: '100%',
                              }}
                            >
                              <option value="">— macro —</option>
                              {Object.values(GRUPOS).map(g => <option key={g} value={g}>{g}</option>)}
                            </select>
                          )}
                        </td>
                        {/* Categoria */}
                        <td style={{ padding: '7px 8px', minWidth: 150 }}>
                          {modoLeitura ? (
                            <span style={{ fontSize: FONT.xs, fontWeight: t.categoria ? 700 : 400, color: t.categoria ? C.brand : C.textMuted }}>
                              {t.categoria ? (categorias.find(c => c.id === t.categoria)?.nome || '—') : '—'}
                            </span>
                          ) : (
                            <select
                              value={t.categoria || ''}
                              onChange={e => {
                                salvarInline(t.id, 'categoria', e.target.value || null);
                                setMacroTemp(prev => { const n = {...prev}; delete n[t.id]; return n; });
                              }}
                              style={{
                                background: 'transparent',
                                border: `1px solid ${t.categoria ? C.brand + '55' : C.yellow + '88'}`,
                                borderRadius: 6,
                                padding: '3px 6px',
                                color: t.categoria ? C.brand : C.yellow,
                                fontSize: FONT.xs,
                                fontFamily: "'Inter',sans-serif",
                                fontWeight: t.categoria ? 700 : 400,
                                outline: 'none',
                                cursor: 'pointer',
                                width: '100%',
                              }}
                            >
                              <option value="">— sem categoria —</option>
                              {catsDoGrupo.map(c => <option key={c.id} value={c.id}>{c.nome}</option>)}
                            </select>
                          )}
                        </td>
                        {/* Parcelas */}
                        <td style={{ padding: '7px 8px', whiteSpace: 'nowrap' }}>
                          {modoLeitura ? (
                            <span style={{ fontSize: FONT.xs, color: C.textMuted }}>{t.parcelaTotal ? `${t.parcelaAtual}/${t.parcelaTotal}` : '—'}</span>
                          ) : (
                            <input
                              type="number" min="1"
                              value={t.parcelaTotal || ''}
                              onChange={e => {
                                const n = parseInt(e.target.value) || null;
                                const novas = transacoes.map(tx => tx.id === t.id
                                  ? { ...tx, parcelaAtual: n ? 1 : null, parcelaTotal: n }
                                  : tx
                                );
                                setClienteAtivo({ ...clienteAtivo, transacoes: novas });
                              }}
                              placeholder="—"
                              title="Nº de parcelas (incluindo o mês atual)"
                              style={{ width: 44, background: C.bg, border: `1px solid ${C.border}`, borderRadius: 4, padding: '2px 4px', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none', textAlign: 'center' }}
                            />
                          )}
                        </td>
                        {/* Ações — oculto no modo cliente */}
                        {!modoLeitura && (
                          <td style={{ padding: '7px 10px', textAlign: 'right' }}>
                            <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                              <MiniBtn
                                onClick={() => !jaAprendeu && t.categoria && salvarAprendizado(t)}
                                title={
                                  jaAprendeu ? 'Regra já criada para esta descrição'
                                  : t.categoria ? 'Criar regra: próximas importações serão categorizadas automaticamente'
                                  : 'Categorize primeiro para criar regra'
                                }
                                style={{
                                  opacity: (!jaAprendeu && !t.categoria) ? 0.35 : 1,
                                  cursor: (jaAprendeu || !t.categoria) ? 'default' : 'pointer',
                                  background: jaAprendeu ? C.rec + '22' : 'transparent',
                                  borderColor: jaAprendeu ? C.rec : C.border,
                                  color: jaAprendeu ? C.rec : C.textMuted,
                                  fontSize: 13,
                                }}
                              >
                                {jaAprendeu ? '✓' : '🧠'}
                              </MiniBtn>
                              <MiniBtn onClick={() => setModalEditar({ ...t })}>✏️</MiniBtn>
                              <MiniBtn onClick={() => deletarTransacao(t.id)} danger>✕</MiniBtn>
                            </div>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                    {/* Spacer bottom: mantém a altura total do scroll */}

                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* ── ABA: REGRAS ──────────────────────────────────────────────────── */}
      {aba === 'regras' && (
        <>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
            <Btn size="sm" onClick={() => setModalRegra({ keyword: '', categoria: '', prioridade: 3 })}>+ Nova Regra</Btn>
          </div>
          <div style={{ background: C.card, borderRadius: RADIUS.lg, border: `1px solid ${C.border}`, overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: FONT.sm }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.border}`, background: C.bg }}>
                  {['Palavra-chave','Categoria','Prioridade','Ações'].map(h => (
                    <th key={h} style={{ padding: '10px 14px', textAlign: 'left', color: C.textMuted, fontWeight: 600, fontSize: FONT.xs }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[...regras].sort((a,b) => a.prioridade - b.prioridade).map((r, i) => {
                  const cat = catPorId.get(r.categoria);
                  return (
                    <tr key={r.id || i} style={{ borderBottom: `1px solid ${C.border}20` }}>
                      <td style={{ padding: '9px 14px', color: C.brand, fontFamily: 'monospace' }}>{r.keyword}</td>
                      <td style={{ padding: '9px 14px' }}>{cat ? <Badge color={C.brand}>{cat.nome}</Badge> : <Badge color={C.red}>{r.categoria}</Badge>}</td>
                      <td style={{ padding: '9px 14px', color: C.textMuted }}>{r.prioridade}</td>
                      <td style={{ padding: '9px 14px' }}>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <MiniBtn onClick={() => setModalRegra({ ...r })}>✏️</MiniBtn>
                          <MiniBtn onClick={() => setClienteAtivo({ ...clienteAtivo, regras: regras.filter(x => (x.id||x.keyword) !== (r.id||r.keyword)) })} danger>✕</MiniBtn>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* ── ABA: CATEGORIAS ─────────────────────────────────────────────────── */}
      {aba === 'categorias' && (
        <>
          {!modoLeitura && (
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 20 }}>
              <button onClick={() => setModalCategoria({ id: '', nome: '', grupo: Object.values(GRUPOS)[0], tipo: 'despesa' })} style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '10px 20px',
                borderRadius: 8, border: `2px solid ${C.rec}`, background: 'transparent',
                color: C.rec, fontWeight: 700, fontSize: FONT.base,
                fontFamily: "'Inter',sans-serif", cursor: 'pointer',
              }}>
                + Nova Categoria
              </button>
            </div>
          )}

          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            {Object.values(GRUPOS).filter(g => g !== GRUPOS.INTERNO).map(grupo => {
              const cats = categorias.filter(c => c.grupo === grupo);
              const corGrupo =
                grupo === GRUPOS.RECEITAS      ? C.rec
                : grupo === GRUPOS.FIXAS       ? C.grupoFixas
                : grupo === GRUPOS.CONSUMO     ? C.grupoConsumo
                : grupo === GRUPOS.DIVIDAS     ? C.grupoDividas
                : C.grupoInvestimentos;

              return (
                <Card key={grupo} padding="0" style={{ overflow: 'hidden' }}>
                  <div style={{ padding: '14px 20px', background: corGrupo + '18', borderBottom: `1px solid ${corGrupo}30`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontWeight: 700, color: corGrupo, fontSize: FONT.sm, textTransform: 'uppercase', letterSpacing: '0.07em' }}>
                      {grupo} <span style={{ fontWeight: 400, opacity: 0.7 }}>({cats.length})</span>
                    </span>
                    {!modoLeitura && (
                      <button onClick={() => setModalCategoria({ id: '', nome: '', grupo, tipo: grupo === GRUPOS.RECEITAS ? 'receita' : 'despesa' })} style={{
                        background: 'transparent', border: `1px solid ${corGrupo}60`, borderRadius: RADIUS.sm,
                        padding: '4px 12px', color: corGrupo, fontSize: FONT.xs, fontWeight: 600,
                        cursor: 'pointer', fontFamily: "'Inter',sans-serif",
                      }}>+ Adicionar</button>
                    )}
                  </div>

                  {cats.length === 0 ? (
                    <div style={{ padding: '16px 20px', color: C.textDim, fontSize: FONT.xs, fontStyle: 'italic' }}>Nenhuma categoria neste grupo.</div>
                  ) : (
                    <div>
                      {cats.map((cat, idx) => {
                        const qtdTrans = transacoes.filter(t => t.categoria === cat.id).length;
                        const isEditando = editandoCatNome === cat.id;
                        return (
                          <div key={cat.id}
                            style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 20px', borderBottom: idx < cats.length - 1 ? `1px solid ${C.border}18` : 'none', transition: 'background 0.12s' }}
                            onMouseEnter={e => e.currentTarget.style.background = C.brand + '08'}
                            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flex: 1 }}>
                              {isEditando ? (
                                <input autoFocus defaultValue={cat.nome}
                                  onBlur={e => renomearCategoria(cat.id, e.target.value)}
                                  onKeyDown={e => {
                                    if (e.key === 'Enter') renomearCategoria(cat.id, e.target.value);
                                    if (e.key === 'Escape') setEditandoCatNome(null);
                                  }}
                                  style={{ background: C.bg, border: `1px solid ${C.brand}`, borderRadius: RADIUS.sm, padding: '4px 10px', color: C.text, fontSize: FONT.sm, fontFamily: "'Inter',sans-serif", outline: 'none', width: 240 }}
                                />
                              ) : (
                                <span style={{ fontSize: FONT.sm, color: C.text, cursor: 'text' }}
                                  onDoubleClick={() => setEditandoCatNome(cat.id)}
                                  title="Clique duplo para renomear">
                                  {cat.nome}
                                </span>
                              )}
                              {qtdTrans > 0 && (
                                <span style={{ fontSize: FONT.xs, color: C.textDim, background: C.bg, borderRadius: RADIUS.full, padding: '1px 8px', border: `1px solid ${C.border}` }}>
                                  {qtdTrans} transa{qtdTrans === 1 ? 'ção' : 'ções'}
                                </span>
                              )}
                            </div>
                            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                              <span style={{ fontSize: FONT.xs, color: C.textDim, marginRight: 4 }}>{cat.tipo}</span>
                              {!modoLeitura && <MiniBtn onClick={() => setEditandoCatNome(cat.id)} title="Renomear">✏️</MiniBtn>}
                              {!modoLeitura && <MiniBtn danger onClick={() => setConfirmDeleteCat({ id: cat.id, nome: cat.nome, qtdTrans })} title="Excluir">🗑️</MiniBtn>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>

          {/* Modal de confirmação de exclusão */}
          {confirmDeleteCat && (
            <Modal open title="Excluir Categoria" onClose={() => setConfirmDeleteCat(null)}>
              <div style={{ fontSize: FONT.sm, color: C.text, lineHeight: 1.6 }}>
                <p>Tem certeza que deseja excluir <strong style={{ color: C.desp }}>{confirmDeleteCat.nome}</strong>?</p>
                {confirmDeleteCat.qtdTrans > 0 && (
                  <p style={{ color: C.yellow, marginTop: 12, background: C.bg, padding: '10px 14px', borderRadius: RADIUS.md, border: `1px solid ${C.yellow}40` }}>
                    ⚠️ Esta categoria tem <strong>{confirmDeleteCat.qtdTrans} transa{confirmDeleteCat.qtdTrans === 1 ? 'ção' : 'ções'}</strong> vinculada{confirmDeleteCat.qtdTrans > 1 ? 's' : ''}. Elas serão movidas para <em>sem categoria</em>.
                  </p>
                )}
              </div>
              <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 24 }}>
                <Btn variant="ghost" onClick={() => setConfirmDeleteCat(null)}>Cancelar</Btn>
                <Btn variant="danger" onClick={() => deletarCategoria(confirmDeleteCat.id)}>Excluir</Btn>
              </div>
            </Modal>
          )}
        </>
      )}

      {/* ── ABA: CONTAS ───────────────────────────────────────────────────── */}
      {aba === 'contas' && (
        <>
          {!modoLeitura && (
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
              <Btn size="sm" onClick={() => setModalConta({ id: '', nome: '', banco: '', tipo: 'corrente' })}>+ Nova Conta</Btn>
            </div>
          )}
          {contas.length === 0 ? (
            <Card><Empty icon="🏦" title="Nenhuma conta cadastrada" sub="As contas são criadas automaticamente ao importar um CSV" /></Card>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 14 }}>
              {contas.map(c => (
                <Card key={c.id} padding="16px 20px">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <div style={{ fontWeight: 700, color: C.text, marginBottom: 4 }}>{c.nome}</div>
                      <div style={{ fontSize: FONT.xs, color: C.textMuted }}>{c.banco || 'Banco não informado'} · {c.tipo}</div>
                      <div style={{ fontSize: FONT.xs, color: C.textDim, marginTop: 6 }}>
                        {transacoes.filter(t => t.conta === c.nome).length} transações
                      </div>
                    </div>
                    {!modoLeitura && (
                      <div style={{ display: 'flex', gap: 6 }}>
                        <MiniBtn onClick={() => setModalConta({ ...c })}>✏️</MiniBtn>
                        <MiniBtn onClick={() => setClienteAtivo({ ...clienteAtivo, contas: contas.filter(x => x.id !== c.id) })} danger>✕</MiniBtn>
                      </div>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </>
      )}

      {/* ── MODAL: Editar Transação ────────────────────────────────────────── */}
      {modalEditar && (
        <EditarTransacaoModal
          t={modalEditar}
          categorias={categorias}
          onSave={salvarEdicao}
          onClose={() => setModalEditar(null)}
        />
      )}

      {/* ── MODAL: Categoria ──────────────────────────────────────────────── */}
      {modalCategoria && (
        <Modal open title={modalCategoria.id ? 'Editar Categoria' : 'Nova Categoria'} onClose={() => setModalCategoria(null)}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <Input label="Nome" value={modalCategoria.nome} onChange={v => setModalCategoria(p => ({ ...p, nome: v }))} />
            <Select label="Grupo macro" value={modalCategoria.grupo} onChange={v => setModalCategoria(p => ({ ...p, grupo: v }))} options={gruposOpts} />
            <Select label="Tipo" value={modalCategoria.tipo} onChange={v => setModalCategoria(p => ({ ...p, tipo: v }))}
              options={[{ value: 'receita', label: 'Receita' }, { value: 'despesa', label: 'Despesa' }, { value: 'neutro', label: 'Neutro' }]} />
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
            <Btn variant="ghost" onClick={() => setModalCategoria(null)}>Cancelar</Btn>
            <Btn onClick={() => salvarCategoria(modalCategoria)} disabled={!modalCategoria.nome.trim()}>Salvar</Btn>
          </div>
        </Modal>
      )}

      {/* ── MODAL: Regra ──────────────────────────────────────────────────── */}
      {modalRegra && (
        <Modal open title={modalRegra.id ? 'Editar Regra' : 'Nova Regra'} onClose={() => setModalRegra(null)}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <Input label="Palavra-chave (case-insensitive)" value={modalRegra.keyword} onChange={v => setModalRegra(p => ({ ...p, keyword: v }))} placeholder="Ex: ifood" />
            <Select label="Categoria" value={modalRegra.categoria} onChange={v => setModalRegra(p => ({ ...p, categoria: v }))} options={catOpts} placeholder="Selecione..." />
            <Input label="Prioridade (1 = mais alta)" value={String(modalRegra.prioridade)} onChange={v => setModalRegra(p => ({ ...p, prioridade: parseInt(v) || 1 }))} type="number" />
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
            <Btn variant="ghost" onClick={() => setModalRegra(null)}>Cancelar</Btn>
            <Btn onClick={() => salvarRegra(modalRegra)} disabled={!modalRegra.keyword.trim() || !modalRegra.categoria}>Salvar</Btn>
          </div>
        </Modal>
      )}

      {/* ── MODAL: Conta ──────────────────────────────────────────────────── */}
      {modalConta && (
        <Modal open title={modalConta.id ? 'Editar Conta' : 'Nova Conta'} onClose={() => setModalConta(null)}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <Input label="Nome da conta" value={modalConta.nome} onChange={v => setModalConta(p => ({ ...p, nome: v }))} placeholder="Ex: Nubank Cartão" />
            <Input label="Banco" value={modalConta.banco} onChange={v => setModalConta(p => ({ ...p, banco: v }))} placeholder="Ex: Nubank" />
            <Select label="Tipo" value={modalConta.tipo} onChange={v => setModalConta(p => ({ ...p, tipo: v }))}
              options={[{ value: 'corrente', label: 'Conta Corrente' }, { value: 'cartao', label: 'Cartão de Crédito' }, { value: 'poupanca', label: 'Poupança' }, { value: 'investimento', label: 'Investimento' }]} />
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
            <Btn variant="ghost" onClick={() => setModalConta(null)}>Cancelar</Btn>
            <Btn onClick={() => {
              const novas = modalConta.id ? contas.map(c => c.id === modalConta.id ? modalConta : c) : [...contas, { ...modalConta, id: gerarId() }];
              setClienteAtivo({ ...clienteAtivo, contas: novas });
              setModalConta(null);
            }} disabled={!modalConta.nome.trim()}>Salvar</Btn>
          </div>
        </Modal>
      )}

      {/* ── MODAL: Revisão de importação PDF ─────────────────────────────── */}
      {modalRevisao && (
        <ModalRevisaoPDF
          dados={modalRevisao}
          categorias={categorias}
          regras={regras}
          onConfirmar={(ts) => confirmarImport(ts, modalRevisao.nomeConta)}
          onCancelar={() => setModalRevisao(null)}
          setClienteAtivo={setClienteAtivo}
          clienteAtivo={clienteAtivo}
        />
      )}

      {/* ── Overlay de carregamento ───────────────────────────────────────── */}
      {carregando && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 2000, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16 }}>
          <Spinner />
          <div style={{ color: C.text, fontSize: FONT.base }}>Processando PDF...</div>
          <div style={{ color: C.textMuted, fontSize: FONT.sm }}>Isso pode levar alguns segundos</div>
        </div>
      )}

      {/* ── Erro de importação ────────────────────────────────────────────── */}
      {erroImport && (
        <div style={{ position: 'fixed', bottom: 24, right: 24, background: C.despBg, border: `1px solid ${C.desp}`, borderRadius: RADIUS.md, padding: '14px 20px', zIndex: 1500, maxWidth: 400 }}>
          <div style={{ color: C.desp, fontWeight: 700, marginBottom: 6 }}>Erro na importação</div>
          <div style={{ color: C.text, fontSize: FONT.sm, marginBottom: 12 }}>{erroImport}</div>
          <Btn size="sm" variant="ghost" onClick={() => setErroImport(null)}>Fechar</Btn>
        </div>
      )}
    </div>
  );
}

// ── Sub-componentes ──────────────────────────────────────────────────────────
function EditarTransacaoModal({ t, categorias, onSave, onClose }) {
  const [form, setForm] = useState({ ...t });

  // Map id→cat memoizado para lookup O(1)
  const catMapModal = useMemo(() => {
    const m = new Map();
    for (const c of categorias) m.set(c.id, c);
    return m;
  }, [categorias]);

  const grupoForm = catMapModal.get(form.categoria)?.grupo || '';
  const [macroSel, setMacroSel] = useState(grupoForm);
  const catsDoMacro = useMemo(
    () => [...categorias]
      .filter(c => macroSel ? c.grupo === macroSel : true)
      .sort((a, b) => a.nome.localeCompare(b.nome, 'pt')),
    [categorias, macroSel]
  );

  return (
    <Modal open title="Editar Transação (completo)" onClose={onClose} width="540px">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Input label="Descrição" value={form.descricao} onChange={v => setForm(p => ({ ...p, descricao: v }))} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Input label="Data de Compra" value={form.data || ''} onChange={v => setForm(p => ({ ...p, data: v }))} type="date" />
          <div>
            <label style={{ fontSize: FONT.xs, color: C.textMuted, display: 'block', marginBottom: 5 }}>Competência</label>
            <input type="month" value={form.competencia || ''} onChange={e => setForm(p => ({ ...p, competencia: e.target.value }))}
              style={{ background: C.bg, border: `1px solid ${C.border}`, borderRadius: RADIUS.sm, padding: '8px 12px', color: C.text, fontSize: FONT.sm, fontFamily: "'Inter',sans-serif", outline: 'none', width: '100%', boxSizing: 'border-box' }} />
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Input label="Valor (R$)" value={String(form.valor)} onChange={v => setForm(p => ({ ...p, valor: parseFloat(v) || 0 }))} type="number" />
          <Select label="Tipo" value={form.tipo} onChange={v => setForm(p => ({ ...p, tipo: v }))}
            options={[{ value: 'receita', label: 'Receita' }, { value: 'despesa', label: 'Despesa' }, { value: 'neutro', label: 'Neutro' }]} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Select label="Macro Grupo" value={macroSel}
            onChange={v => { setMacroSel(v); setForm(p => ({ ...p, categoria: null })); }}
            options={[{ value: '', label: '— todos —' }, ...Object.values(GRUPOS).map(g => ({ value: g, label: g }))]} />
          <Select label="Categoria" value={form.categoria || ''} onChange={v => setForm(p => ({ ...p, categoria: v || null }))}
            options={[{ value: '', label: '— sem categoria —' }, ...catsDoMacro.map(c => ({ value: c.id, label: c.nome }))]} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Input label="Conta" value={form.conta || ''} onChange={v => setForm(p => ({ ...p, conta: v }))} />
          <Input label="Período (label)" value={form.periodoLabel || ''} onChange={v => setForm(p => ({ ...p, periodoLabel: v }))} placeholder="Ex: Dez/2024" />
        </div>
        <Input label="Subcategoria (opcional)" value={form.subcategoria || ''} onChange={v => setForm(p => ({ ...p, subcategoria: v }))} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Input label="Parcela atual" value={String(form.parcelaAtual || '')} onChange={v => setForm(p => ({ ...p, parcelaAtual: parseInt(v) || null }))} type="number" />
          <Input label="Total de parcelas" value={String(form.parcelaTotal || '')} onChange={v => setForm(p => ({ ...p, parcelaTotal: parseInt(v) || null }))} type="number" />
        </div>
      </div>
      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
        <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
        <Btn onClick={() => onSave(form)}>Salvar</Btn>
      </div>
    </Modal>
  );
}

function StatBox({ label, value, color }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '12px 16px' }}>
      <div style={{ fontSize: FONT.xs, color: C.textMuted, marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: FONT.xl, fontWeight: 700, color }}>{value}</div>
    </div>
  );
}

function TipoBadge({ tipo }) {
  const map = { receita: [C.rec, C.recBg, 'Receita'], despesa: [C.desp, C.despBg, 'Despesa'], neutro: [C.textMuted, C.card, 'Neutro'] };
  const [color, bg, label] = map[tipo] || map.neutro;
  return <Badge color={color} bg={bg}>{label}</Badge>;
}

function MiniBtn({ children, onClick, danger }) {
  return (
    <button onClick={onClick} style={{
      background: 'transparent', border: `1px solid ${C.border}`, borderRadius: RADIUS.sm,
      width: 26, height: 26, display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer', color: danger ? C.red : C.textMuted, fontSize: 11,
    }}>{children}</button>
  );
}

function grupoColor(grupo) {
  const map = {
    'Receitas': C.rec,
    'Despesas Fixas': C.desp,
    'Consumo Mensal': C.warn,
    'Dívidas': '#C084FC',
    'Investimentos': C.info,
    'Fluxo Interno': C.textMuted,
  };
  return map[grupo] || C.textMuted;
}

function formatoColor(formato) {
  const map = {
    'Pix':      '#00BFFF',
    'Débito':   '#A78BFA',
    'Crédito':  '#F97316',
    'Dinheiro': '#4ADE80',
    'TED':      '#60A5FA',
    'DOC':      '#60A5FA',
  };
  return map[formato] || C.textMuted;
}

// ── Modal de Revisão de PDF ───────────────────────────────────────────────────
function ModalRevisaoPDF({ dados, categorias, regras, onConfirmar, onCancelar, clienteAtivo, setClienteAtivo }) {
  const [transacoes, setTransacoes] = useState(dados.transacoes);
  const [nomeConta, setNomeConta]   = useState(dados.nomeConta);
  const [competencia, setCompetencia] = useState('');   // YYYY-MM global
  const [periodoLabel, setPeriodoLabel] = useState(''); // label texto
  const [abaRevisao, setAbaRevisao]   = useState('lista');
  const [selecionados, setSelecionados] = useState(new Set());
  const [macroLote, setMacroLote] = useState('');
  // Estado do macro selecionado por linha (fora do .map para não violar regra de hooks)
  const [macrosPorLinha, setMacrosPorLinha] = useState(() => {
    const catMap = new Map();
    for (const c of categorias) catMap.set(c.id, c);
    const init = {};
    dados.transacoes.forEach((t, i) => {
      init[i] = catMap.get(t.categoria)?.grupo || '';
    });
    return init;
  });

  const semCat = transacoes.filter(t => !t.categoria).length;
  const total  = transacoes.length;

  // categorias ordenadas por macro (para dropdowns) — memoizado
  const catsOrdenadas = useMemo(
    () => [...categorias].sort((a, b) => a.nome.localeCompare(b.nome, 'pt')),
    [categorias]
  );
  const catMapModal = useMemo(() => { const m = new Map(); for (const c of categorias) m.set(c.id, c); return m; }, [categorias]);
  const catsPorMacro = useMemo(() => {
    const mapa = {};
    for (const g of Object.values(GRUPOS)) mapa[g] = [];
    for (const c of catsOrdenadas) {
      if (mapa[c.grupo]) mapa[c.grupo].push(c);
      else mapa[c.grupo] = [c];
    }
    return mapa;
  }, [catsOrdenadas]);

  function editar(idx, campo, valor) {
    setTransacoes(ts => ts.map((t, i) =>
      i === idx
        ? {
            ...t,
            [campo]: valor,
            status: campo === 'categoria'
              ? (valor ? 'categorizado' : 'pendente')
              : t.status,
          }
        : t
    ));
  }
  function setMacroLinha(idx, novoMacro) {
    setMacrosPorLinha(prev => ({ ...prev, [idx]: novoMacro }));
    // Limpa categoria da linha ao trocar macro
    setTransacoes(ts => ts.map((t, i) =>
      i === idx ? { ...t, categoria: null, status: 'pendente' } : t
    ));
  }
  function remover(idx) { setTransacoes(ts => ts.filter((_, i) => i !== idx)); }

  function handleAutoCat() {
    setTransacoes(ts => ts.map(t => {
      if (t.categoria) return t;
      const desc = (t.descricao || '').toLowerCase();
      for (const r of [...regras].sort((a,b) => a.prioridade - b.prioridade)) {
        if (desc.includes(r.keyword.toLowerCase()))
          return { ...t, categoria: r.categoria, status: 'categorizado' };
      }
      return t;
    }));
  }

  function toggleSel(idx) {
    setSelecionados(prev => { const s = new Set(prev); s.has(idx) ? s.delete(idx) : s.add(idx); return s; });
  }
  function toggleTodos() {
    setSelecionados(selecionados.size === total ? new Set() : new Set(transacoes.map((_,i) => i)));
  }
  function categorizarLote(catId) {
    setTransacoes(ts => ts.map((t, i) =>
      selecionados.has(i) ? { ...t, categoria: catId, status: 'categorizado' } : t
    ));
    setSelecionados(new Set());
  }
  function deletarLote() {
    setTransacoes(ts => ts.filter((_, i) => !selecionados.has(i)));
    setSelecionados(new Set());
  }

  // ── Aprendizado na revisão ──────────────────────────────────────────────
  const [aprOkRevisao, setAprOkRevisao] = useState({}); // { [idx]: true } regra criada

  function extrairKeywordRevisao(descricao = '') {
    const limpo = descricao.trim()
      .replace(/\s*PARC\s+\d{1,2}\/\d{1,2}/gi, '')
      .replace(/\s+\d{1,2}\/\d{1,2}$/g, '')
      .replace(/\s+(BR|SP|RJ|MG|RS|SC|PR|BA|CE|GO|DF)$/gi, '')
      .replace(/\s+[A-Z]{2}\s*$/g, '')
      .trim();
    return limpo.split(/\s+/).filter(Boolean).slice(0, 3).join(' ').slice(0, 30).toLowerCase();
  }

  // Verifica se já existe regra cobrindo esta descrição (nas regras do cliente)
  function temRegraRevisao(t) {
    const desc = (t.descricao || '').toLowerCase();
    const regrasAtuais = clienteAtivo?.regras || [];
    return regrasAtuais.some(r => r.keyword && desc.includes(r.keyword.toLowerCase()));
  }

  // Salva regra imediatamente ao clicar 🧠 — sem modal
  function salvarAprenderRevisao(idx, t) {
    if (!t.categoria || !clienteAtivo) return;
    const keyword = extrairKeywordRevisao(t.descricao);
    if (!keyword) return;
    const regrasAtuais = clienteAtivo.regras || [];
    const jaExiste = regrasAtuais.find(r => r.keyword.toLowerCase() === keyword.toLowerCase());
    let novasRegras;
    if (jaExiste) {
      novasRegras = regrasAtuais.map(r =>
        r.keyword.toLowerCase() === keyword.toLowerCase()
          ? { ...r, categoria: t.categoria }
          : r
      );
    } else {
      novasRegras = [...regrasAtuais, { id: `r_${Date.now()}`, keyword, categoria: t.categoria, prioridade: 2 }];
    }
    setClienteAtivo({ ...clienteAtivo, regras: novasRegras });
    setAprOkRevisao(prev => ({ ...prev, [idx]: true }));
  }

  const catsLote = macroLote ? (catsPorMacro[macroLote] || []) : [];

  const inputStyle = { background: 'transparent', border: 'none', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none', width: '100%' };
  const selStyle = (hasVal) => ({ background: hasVal ? C.bg : C.yellowBg, border: `1px solid ${hasVal ? C.border : C.yellow}`, borderRadius: 4, padding: '2px 5px', color: hasVal ? C.text : C.yellow, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none', width: '100%' });

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', zIndex: 1000, display: 'flex', alignItems: 'stretch', justifyContent: 'center', padding: '16px' }}>
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.xl, width: '100%', maxWidth: 1100, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* ── Header ── */}
        <div style={{ padding: '18px 24px', borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
          <div>
            <div style={{ fontSize: FONT.lg, fontWeight: 800, color: C.text }}>Revisar Importação — PDF</div>
            <div style={{ fontSize: FONT.sm, color: C.textMuted, marginTop: 2 }}>
              <strong style={{ color: C.brand }}>{dados.banco}</strong> · {total} transações ·{' '}
              {semCat > 0 ? <span style={{ color: C.yellow }}>{semCat} sem categoria</span>
                          : <span style={{ color: C.rec }}>todas categorizadas ✓</span>}
            </div>
          </div>
          <button onClick={onCancelar} style={{ background: 'none', border: 'none', color: C.textMuted, fontSize: 22, cursor: 'pointer' }}>✕</button>
        </div>

        {/* ── Campos globais + abas ── */}
        <div style={{ padding: '10px 24px', borderBottom: `1px solid ${C.border}`, display: 'flex', gap: 12, alignItems: 'center', flexShrink: 0, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: FONT.xs, color: C.textMuted, whiteSpace: 'nowrap' }}>Conta:</span>
            <input value={nomeConta} onChange={e => setNomeConta(e.target.value)}
              style={{ background: C.bg, border: `1px solid ${C.border}`, borderRadius: 4, padding: '4px 8px', color: C.text, fontSize: FONT.sm, fontFamily: "'Inter',sans-serif", outline: 'none', width: 160 }} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: FONT.xs, color: C.textMuted, whiteSpace: 'nowrap' }}>Competência:</span>
            <input type="month" value={competencia} onChange={e => setCompetencia(e.target.value)}
              style={{ background: C.bg, border: `1px solid ${C.border}`, borderRadius: 4, padding: '4px 8px', color: C.text, fontSize: FONT.sm, fontFamily: "'Inter',sans-serif", outline: 'none' }} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: FONT.xs, color: C.textMuted, whiteSpace: 'nowrap' }}>Período (label):</span>
            <input value={periodoLabel} onChange={e => setPeriodoLabel(e.target.value)} placeholder="Ex: Dez/2024"
              style={{ background: C.bg, border: `1px solid ${C.border}`, borderRadius: 4, padding: '4px 8px', color: C.text, fontSize: FONT.sm, fontFamily: "'Inter',sans-serif", outline: 'none', width: 130 }} />
          </div>
          {semCat > 0 && <Btn size="sm" variant="outline" onClick={handleAutoCat}>⚡ Auto ({semCat})</Btn>}
          <div style={{ display: 'flex', gap: 4, marginLeft: 'auto' }}>
            {['lista','texto'].map(v => (
              <button key={v} onClick={() => setAbaRevisao(v)}
                style={{ padding: '4px 12px', borderRadius: 4, border: `1px solid ${C.border}`, background: abaRevisao === v ? C.brand : 'transparent', color: abaRevisao === v ? C.bg : C.textMuted, fontSize: FONT.xs, cursor: 'pointer', fontFamily: "'Inter',sans-serif", fontWeight: 600 }}>
                {v === 'lista' ? '📋 Transações' : '📄 Texto'}
              </button>
            ))}
          </div>
        </div>

        {/* ── Barra lote (aparece quando há seleção) ── */}
        {selecionados.size > 0 && !modoLeitura && (
          <div style={{ padding: '8px 24px', borderBottom: `1px solid ${C.border}`, display: 'flex', gap: 10, alignItems: 'center', flexShrink: 0, background: C.brand + '14', flexWrap: 'wrap' }}>
            <span style={{ fontSize: FONT.sm, fontWeight: 700, color: C.brand }}>{selecionados.size} selecionadas</span>
            <select value={macroLote} onChange={e => setMacroLote(e.target.value)}
              style={{ background: C.bg, border: `1px solid ${C.border}`, borderRadius: 4, padding: '4px 8px', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none' }}>
              <option value="">Filtrar macro...</option>
              {Object.values(GRUPOS).map(g => <option key={g} value={g}>{g}</option>)}
            </select>
            <select defaultValue="" onChange={e => { if(e.target.value) categorizarLote(e.target.value); e.target.value=''; }}
              style={{ background: C.bg, border: `1px solid ${C.border}`, borderRadius: 4, padding: '4px 8px', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none', minWidth: 200 }}>
              <option value="">Categorizar como...</option>
              {(macroLote ? catsLote : catsOrdenadas).map(c => (
                <option key={c.id} value={c.id}>{c.nome}</option>
              ))}
            </select>
            <Btn size="sm" variant="ghost" onClick={deletarLote} style={{ color: C.desp }}>✕ Deletar</Btn>
            <Btn size="sm" variant="ghost" onClick={() => setSelecionados(new Set())}>Limpar</Btn>
          </div>
        )}

        {/* ── Conteúdo ── */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '0' }}>
          {abaRevisao === 'texto' ? (
            <pre style={{ fontSize: 11, color: C.textMuted, fontFamily: 'monospace', whiteSpace: 'pre-wrap', lineHeight: 1.6, padding: '16px 24px' }}>
              {dados.textoOriginal || 'Texto não disponível'}
            </pre>
          ) : total === 0 ? (
            <div style={{ textAlign: 'center', padding: '48px', color: C.textMuted }}>
              <div style={{ fontSize: 36, marginBottom: 12 }}>⚠️</div>
              <div style={{ fontSize: FONT.base, fontWeight: 600, color: C.warn, marginBottom: 8 }}>Nenhuma transação detectada</div>
              <Btn variant="ghost" onClick={() => setAbaRevisao('texto')}>Ver texto extraído</Btn>
            </div>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: FONT.sm }}>
              <thead style={{ position: 'sticky', top: 0, zIndex: 2 }}>
                <tr style={{ borderBottom: `1px solid ${C.border}`, background: C.bg }}>
                  <th style={{ padding: '8px 10px', width: 32 }}>
                    <input type="checkbox" checked={selecionados.size === total && total > 0}
                      onChange={toggleTodos} style={{ cursor: 'pointer', accentColor: C.brand }} />
                  </th>
                  {['Conta','Data','Valor','Descrição','Macro','Categoria','Parc.','🧠',''].map(h => (
                    <th key={h} style={{ padding: '8px 10px', textAlign: 'left', color: C.textMuted, fontWeight: 600, fontSize: FONT.xs, whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {transacoes.map((t, i) => {
                  const catAtual = catMapModal.get(t.categoria);
                  const macroRow = macrosPorLinha[i] || catAtual?.grupo || t.grupoImportado || '';
                  const catsRow = macroRow ? (catsPorMacro[macroRow] || []) : catsOrdenadas;
                  const sel = selecionados.has(i);
                  return (
                    <tr key={i} style={{ borderBottom: `1px solid ${C.border}20`, background: sel ? C.brand + '18' : i % 2 ? C.bg + '44' : 'transparent' }}>
                      <td style={{ padding: '6px 10px', textAlign: 'center' }}>
                        <input type="checkbox" checked={sel} onChange={() => toggleSel(i)} style={{ cursor: 'pointer', accentColor: C.brand }} />
                      </td>
                      {/* Conta */}
                      <td style={{ padding: '6px 10px', minWidth: 80, maxWidth: 130 }}>
                        <input
                          value={t.conta || ''}
                          onChange={e => editar(i, 'conta', e.target.value)}
                          placeholder={nomeConta || 'conta'}
                          style={{ ...inputStyle, width: 110, color: C.text, fontSize: FONT.xs }}
                        />
                      </td>
                      {/* Data */}
                      <td style={{ padding: '6px 10px', color: C.textMuted, whiteSpace: 'nowrap', minWidth: 95 }}>
                        <input type="date" value={t.data || ''} onChange={e => editar(i,'data',e.target.value)} style={inputStyle} />
                      </td>
                      {/* Valor */}
                      <td style={{ padding: '6px 10px', whiteSpace: 'nowrap', minWidth: 90 }}>
                        <input type="number" value={t.valor || ''} onChange={e => editar(i,'valor', parseFloat(e.target.value)||0)}
                          style={{ ...inputStyle, color: t.tipo==='receita' ? C.rec : C.desp, fontWeight: 700, width: 80 }} />
                      </td>
                      {/* Descrição */}
                      <td style={{ padding: '6px 10px', minWidth: 200 }}>
                        <input value={t.descricao || ''} onChange={e => editar(i,'descricao',e.target.value)} style={inputStyle} />
                      </td>
                      {/* Macro */}
                      <td style={{ padding: '6px 10px', minWidth: 130 }}>
                        <select value={macroRow} onChange={e => setMacroLinha(i, e.target.value)}
                          style={{ background: C.bg, border: `1px solid ${C.border}`, borderRadius: 4, padding: '2px 5px', color: C.text, fontSize: FONT.xs, fontFamily: "'Inter',sans-serif", outline: 'none', width: '100%' }}>
                          <option value="">— macro —</option>
                          {Object.values(GRUPOS).map(g => <option key={g} value={g}>{g}</option>)}
                        </select>
                      </td>
                      {/* Categoria filtrada pelo macro da linha */}
                      <td style={{ padding: '6px 10px', minWidth: 160 }}>
                        <select value={t.categoria || ''} onChange={e => editar(i,'categoria',e.target.value || null)}
                          style={selStyle(!!t.categoria)}>
                          <option value="">— sem cat. —</option>
                          {catsRow.map(c => <option key={c.id} value={c.id}>{c.nome}</option>)}
                        </select>
                      </td>
                      {/* Parc. */}
                      <td style={{ padding: '6px 8px', textAlign: 'center', color: t.parcelaTotal ? C.brand : C.textMuted, fontSize: FONT.xs, fontWeight: t.parcelaTotal ? 700 : 400 }}>
                        {t.parcelaTotal ? `${t.parcelaTotal}x` : '—'}
                      </td>
                      {/* Aprender */}
                      <td style={{ padding: '6px 6px', textAlign: 'center' }}>
                        {(() => {
                          const jaAprendeuR = aprOkRevisao[i] || temRegraRevisao(t);
                          return (
                            <button
                              onClick={() => !jaAprendeuR && salvarAprenderRevisao(i, t)}
                              title={
                                jaAprendeuR ? 'Regra já criada para esta descrição'
                                : t.categoria ? 'Criar regra: próximas importações serão categorizadas automaticamente'
                                : 'Categorize primeiro para criar regra'
                              }
                              style={{
                                background: jaAprendeuR ? C.rec + '22' : 'transparent',
                                border: `1px solid ${jaAprendeuR ? C.rec : t.categoria ? C.border : C.border + '55'}`,
                                borderRadius: 4,
                                width: 26, height: 26,
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                cursor: (jaAprendeuR || !t.categoria) ? 'default' : 'pointer',
                                opacity: (!jaAprendeuR && !t.categoria) ? 0.3 : 1,
                                fontSize: 13,
                                color: jaAprendeuR ? C.rec : C.textMuted,
                              }}
                            >
                              {jaAprendeuR ? '✓' : '🧠'}
                            </button>
                          );
                        })()}
                      </td>
                      <td style={{ padding: '6px 10px' }}>
                        <button onClick={() => remover(i)} style={{ background: 'transparent', border: 'none', color: C.desp, cursor: 'pointer', fontSize: 14 }}>✕</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* ── Footer ── */}
        <div style={{ padding: '14px 24px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
          <div style={{ fontSize: FONT.sm, color: C.textMuted }}>
            {total} transações · <span style={{ color: C.rec }}>{total - semCat} categorizadas</span>
            {semCat > 0 && <span style={{ color: C.yellow }}> · {semCat} pendentes</span>}
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <Btn variant="ghost" onClick={onCancelar}>Cancelar</Btn>
            <Btn onClick={() => onConfirmar(transacoes.map(t => ({
              ...t,
              // XLSM: cada transação já carrega t.conta individual → preserva
              // PDF/CSV: usa nomeConta global como fallback
              conta: t.conta?.trim() || nomeConta,
              competencia: competencia || t.competencia || null,
              periodoLabel: periodoLabel || t.periodoLabel || nomeConta,
            })))} disabled={total === 0}>
              ✓ Confirmar e Importar ({total})
            </Btn>
          </div>
        </div>
      </div>
    </div>
  );
}
