import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { C, FONT, RADIUS } from '../design/tokens.js';
import { supabase } from '../lib/supabase.js';
import { APP_NAME, LOGO_URL } from '../lib/appConfig.js';
import ModalAcessos from '../components/ModalAcessos.jsx';

export default function PageManagerHub() {
  const {
    listarPlanejadores, criarPlanejador, renomearPlanejador,
    toggleAtivoPlanejador, resetarSenha, excluirPlanejador,
    logout, sessao,
  } = useAuth();

  const [planejadores, setPlanejadores] = useState([]);
  const [carregando, setCarregando]     = useState(true);
  const [erro, setErro]                 = useState('');

  // Modais
  const [modalNovo, setModalNovo]           = useState(false);
  const [modalRenomear, setModalRenomear]   = useState(null); // { id, nome }
  const [modalSenha, setModalSenha]         = useState(null); // { id, email, nome }
  const [modalExcluir, setModalExcluir]     = useState(null); // { id, nome }
  const [modalAcessar, setModalAcessar]     = useState(null); // planejador a acessar
  const [modalClientes, setModalClientes]   = useState(null); // planejador para ver clientes

  // Form novo planejador
  const [novoNome, setNovoNome]   = useState('');
  const [novoEmail, setNovoEmail] = useState('');
  const [novaSenha, setNovaSenha] = useState('');
  const [formErro, setFormErro]   = useState('');
  const [formLoad, setFormLoad]   = useState(false);

  // Form renomear
  const [renomearNome, setRenomearNome] = useState('');

  // Busca
  const [busca, setBusca] = useState('');

  const carregar = useCallback(async () => {
    setCarregando(true);
    try {
      const lista = await listarPlanejadores();
      setPlanejadores(lista);
    } catch (e) { setErro(e.message); }
    finally { setCarregando(false); }
  }, [listarPlanejadores]);

  useEffect(() => { carregar(); }, [carregar]);

  const planejadoresFiltrados = planejadores.filter(p =>
    p.nome.toLowerCase().includes(busca.toLowerCase()) ||
    p.email.toLowerCase().includes(busca.toLowerCase())
  );

  // ── Criar planejador ────────────────────────────────────────────────────────
  async function handleCriar(e) {
    e.preventDefault();
    setFormErro('');
    if (!novoNome.trim() || !novoEmail.trim() || !novaSenha) {
      setFormErro('Preencha todos os campos.'); return;
    }
    if (novaSenha.length < 6) { setFormErro('Senha deve ter ao menos 6 caracteres.'); return; }
    setFormLoad(true);
    try {
      await criarPlanejador({ nome: novoNome.trim(), email: novoEmail.trim().toLowerCase(), senha: novaSenha });
      setModalNovo(false); setNovoNome(''); setNovoEmail(''); setNovaSenha('');
      await carregar();
    } catch (e) { setFormErro(e.message); }
    finally { setFormLoad(false); }
  }

  // ── Renomear ────────────────────────────────────────────────────────────────
  async function handleRenomear(e) {
    e.preventDefault();
    if (!renomearNome.trim()) return;
    try {
      await renomearPlanejador(modalRenomear.id, renomearNome.trim());
      setModalRenomear(null);
      await carregar();
    } catch (e) { setErro(e.message); }
  }

  // ── Toggle ativo ────────────────────────────────────────────────────────────
  async function handleToggleAtivo(p) {
    try {
      await toggleAtivoPlanejador(p.id, !p.ativo);
      await carregar();
    } catch (e) { setErro(e.message); }
  }

  // ── Resetar senha ───────────────────────────────────────────────────────────
  async function handleResetarSenha() {
    try {
      await resetarSenha(modalSenha.email);
      alert(`Email de redefinição de senha enviado para ${modalSenha.email}`);
      setModalSenha(null);
    } catch (e) { setErro(e.message); }
  }

  // ── Excluir ─────────────────────────────────────────────────────────────────
  async function handleExcluir() {
    try {
      await excluirPlanejador(modalExcluir.id);
      setModalExcluir(null);
      await carregar();
    } catch (e) { setErro(e.message); }
  }

  const inputStyle = {
    width: '100%', boxSizing: 'border-box',
    background: C.bg, border: `1px solid ${C.border}`,
    borderRadius: RADIUS.md, padding: '9px 12px',
    color: C.text, fontSize: FONT.sm,
    fontFamily: "'Inter',sans-serif", outline: 'none',
  };

  const labelStyle = {
    fontSize: FONT.xs, color: C.textMuted,
    fontWeight: 600, display: 'block', marginBottom: 5,
  };

  return (
    <div style={{ minHeight: '100vh', background: C.bg, fontFamily: "'Inter',system-ui,sans-serif", color: C.text }}>

      {/* Header */}
      <div style={{ background: C.card, borderBottom: `1px solid ${C.border}`, padding: '0 32px', position: 'sticky', top: 0, zIndex: 50 }}>
        <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', alignItems: 'center', height: 52, gap: 16 }}>
          <img src={LOGO_URL} alt={APP_NAME} style={{ width: 30, height: 30, objectFit: 'contain' }} />
          <span style={{ fontSize: FONT.sm, fontWeight: 700, color: C.text }}>{APP_NAME}</span>
          <span style={{ fontSize: FONT.xs, color: C.brand, background: C.brand + '18', padding: '2px 10px', borderRadius: RADIUS.full, fontWeight: 600 }}>
            Manager
          </span>
          <div style={{ flex: 1 }} />
          <span style={{ fontSize: FONT.xs, color: C.textMuted }}>{sessao?.perfil?.nome}</span>
          <button onClick={logout} style={{ fontSize: FONT.xs, color: C.textMuted, background: 'transparent', border: `1px solid ${C.border}`, borderRadius: RADIUS.sm, padding: '4px 12px', cursor: 'pointer', fontFamily: "'Inter',sans-serif" }}>
            Sair
          </button>
        </div>
      </div>

      {/* Conteúdo */}
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '32px 32px' }}>

        {/* Título + ações */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 }}>
          <div>
            <div style={{ fontSize: FONT.xl, fontWeight: 800 }}>Painel Manager</div>
            <div style={{ fontSize: FONT.sm, color: C.textMuted, marginTop: 2 }}>Gerencie as contas dos Planejadores</div>
          </div>
          <button
            onClick={() => { setModalNovo(true); setFormErro(''); }}
            style={{
              background: C.brand, color: C.bg, border: 'none',
              borderRadius: RADIUS.md, padding: '10px 20px',
              fontSize: FONT.sm, fontWeight: 700,
              fontFamily: "'Inter',sans-serif", cursor: 'pointer',
            }}
          >+ Novo Planejador</button>
        </div>

        {/* Barra de busca */}
        <div style={{ marginBottom: 20 }}>
          <input
            value={busca} onChange={e => setBusca(e.target.value)}
            placeholder="Buscar por nome ou e-mail..."
            style={{ ...inputStyle, maxWidth: 360 }}
          />
        </div>

        {/* Erro global */}
        {erro && (
          <div style={{ background: C.desp + '18', border: `1px solid ${C.desp}44`, borderRadius: RADIUS.sm, padding: '10px 14px', fontSize: FONT.xs, color: C.desp, marginBottom: 16 }}>
            {erro} <button onClick={() => setErro('')} style={{ marginLeft: 8, color: C.desp, background: 'none', border: 'none', cursor: 'pointer', fontSize: FONT.xs }}>✕</button>
          </div>
        )}

        {/* Tabela de planejadores */}
        {carregando ? (
          <div style={{ color: C.textMuted, fontSize: FONT.sm, padding: '48px', textAlign: 'center' }}>Carregando...</div>
        ) : planejadoresFiltrados.length === 0 ? (
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '48px', textAlign: 'center', color: C.textMuted }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>👥</div>
            <div style={{ fontSize: FONT.base, fontWeight: 600, color: C.text, marginBottom: 8 }}>Nenhum Planejador cadastrado</div>
            <div style={{ fontSize: FONT.sm }}>Clique em "+ Novo Planejador" para criar a primeira conta.</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {planejadoresFiltrados.map(p => (
              <div key={p.id} style={{
                background: C.card, border: `1px solid ${C.border}`,
                borderRadius: RADIUS.md, padding: '16px 20px',
                display: 'flex', alignItems: 'center', gap: 16,
                opacity: p.ativo ? 1 : 0.5,
              }}>
                {/* Avatar */}
                <div style={{
                  width: 40, height: 40, borderRadius: '50%',
                  background: C.brand + '22', color: C.brand,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontWeight: 700, fontSize: FONT.base, flexShrink: 0,
                }}>
                  {p.nome.charAt(0).toUpperCase()}
                </div>

                {/* Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: FONT.sm, color: C.text }}>
                    {p.nome}
                    {!p.ativo && <span style={{ fontSize: FONT.xs, color: C.desp, marginLeft: 8, background: C.desp + '18', padding: '1px 8px', borderRadius: RADIUS.full }}>Desativado</span>}
                  </div>
                  <div style={{ fontSize: FONT.xs, color: C.textMuted, marginTop: 2 }}>{p.email}</div>
                  <div style={{ fontSize: 10, color: C.textDim, marginTop: 2 }}>
                    Criado em {new Date(p.criado_em).toLocaleDateString('pt-BR')}
                  </div>
                </div>

                {/* Ações */}
                <div style={{ display: 'flex', gap: 8, flexShrink: 0, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                  <ActionBtn color={C.brand} onClick={() => setModalAcessar(p)}>🔓 Acessar</ActionBtn>
                  <ActionBtn color="#A78BFA" onClick={() => setModalClientes(p)}>👥 Clientes</ActionBtn>
                  <ActionBtn onClick={() => { setModalRenomear(p); setRenomearNome(p.nome); }}>✏️ Renomear</ActionBtn>
                  <ActionBtn onClick={() => setModalSenha(p)}>🔑 Resetar senha</ActionBtn>
                  <ActionBtn onClick={() => handleToggleAtivo(p)}>
                    {p.ativo ? '🚫 Desativar' : '✅ Ativar'}
                  </ActionBtn>
                  <ActionBtn color={C.desp} onClick={() => setModalExcluir(p)}>🗑 Excluir</ActionBtn>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Modal Novo Planejador ─────────────────────────────────────────────── */}
      <ModalBase open={modalNovo} onClose={() => setModalNovo(false)} title="Novo Planejador">
        <form onSubmit={handleCriar} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <label style={labelStyle}>NOME</label>
            <input value={novoNome} onChange={e => setNovoNome(e.target.value)} placeholder="Ex: João Silva" style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>E-MAIL</label>
            <input type="email" value={novoEmail} onChange={e => setNovoEmail(e.target.value)} placeholder="joao@email.com" style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>SENHA INICIAL</label>
            <input type="password" value={novaSenha} onChange={e => setNovaSenha(e.target.value)} placeholder="Mínimo 6 caracteres" style={inputStyle} />
          </div>
          {formErro && <div style={{ fontSize: FONT.xs, color: C.desp }}>{formErro}</div>}
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 4 }}>
            <GhostBtn onClick={() => setModalNovo(false)}>Cancelar</GhostBtn>
            <PrimaryBtn type="submit" disabled={formLoad}>{formLoad ? 'Criando...' : 'Criar conta'}</PrimaryBtn>
          </div>
        </form>
      </ModalBase>

      {/* ── Modal Renomear ───────────────────────────────────────────────────── */}
      <ModalBase open={!!modalRenomear} onClose={() => setModalRenomear(null)} title="Renomear Planejador">
        <form onSubmit={handleRenomear} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <label style={labelStyle}>NOVO NOME</label>
            <input value={renomearNome} onChange={e => setRenomearNome(e.target.value)} placeholder="Nome do planejador" style={inputStyle} />
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <GhostBtn onClick={() => setModalRenomear(null)}>Cancelar</GhostBtn>
            <PrimaryBtn type="submit">Salvar</PrimaryBtn>
          </div>
        </form>
      </ModalBase>

      {/* ── Modal Resetar Senha ──────────────────────────────────────────────── */}
      <ModalBase open={!!modalSenha} onClose={() => setModalSenha(null)} title="Resetar Senha">
        <div style={{ fontSize: FONT.sm, color: C.textMuted, marginBottom: 20, lineHeight: 1.6 }}>
          Um e-mail de redefinição de senha será enviado para:<br />
          <strong style={{ color: C.text }}>{modalSenha?.email}</strong>
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <GhostBtn onClick={() => setModalSenha(null)}>Cancelar</GhostBtn>
          <PrimaryBtn onClick={handleResetarSenha}>Enviar e-mail</PrimaryBtn>
        </div>
      </ModalBase>

      {/* ── Modal Excluir ────────────────────────────────────────────────────── */}
      <ModalBase open={!!modalExcluir} onClose={() => setModalExcluir(null)} title="Excluir Planejador">
        <div style={{ fontSize: FONT.sm, color: C.textMuted, marginBottom: 20, lineHeight: 1.6 }}>
          Tem certeza que deseja excluir <strong style={{ color: C.text }}>{modalExcluir?.nome}</strong>?<br />
          <span style={{ color: C.desp, fontSize: FONT.xs }}>⚠️ Todos os clientes e dados serão permanentemente apagados.</span>
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <GhostBtn onClick={() => setModalExcluir(null)}>Cancelar</GhostBtn>
          <button
            onClick={handleExcluir}
            style={{ background: C.desp, color: '#fff', border: 'none', borderRadius: RADIUS.md, padding: '8px 18px', fontSize: FONT.sm, fontWeight: 700, fontFamily: "'Inter',sans-serif", cursor: 'pointer' }}
          >Excluir permanentemente</button>
        </div>
      </ModalBase>

      {/* ── Modal Clientes do Planejador ──────────────────────────────────────── */}
      <ModalClientes
        open={!!modalClientes}
        planejador={modalClientes}
        planejadores={planejadores}
        onClose={() => setModalClientes(null)}
        onReload={carregar}
      />

      {/* ── Modal Acessar Hub do Planejador ──────────────────────────────────── */}
      <ModalBase open={!!modalAcessar} onClose={() => setModalAcessar(null)} title="Acessar Hub">
        <div style={{ fontSize: FONT.sm, color: C.textMuted, marginBottom: 20, lineHeight: 1.6 }}>
          Você está prestes a acessar o hub de<br />
          <strong style={{ color: C.text, fontSize: FONT.base }}>{modalAcessar?.nome}</strong><br />
          <span style={{ fontSize: FONT.xs }}>Você verá todos os clientes e dados deste Planejador.</span>
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <GhostBtn onClick={() => setModalAcessar(null)}>Cancelar</GhostBtn>
          <PrimaryBtn onClick={() => {
            // Armazena qual planejador o Manager está visualizando
            // Usa localStorage para persistir através do reload (sessionStorage pode ser perdido)
            localStorage.setItem('manager_viewing', JSON.stringify({
              id: modalAcessar.id,
              nome: modalAcessar.nome,
              email: modalAcessar.email,
            }));
            window.location.href = '/'; // Força reload limpo
          }}>Acessar hub</PrimaryBtn>
        </div>
      </ModalBase>

    </div>
  );
}

// ── Componentes auxiliares ───────────────────────────────────────────────────

function ActionBtn({ children, onClick, color }) {
  const [hover, setHover] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        fontSize: FONT.xs, color: color || C.textMuted,
        background: hover ? (color || C.textMuted) + '15' : 'transparent',
        border: `1px solid ${(color || C.textMuted) + '44'}`,
        borderRadius: RADIUS.sm, padding: '5px 12px',
        cursor: 'pointer', fontFamily: "'Inter',sans-serif",
        transition: 'background .12s',
      }}
    >{children}</button>
  );
}

function ModalBase({ open, onClose, title, children }) {
  if (!open) return null;
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 1000,
      background: 'rgba(0,0,0,0.6)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 24,
    }} onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={{
        background: C.card, border: `1px solid ${C.border}`,
        borderRadius: RADIUS.lg, padding: '28px 28px',
        width: '100%', maxWidth: 440,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text }}>{title}</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: C.textMuted, cursor: 'pointer', fontSize: 18, lineHeight: 1 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function PrimaryBtn({ children, onClick, type = 'button', disabled }) {
  return (
    <button
      type={type} onClick={onClick} disabled={disabled}
      style={{
        background: disabled ? C.brand + '66' : C.brand,
        color: C.bg, border: 'none', borderRadius: RADIUS.md,
        padding: '8px 18px', fontSize: FONT.sm, fontWeight: 700,
        fontFamily: "'Inter',sans-serif",
        cursor: disabled ? 'not-allowed' : 'pointer',
      }}
    >{children}</button>
  );
}

function GhostBtn({ children, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        background: 'transparent', color: C.textMuted,
        border: `1px solid ${C.border}`, borderRadius: RADIUS.md,
        padding: '8px 18px', fontSize: FONT.sm,
        fontFamily: "'Inter',sans-serif", cursor: 'pointer',
      }}
    >{children}</button>
  );
}

// ── Modal Clientes do Planejador ─────────────────────────────────────────────
// Lista clientes com ações: Acessos, Migrar, Excluir
function ModalClientes({ open, planejador, planejadores, onClose, onReload }) {
  const [clientes, setClientes]         = useState([]);
  const [carregando, setCarregando]     = useState(false);
  const [erro, setErro]                 = useState('');

  // Sub-modal migrar
  const [modalMigrar, setModalMigrar]   = useState(null); // cliente a migrar
  const [destinoId, setDestinoId]       = useState('');
  const [migrando, setMigrando]         = useState(false);
  const [migrarErro, setMigrarErro]     = useState('');

  // Sub-modal excluir
  const [modalExcluir, setModalExcluir] = useState(null);
  const [excluindo, setExcluindo]       = useState(false);

  // Sub-modal acessos
  const [modalAcessos, setModalAcessos] = useState(null); // { id, nome }

  useEffect(() => {
    if (!open || !planejador) return;
    setErro('');
    carregar();
  }, [open, planejador]);

  async function carregar() {
    setCarregando(true);
    const { data, error } = await supabase
      .from('clientes')
      .select('id, nome')
      .eq('planejador_id', planejador.id)
      .order('nome');
    setCarregando(false);
    if (error) { setErro(error.message); return; }
    setClientes(data || []);
  }

  async function handleMigrar() {
    if (!destinoId) { setMigrarErro('Selecione o planejador de destino.'); return; }
    setMigrarErro(''); setMigrando(true);
    try {
      const { error } = await supabase
        .from('clientes')
        .update({ planejador_id: destinoId })
        .eq('id', modalMigrar.id)
        .eq('planejador_id', planejador.id);
      if (error) throw error;
      setModalMigrar(null); setDestinoId('');
      await carregar();
      onReload();
    } catch(e) { setMigrarErro(e.message); }
    finally { setMigrando(false); }
  }

  async function handleExcluir() {
    setExcluindo(true);
    try {
      const { error } = await supabase
        .from('clientes')
        .delete()
        .eq('id', modalExcluir.id);
      if (error) throw error;
      setModalExcluir(null);
      await carregar();
      onReload();
    } catch(e) { setErro(e.message); }
    finally { setExcluindo(false); }
  }

  if (!open) return null;

  const destinos = planejadores.filter(p => p.id !== planejador?.id);

  const inputSt = {
    width: '100%', boxSizing: 'border-box',
    background: C.bg, border: `1px solid ${C.border}`,
    borderRadius: RADIUS.md, padding: '9px 12px',
    color: C.text, fontSize: FONT.sm,
    fontFamily: "'Inter',sans-serif", outline: 'none',
  };

  return (
    <>
      <div style={{
        position: 'fixed', inset: 0, zIndex: 1000,
        background: 'rgba(0,0,0,0.65)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 24,
      }}
        onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      >
        <div style={{
          background: C.card, border: `1px solid ${C.border}`,
          borderRadius: RADIUS.lg, padding: '28px',
          width: '100%', maxWidth: 520,
          maxHeight: '90vh', display: 'flex', flexDirection: 'column',
        }}>
          {/* Cabeçalho */}
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
            <div>
              <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text }}>👥 Clientes</div>
              <div style={{ fontSize: FONT.xs, color: C.textMuted, marginTop: 3 }}>
                Planejador: <strong style={{ color: '#A78BFA' }}>{planejador?.nome}</strong>
              </div>
            </div>
            <button onClick={onClose} style={{ background: 'none', border: 'none', color: C.textMuted, cursor: 'pointer', fontSize: 18 }}>×</button>
          </div>

          {erro && (
            <div style={{ fontSize: FONT.xs, color: C.desp, background: C.desp + '15', padding: '8px 12px', borderRadius: RADIUS.sm, marginBottom: 14 }}>
              {erro}
            </div>
          )}

          {/* Lista */}
          <div style={{ flex: 1, overflowY: 'auto', border: `1px solid ${C.border}`, borderRadius: RADIUS.md }}>
            {carregando ? (
              <div style={{ padding: 24, textAlign: 'center', color: C.textMuted, fontSize: FONT.sm }}>Carregando...</div>
            ) : clientes.length === 0 ? (
              <div style={{ padding: 32, textAlign: 'center', color: C.textMuted, fontSize: FONT.sm }}>
                <div style={{ fontSize: 28, marginBottom: 8 }}>👤</div>
                Nenhum cliente cadastrado.
              </div>
            ) : clientes.map(c => (
              <div key={c.id} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '12px 16px', borderBottom: `1px solid ${C.border}`,
              }}>
                <div style={{
                  width: 34, height: 34, borderRadius: '50%',
                  background: '#A78BFA22', color: '#A78BFA',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontWeight: 700, fontSize: FONT.sm, flexShrink: 0,
                }}>
                  {c.nome.charAt(0).toUpperCase()}
                </div>
                <div style={{ flex: 1, fontSize: FONT.sm, color: C.text, fontWeight: 500 }}>{c.nome}</div>
                <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                  <SmallBtn onClick={() => setModalAcessos({ id: c.id, nome: c.nome })}>👤 Acessos</SmallBtn>
                  <SmallBtn onClick={() => { setModalMigrar(c); setDestinoId(''); setMigrarErro(''); }}>🔄 Migrar</SmallBtn>
                  <SmallBtn danger onClick={() => setModalExcluir(c)}>🗑</SmallBtn>
                </div>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
            <GhostBtn onClick={onClose}>Fechar</GhostBtn>
          </div>
        </div>
      </div>

      {/* Sub-modal: Migrar cliente */}
      {modalMigrar && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1100, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}
          onClick={e => { if (e.target === e.currentTarget) setModalMigrar(null); }}>
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.lg, padding: '28px', width: '100%', maxWidth: 400 }}>
            <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text, marginBottom: 4 }}>🔄 Migrar Cliente</div>
            <div style={{ fontSize: FONT.xs, color: C.textMuted, marginBottom: 16 }}>
              Transferir <strong style={{ color: C.text }}>{modalMigrar.nome}</strong> para outro planejador
            </div>
            <label style={{ fontSize: FONT.xs, color: C.textMuted, fontWeight: 600, display: 'block', marginBottom: 6 }}>PLANEJADOR DE DESTINO</label>
            <select value={destinoId} onChange={e => setDestinoId(e.target.value)} style={{ ...inputSt, marginBottom: 12 }}>
              <option value="">Selecione...</option>
              {destinos.map(p => <option key={p.id} value={p.id}>{p.nome} — {p.email}</option>)}
            </select>
            {migrarErro && <div style={{ fontSize: FONT.xs, color: C.desp, marginBottom: 10 }}>{migrarErro}</div>}
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <GhostBtn onClick={() => setModalMigrar(null)}>Cancelar</GhostBtn>
              <PrimaryBtn onClick={handleMigrar} disabled={migrando}>{migrando ? 'Migrando...' : 'Confirmar'}</PrimaryBtn>
            </div>
          </div>
        </div>
      )}

      {/* Sub-modal: Excluir cliente */}
      {modalExcluir && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1100, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}
          onClick={e => { if (e.target === e.currentTarget) setModalExcluir(null); }}>
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.lg, padding: '28px', width: '100%', maxWidth: 360 }}>
            <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text, marginBottom: 12 }}>Excluir Cliente</div>
            <div style={{ fontSize: FONT.sm, color: C.textMuted, marginBottom: 20, lineHeight: 1.6 }}>
              Tem certeza que deseja excluir <strong style={{ color: C.text }}>{modalExcluir.nome}</strong>?<br />
              <span style={{ fontSize: FONT.xs, color: C.desp }}>⚠️ Todos os dados financeiros serão apagados permanentemente.</span>
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <GhostBtn onClick={() => setModalExcluir(null)}>Cancelar</GhostBtn>
              <button
                onClick={handleExcluir} disabled={excluindo}
                style={{ background: excluindo ? C.desp + '66' : C.desp, color: '#fff', border: 'none', borderRadius: RADIUS.md, padding: '8px 18px', fontSize: FONT.sm, fontWeight: 700, fontFamily: "'Inter',sans-serif", cursor: excluindo ? 'not-allowed' : 'pointer' }}
              >{excluindo ? 'Excluindo...' : 'Excluir permanentemente'}</button>
            </div>
          </div>
        </div>
      )}

      {/* Sub-modal: Acessos do cliente */}
      <ModalAcessos
        open={!!modalAcessos}
        clienteId={modalAcessos?.id}
        clienteNome={modalAcessos?.nome}
        onClose={() => setModalAcessos(null)}
      />
    </>
  );
}

function SmallBtn({ children, onClick, danger }) {
  const [hov, setHov] = useState(false);
  const col = danger ? C.desp : C.textMuted;
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        fontSize: FONT.xs, color: col,
        background: hov ? col + '18' : 'transparent',
        border: `1px solid ${col + '44'}`,
        borderRadius: RADIUS.sm, padding: '4px 10px',
        cursor: 'pointer', fontFamily: "'Inter',sans-serif",
        transition: 'background .12s', whiteSpace: 'nowrap',
      }}
    >{children}</button>
  );
}

