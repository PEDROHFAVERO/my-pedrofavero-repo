import { useState } from 'react';
import { C, FONT, RADIUS } from '../design/tokens.js';
import { useHub } from '../context/AppContext.jsx';
import { APP_NAME, LOGO_URL } from '../lib/appConfig.js';
import { Btn, Card, Modal, Input, KPICard, SectionTitle, Empty } from '../components/UI.jsx';
import ModalAcessos from '../components/ModalAcessos.jsx';

export default function PageHub() {
  const { hub, criarCliente, abrirCliente, hubCarregado } = useHub();
  const [modalNovo, setModalNovo]       = useState(false);
  const [nome, setNome]                 = useState('');
  const [busca, setBusca]               = useState('');
  const [modalAcessos, setModalAcessos] = useState(null); // { id, nome }

  const clientesFiltrados = hub.clientes.filter(c =>
    c.nome.toLowerCase().includes(busca.toLowerCase())
  );

  function handleCriar() {
    if (!nome.trim()) return;
    criarCliente(nome.trim());
    setNome('');
    setModalNovo(false);
  }

  const totalClientes = hub.clientes.length;

  if (!hubCarregado) {
    return (
      <div style={{ minHeight: '100vh', background: C.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'Inter',sans-serif", color: C.textMuted, fontSize: FONT.sm }}>
        Carregando clientes...
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: C.bg, fontFamily: "'Inter', sans-serif", color: C.text }}>
      {/* Header */}
      <div style={{ borderBottom: `1px solid ${C.border}`, padding: '0 40px' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <img src={LOGO_URL} alt={APP_NAME} style={{ width: 40, height: 40, objectFit: 'contain' }} />
            <div>
              <div style={{ fontWeight: 800, fontSize: FONT.lg, color: C.text, lineHeight: 1 }}>{APP_NAME}</div>
              <div style={{ fontSize: FONT.xs, color: C.brand, fontWeight: 600 }}>Planejador Financeiro PF</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <Btn size="sm" onClick={() => setModalNovo(true)}>+ Novo Cliente</Btn>
          </div>
        </div>
      </div>

      {/* Conteúdo */}
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '36px 40px' }}>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 32 }}>
          <KPICard label="Total de Clientes" value={totalClientes} icon="👥" color={C.brand} />
          <KPICard
            label="Ativos este mês"
            value={hub.clientes.filter(c => {
              if (!c.atualizadoEm) return false;
              const d = new Date(c.atualizadoEm);
              const n = new Date();
              return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear();
            }).length}
            icon="📊"
            color={C.rec}
          />
          <KPICard
            label="Ano em Curso"
            value={new Date().getFullYear()}
            icon="📅"
            color={C.info}
          />
        </div>

        {/* Lista de clientes */}
        <SectionTitle
          title="Meus Clientes"
          sub={`${totalClientes} cliente${totalClientes !== 1 ? 's' : ''} cadastrado${totalClientes !== 1 ? 's' : ''}`}
        />

        {/* Busca */}
        {totalClientes > 0 && (
          <input
            placeholder="🔍  Buscar cliente..."
            value={busca}
            onChange={e => setBusca(e.target.value)}
            style={{
              background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md,
              padding: '10px 16px', color: C.text, fontSize: FONT.base,
              fontFamily: "'Inter', sans-serif", outline: 'none', width: '100%',
              boxSizing: 'border-box', marginBottom: 16,
            }}
          />
        )}

        {clientesFiltrados.length === 0 ? (
          <Card>
            <Empty
              icon="👤"
              title="Nenhum cliente ainda"
              sub='Clique em "+ Novo Cliente" para começar'
            />
          </Card>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
            {clientesFiltrados.map(c => (
              <ClienteCard
                key={c.id}
                cliente={c}
                onAbrir={() => abrirCliente(c.id)}
                onAcessos={e => { e.stopPropagation(); setModalAcessos({ id: c.id, nome: c.nome }); }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Modal Novo Cliente */}
      <Modal open={modalNovo} onClose={() => { setModalNovo(false); setNome(''); }} title="Novo Cliente">
        <Input label="Nome completo do cliente" value={nome} onChange={setNome} placeholder="Ex: João Silva" />
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
          <Btn variant="ghost" onClick={() => { setModalNovo(false); setNome(''); }}>Cancelar</Btn>
          <Btn onClick={handleCriar} disabled={!nome.trim()}>Criar Cliente</Btn>
        </div>
      </Modal>

      {/* Modal Acessos */}
      <ModalAcessos
        open={!!modalAcessos}
        clienteId={modalAcessos?.id}
        clienteNome={modalAcessos?.nome}
        onClose={() => setModalAcessos(null)}
      />
    </div>
  );
}

function ClienteCard({ cliente, onAbrir, onAcessos }) {
  const qtdTransacoes = cliente.transacoes?.length || 0;
  const ultimaAtualizacao = cliente.atualizadoEm
    ? new Date(cliente.atualizadoEm).toLocaleDateString('pt-BR')
    : '—';

  return (
    <Card onClick={onAbrir} style={{ position: 'relative' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
        <div style={{
          width: 44, height: 44, borderRadius: RADIUS.full, background: C.brand + '22',
          border: `2px solid ${C.brand}`, display: 'flex', alignItems: 'center',
          justifyContent: 'center', fontSize: FONT.lg, fontWeight: 800, color: C.brand,
        }}>
          {cliente.nome.charAt(0).toUpperCase()}
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <ActionBtn title="Gerenciar acessos" onClick={onAcessos}>👤 Acessos</ActionBtn>
        </div>
      </div>
      <div style={{ fontWeight: 700, fontSize: FONT.lg, color: C.text, marginBottom: 4 }}>{cliente.nome}</div>
      <div style={{ fontSize: FONT.sm, color: C.textMuted }}>
        {qtdTransacoes > 0
          ? `${qtdTransacoes} transações importadas`
          : 'Sem dados importados ainda'}
      </div>
      <div style={{ fontSize: FONT.xs, color: C.textDim, marginTop: 10 }}>
        Atualizado em {ultimaAtualizacao}
      </div>
    </Card>
  );
}

function ActionBtn({ children, onClick, title }) {
  const [hov, setHov] = useState(false);
  return (
    <button
      title={title}
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: hov ? C.brand + '18' : 'transparent',
        border: `1px solid ${hov ? C.brand : C.border}`,
        borderRadius: RADIUS.sm, padding: '5px 12px',
        display: 'flex', alignItems: 'center', gap: 5,
        cursor: 'pointer', color: hov ? C.brand : C.textMuted,
        fontSize: FONT.xs, fontFamily: "'Inter',sans-serif",
        transition: 'all .15s',
      }}
    >
      {children}
    </button>
  );
}
