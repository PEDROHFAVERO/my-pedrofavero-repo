import { useState, useMemo } from 'react';
import { C, FONT, RADIUS } from '../design/tokens.js';
import { useApp } from '../context/AppContext.jsx';
import { Btn, Card, SectionTitle, fmtBRL, Badge, ProgressBar, Modal, Input, Select } from '../components/UI.jsx';
import { GRUPOS, MESES, MESES_FULL } from '../data/categorias.js';
import { calcularMediasHistoricas, calcularParcelasFuturas, agruparPorMesCategoria } from '../utils/parser.js';
import { gerarPDFProjecao } from '../utils/gerarPDFProjecao.js';

export default function PagePlanejador() {
  const { clienteAtivo, setClienteAtivo, setPaginaAtual, modoLeitura } = useApp();
  const [mesAtivo, setMesAtivo] = useState(new Date().getMonth());
  const [modalCat, setModalCat] = useState(null); // para editar limite de categoria
  const [modalInicializar, setModalInicializar] = useState(false);
  const [modalSalvar, setModalSalvar] = useState(false);
  const [gerandoPDF, setGerandoPDF] = useState(false);

  if (!clienteAtivo) return null;
  const { transacoes, categorias, planejamento, anoAtivo } = clienteAtivo;

  const anoStr = String(anoAtivo);
  const planAno = planejamento?.[anoStr] || {};

  // ── Calcula médias históricas ─────────────────────────────────────────
  const medias = useMemo(() =>
    calcularMediasHistoricas(transacoes, categorias, anoAtivo),
  [transacoes, categorias, anoAtivo]);

  // ── Agrupa realizado por mês/categoria ────────────────────────────────
  const realizadoPorMes = useMemo(() =>
    agruparPorMesCategoria(transacoes, anoAtivo),
  [transacoes, anoAtivo]);

  // ── Parcelas futuras comprometidas ────────────────────────────────────
  const parcelasFuturas = useMemo(() =>
    calcularParcelasFuturas(transacoes, categorias, anoAtivo),
  [transacoes, categorias, anoAtivo]);

  // ── Inicializar projeção com médias históricas — apenas mês ativo ──────
  function inicializarComMedias() {
    const novoPlan = JSON.parse(JSON.stringify(planAno));
    if (!novoPlan[mesAtivo]) novoPlan[mesAtivo] = {};
    for (const cat of categorias) {
      novoPlan[mesAtivo][cat.id] = {
        projetado: Math.round(medias[cat.id] || 0),
        parcelas: parcelasFuturas[mesAtivo]?.[cat.id] || 0,
      };
    }
    setClienteAtivo({ ...clienteAtivo, planejamento: { ...planejamento, [anoStr]: novoPlan } });
    setModalInicializar(false);
  }

  // ── Inicializar projeção manual (valores zerados) — apenas mês ativo ──
  function inicializarManual() {
    const novoPlan = JSON.parse(JSON.stringify(planAno));
    if (!novoPlan[mesAtivo]) novoPlan[mesAtivo] = {};
    for (const cat of categorias) {
      novoPlan[mesAtivo][cat.id] = {
        projetado: 0,
        parcelas: parcelasFuturas[mesAtivo]?.[cat.id] || 0,
      };
    }
    setClienteAtivo({ ...clienteAtivo, planejamento: { ...planejamento, [anoStr]: novoPlan } });
    setModalInicializar(false);
  }

  // ── Replicar projeção do mês ativo para os meses seguintes até Dezembro ─────
  function replicarAteDezembroEFechar() {
    const novoPlan = JSON.parse(JSON.stringify(planAno));
    const origem = novoPlan[mesAtivo] || {};
    for (let m = mesAtivo + 1; m < 12; m++) {
      if (!novoPlan[m]) novoPlan[m] = {};
      for (const cat of categorias) {
        const projetadoOrigem = origem[cat.id]?.projetado ?? 0;
        if (!novoPlan[m][cat.id]) novoPlan[m][cat.id] = { projetado: 0, parcelas: parcelasFuturas[m]?.[cat.id] || 0 };
        novoPlan[m][cat.id].projetado = projetadoOrigem; // preserva parcelas do mês destino
      }
    }
    setClienteAtivo({ ...clienteAtivo, planejamento: { ...planejamento, [anoStr]: novoPlan } });
    setModalSalvar(false);
  }

  // ── Limpar projetado de todo o grupo no mês ativo ─────────────────────
  const [confirmLimpar, setConfirmLimpar] = useState(null); // grupo em confirmação

  function limparGrupoMes(grupo) {
    const cats = categorias.filter(c => c.grupo === grupo);
    const novoPlan = JSON.parse(JSON.stringify(planAno));
    if (!novoPlan[mesAtivo]) novoPlan[mesAtivo] = {};
    for (const cat of cats) {
      if (novoPlan[mesAtivo][cat.id]) {
        novoPlan[mesAtivo][cat.id].projetado = 0;
      }
    }
    setClienteAtivo({ ...clienteAtivo, planejamento: { ...planejamento, [anoStr]: novoPlan } });
    setConfirmLimpar(null);
  }

  // ── Atualiza limite de uma categoria num mês ──────────────────────────
  function atualizarLimite(mes, catId, valor) {
    const novoPlan = JSON.parse(JSON.stringify(planAno));
    if (!novoPlan[mes]) novoPlan[mes] = {};
    if (!novoPlan[mes][catId]) novoPlan[mes][catId] = { projetado: 0, parcelas: 0 };
    novoPlan[mes][catId].projetado = parseFloat(valor) || 0;
    setClienteAtivo({ ...clienteAtivo, planejamento: { ...planejamento, [anoStr]: novoPlan } });
  }

  // ── Dados do mês ativo ────────────────────────────────────────────────
  const planMes = planAno[mesAtivo] || {};
  const realizadoMes = realizadoPorMes[mesAtivo] || {};
  const parcelasMes = parcelasFuturas[mesAtivo] || {};

  // Verdadeiro apenas se o mês ativo já tem projeção lançada
  const temProjecao = planAno[mesAtivo] != null && Object.keys(planAno[mesAtivo] || {}).length > 0;

  // ── Totais por grupo ──────────────────────────────────────────────────
  function calcTotaisGrupo(grupo) {
    const cats = categorias.filter(c => c.grupo === grupo);
    let projetado = 0, realizado = 0, parcelas = 0;
    for (const c of cats) {
      projetado += planMes[c.id]?.projetado || 0;
      realizado += (realizadoMes[c.id]?.despesa || 0) + (realizadoMes[c.id]?.receita || 0);
      parcelas += parcelasMes[c.id] || planMes[c.id]?.parcelas || 0;
    }
    return { projetado, realizado, parcelas };
  }

  const gruposExibir = [GRUPOS.RECEITAS, GRUPOS.FIXAS, GRUPOS.CONSUMO, GRUPOS.DIVIDAS, GRUPOS.INVESTIMENTOS];

  const totalReceitas = calcTotaisGrupo(GRUPOS.RECEITAS).realizado;
  const totalDespesas = gruposExibir.slice(1).reduce((s, g) => s + calcTotaisGrupo(g).realizado, 0);
  const saldoMes = totalReceitas - totalDespesas;

  const totalReceitasProj = calcTotaisGrupo(GRUPOS.RECEITAS).projetado;
  const totalDespesasProj = gruposExibir.slice(1).reduce((s, g) => s + calcTotaisGrupo(g).projetado, 0);
  const saldoProj = totalReceitasProj - totalDespesasProj;

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1200, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <div style={{ fontSize: FONT.xl, fontWeight: 800, color: C.text }}>Planejador Financeiro</div>
          <div style={{ fontSize: FONT.sm, color: C.textMuted }}>{clienteAtivo.nome} · {anoAtivo}</div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 10, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
          {!modoLeitura && (
            <Btn size="sm" onClick={() => setModalInicializar(true)}>🚀 Iniciar Projeção</Btn>
          )}
          {!modoLeitura && temProjecao && (
            <Btn size="sm" onClick={() => setModalSalvar(true)}>💾 Salvar Projeção</Btn>
          )}
          {!modoLeitura && temProjecao && (
            <button
              disabled={gerandoPDF}
              onClick={async () => {
                setGerandoPDF(true);
                try {
                  await gerarPDFProjecao({
                    cliente:          clienteAtivo,
                    mesAtivo,
                    planAno,
                    realizadoPorMes,
                    parcelasFuturas,
                  });
                } catch (e) {
                  console.error('Erro ao gerar PDF:', e);
                  alert('Erro ao gerar PDF. Verifique o console.');
                } finally {
                  setGerandoPDF(false);
                }
              }}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '7px 14px', borderRadius: RADIUS.md,
                background: gerandoPDF ? C.brand + '66' : C.brand,
                color: C.bg, border: 'none',
                fontWeight: 700, fontSize: FONT.sm,
                fontFamily: "'Inter',sans-serif",
                cursor: gerandoPDF ? 'not-allowed' : 'pointer',
                opacity: gerandoPDF ? 0.7 : 1,
                transition: 'opacity .15s',
              }}
            >
              {gerandoPDF ? '⏳ Gerando...' : '📄 Gerar PDF'}
            </button>
          )}
        </div>
      </div>

      {/* Seletor de mês */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 24, flexWrap: 'wrap' }}>
        {MESES.map((m, i) => (
          <button key={i} onClick={() => setMesAtivo(i)}
            style={{
              padding: '7px 14px', borderRadius: RADIUS.md, border: 'none',
              background: mesAtivo === i ? C.brand : C.card,
              color: mesAtivo === i ? C.bg : C.textMuted,
              fontWeight: mesAtivo === i ? 700 : 500,
              fontSize: FONT.sm, cursor: 'pointer', fontFamily: "'Inter',sans-serif",
              border: `1px solid ${mesAtivo === i ? C.brand : C.border}`,
            }}
          >{m}</button>
        ))}
      </div>

      {/* KPIs do mês */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 28 }}>
        <KPIBox label="Receitas Projetadas" value={fmtBRL(totalReceitasProj)} color={C.rec} />
        <KPIBox label="Despesas Projetadas" value={fmtBRL(totalDespesasProj)} color={C.desp} />
        <KPIBox label="Saldo Projetado" value={fmtBRL(saldoProj)} color={saldoProj >= 0 ? C.rec : C.desp} />
        <KPIBox label="Saldo Realizado" value={fmtBRL(saldoMes)} color={saldoMes >= 0 ? C.rec : C.desp} />
      </div>

      {!temProjecao ? (
        <Card>
          <div style={{ textAlign: 'center', padding: '48px', color: C.textMuted }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>📊</div>
            <div style={{ fontSize: FONT.lg, fontWeight: 600, color: C.text, marginBottom: 8 }}>
              Projeção não inicializada
            </div>
            <div style={{ fontSize: FONT.sm, marginBottom: 20 }}>
              {transacoes.length > 0
                ? `Clique em "Iniciar Projeção" para preencher ${MESES_FULL[mesAtivo]} automaticamente com a média do histórico, ou construir manualmente.`
                : 'Importe transações no Fluxo Financeiro primeiro, ou inicialize manualmente.'}
            </div>
            {!modoLeitura && <Btn onClick={() => setModalInicializar(true)}>🚀 Iniciar Projeção</Btn>}
          </div>
        </Card>
      ) : (
        /* Tabela de planejamento por grupo */
        gruposExibir.map(grupo => {
          const cats = categorias.filter(c => c.grupo === grupo);
          if (!cats.length) return null;
          const totais = calcTotaisGrupo(grupo);
          const isReceita = grupo === GRUPOS.RECEITAS;

          return (
            <div key={grupo} style={{ marginBottom: 20 }}>
              {/* Header do grupo */}
              <div style={{
                background: grupoColor(grupo) + '15',
                border: `1px solid ${grupoColor(grupo)}40`,
                borderRadius: `${RADIUS.md} ${RADIUS.md} 0 0`,
                padding: '10px 16px',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              }}>
                <span style={{ fontWeight: 700, color: grupoColor(grupo), fontSize: FONT.base }}>
                  {grupo}
                </span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 20, fontSize: FONT.sm }}>
                  <span style={{ color: C.textMuted }}>Projetado: <strong style={{ color: C.text }}>{fmtBRL(totais.projetado)}</strong></span>
                  <span style={{ color: C.textMuted }}>Realizado: <strong style={{ color: isReceita ? C.rec : C.desp }}>{fmtBRL(totais.realizado)}</strong></span>
                  {totais.parcelas > 0 && (
                    <span style={{ color: C.textMuted }}>Parcelas: <strong style={{ color: '#C084FC' }}>{fmtBRL(totais.parcelas)}</strong></span>
                  )}
                  {/* Botão limpar grupo no mês ativo */}
                  {!modoLeitura && temProjecao && (
                    confirmLimpar === grupo ? (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontSize: FONT.xs, color: C.textMuted }}>Zerar {MESES[mesAtivo]}?</span>
                        <button
                          onClick={() => limparGrupoMes(grupo)}
                          style={{ fontSize: FONT.xs, fontWeight: 700, color: C.red, background: C.red + '18', border: `1px solid ${C.red}55`, borderRadius: RADIUS.sm, padding: '3px 10px', cursor: 'pointer', fontFamily: "'Inter',sans-serif" }}
                        >Confirmar</button>
                        <button
                          onClick={() => setConfirmLimpar(null)}
                          style={{ fontSize: FONT.xs, color: C.textMuted, background: 'transparent', border: `1px solid ${C.border}`, borderRadius: RADIUS.sm, padding: '3px 8px', cursor: 'pointer', fontFamily: "'Inter',sans-serif" }}
                        >Cancelar</button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setConfirmLimpar(grupo)}
                        style={{ fontSize: FONT.xs, color: grupoColor(grupo), background: 'transparent', border: `1px solid ${grupoColor(grupo)}44`, borderRadius: RADIUS.sm, padding: '3px 10px', cursor: 'pointer', fontFamily: "'Inter',sans-serif", opacity: 0.6, transition: 'opacity .15s' }}
                        onMouseEnter={e => e.currentTarget.style.opacity = 1}
                        onMouseLeave={e => e.currentTarget.style.opacity = 0.6}
                      >🗑 Limpar</button>
                    )
                  )}
                </div>
              </div>

              {/* Linhas de categoria */}
              <div style={{ background: C.card, border: `1px solid ${grupoColor(grupo)}40`, borderTop: 'none', borderRadius: `0 0 ${RADIUS.md} ${RADIUS.md}`, overflow: 'hidden' }}>
                {cats.map((cat, idx) => {
                  const proj = planMes[cat.id]?.projetado || 0;
                  const parc = parcelasMes[cat.id] || planMes[cat.id]?.parcelas || 0;
                  const real = isReceita
                    ? (realizadoMes[cat.id]?.receita || 0)
                    : (realizadoMes[cat.id]?.despesa || 0);
                  const livre = proj - parc - real;
                  const pct = proj > 0 ? ((real + parc) / proj) * 100 : 0;

                  return (
                    <div key={cat.id} style={{
                      display: 'grid',
                      gridTemplateColumns: '200px 130px 130px 130px 130px 1fr 50px',
                      alignItems: 'center',
                      padding: '10px 16px',
                      borderTop: idx > 0 ? `1px solid ${C.border}30` : 'none',
                      background: idx % 2 === 0 ? 'transparent' : C.bg + '44',
                      gap: 8,
                    }}>
                      <span style={{ fontSize: FONT.sm, color: C.text, fontWeight: 500 }}>{cat.nome}</span>

                      {/* Projetado editável */}
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        {modoLeitura ? (
                          <span style={{ fontSize: FONT.sm, color: C.text }}>{fmtBRL(proj)}</span>
                        ) : (
                          <input
                            type="number"
                            value={proj || ''}
                            onChange={e => atualizarLimite(mesAtivo, cat.id, e.target.value)}
                            placeholder="0"
                            style={{
                              width: '100%', background: C.bg, border: `1px solid ${C.border}`,
                              borderRadius: RADIUS.sm, padding: '5px 8px', color: C.text,
                              fontSize: FONT.sm, fontFamily: "'Inter',sans-serif", outline: 'none',
                            }}
                          />
                        )}
                      </div>

                      {/* Parcelas comprometidas */}
                      <span style={{ fontSize: FONT.sm, color: parc > 0 ? '#C084FC' : C.textDim, fontWeight: parc > 0 ? 600 : 400 }}>
                        {parc > 0 ? fmtBRL(parc) : '—'}
                      </span>

                      {/* Realizado */}
                      <span style={{ fontSize: FONT.sm, fontWeight: 600, color: isReceita ? C.rec : C.desp }}>
                        {real > 0 ? fmtBRL(real) : '—'}
                      </span>

                      {/* Livre */}
                      <span style={{ fontSize: FONT.sm, fontWeight: 600, color: livre >= 0 ? C.green : C.red }}>
                        {proj > 0 ? fmtBRL(livre) : '—'}
                      </span>

                      {/* Barra semáforo */}
                      <ProgressBar value={real + parc} max={proj} height={5} />

                      {/* Semáforo ícone */}
                      <span style={{ fontSize: 14, textAlign: 'center' }}>
                        {proj === 0 ? '⚪' : pct >= 100 ? '🔴' : pct >= 85 ? '🟡' : '🟢'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })
      )}

      {/* Legenda */}
      {temProjecao && (
        <div style={{ display: 'flex', gap: 20, marginTop: 20, fontSize: FONT.xs, color: C.textMuted, flexWrap: 'wrap' }}>
          <span>📝 <strong style={{ color: C.text }}>Projetado</strong> = limite definido</span>
          <span>💜 <strong style={{ color: '#C084FC' }}>Parcelas</strong> = já comprometido em parcelamentos</span>
          <span>💸 <strong style={{ color: C.desp }}>Realizado</strong> = efetivamente gasto</span>
          <span>✅ <strong style={{ color: C.green }}>Livre</strong> = projetado − parcelas − realizado</span>
        </div>
      )}

      {/* Modal — escolha do tipo de projeção */}
      <Modal open={modalInicializar} onClose={() => setModalInicializar(false)} title="Iniciar Projeção" width="500px">
        <div style={{ color: C.textMuted, fontSize: FONT.sm, marginBottom: 20 }}>
          Escolha como deseja construir a projeção de <strong style={{ color: C.text }}>{anoAtivo}</strong>:
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>

          {/* Opção 1 — Médias históricas */}
          <button
            onClick={transacoes.length > 0 ? inicializarComMedias : undefined}
            disabled={transacoes.length === 0}
            style={{
              display: 'flex', alignItems: 'flex-start', gap: 16,
              background: transacoes.length > 0 ? C.brand + '15' : C.bg,
              border: `2px solid ${transacoes.length > 0 ? C.brand : C.border}`,
              borderRadius: RADIUS.md, padding: '16px 18px',
              cursor: transacoes.length > 0 ? 'pointer' : 'not-allowed',
              opacity: transacoes.length === 0 ? 0.45 : 1,
              textAlign: 'left', width: '100%', fontFamily: "'Inter',sans-serif",
              transition: 'border-color .15s',
            }}
          >
            <span style={{ fontSize: 28, lineHeight: 1 }}>⚡</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: FONT.base, color: C.text, marginBottom: 4 }}>
                Usar Médias Históricas
              </div>
              <div style={{ fontSize: FONT.xs, color: C.textMuted, lineHeight: 1.5 }}>
                {transacoes.length > 0
                  ? `Projeção preenchida automaticamente com a média dos ${transacoes.length} lançamentos já importados. Você poderá ajustar depois.`
                  : 'Nenhuma transação importada ainda. Importe dados no Fluxo Financeiro para usar esta opção.'}
              </div>
              {transacoes.length > 0 && (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
                  {Object.entries(medias).slice(0, 5).map(([catId, media]) => {
                    const cat = clienteAtivo.categorias.find(c => c.id === catId);
                    return cat ? (
                      <span key={catId} style={{ fontSize: 10, background: C.brand + '22', color: C.brand, borderRadius: 20, padding: '2px 8px', fontWeight: 600 }}>
                        {cat.nome}: {fmtBRL(media)}
                      </span>
                    ) : null;
                  })}
                  {Object.keys(medias).length > 5 && (
                    <span style={{ fontSize: 10, color: C.textMuted }}>+{Object.keys(medias).length - 5} mais...</span>
                  )}
                </div>
              )}
            </div>
          </button>

          {/* Opção 2 — Manual */}
          <button
            onClick={inicializarManual}
            style={{
              display: 'flex', alignItems: 'flex-start', gap: 16,
              background: C.bg,
              border: `2px solid ${C.border}`,
              borderRadius: RADIUS.md, padding: '16px 18px',
              cursor: 'pointer', textAlign: 'left', width: '100%',
              fontFamily: "'Inter',sans-serif", transition: 'border-color .15s',
            }}
            onMouseEnter={e => e.currentTarget.style.borderColor = C.textMuted}
            onMouseLeave={e => e.currentTarget.style.borderColor = C.border}
          >
            <span style={{ fontSize: 28, lineHeight: 1 }}>✏️</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: FONT.base, color: C.text, marginBottom: 4 }}>
                Construir Manualmente
              </div>
              <div style={{ fontSize: FONT.xs, color: C.textMuted, lineHeight: 1.5 }}>
                Projeção iniciada com todos os valores zerados. Você preenche cada categoria no seu ritmo, mês a mês.
              </div>
            </div>
          </button>
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <Btn variant="ghost" onClick={() => setModalInicializar(false)}>Cancelar</Btn>
        </div>
      </Modal>

      {/* Modal — salvar projeção / replicar para meses seguintes */}
      <Modal open={modalSalvar} onClose={() => setModalSalvar(false)} title="Salvar Projeção" width="420px">
        <div style={{ color: C.textMuted, fontSize: FONT.sm, marginBottom: 24, lineHeight: 1.6 }}>
          Deseja replicar os valores projetados de{' '}
          <strong style={{ color: C.text }}>{MESES_FULL[mesAtivo]}</strong> para os próximos meses também?
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
          <Btn
            onClick={replicarAteDezembroEFechar}
            disabled={mesAtivo === 11}
            style={{ opacity: mesAtivo === 11 ? 0.4 : 1, width: '100%' }}
          >
            ✅ Sim, replicar até Dezembro
          </Btn>
          <Btn variant="ghost" style={{ width: '100%' }} onClick={() => setModalSalvar(false)}>
            ❌ Não, salvar só este mês
          </Btn>
        </div>

        <div style={{ textAlign: 'center' }}>
          <button
            onClick={() => setModalSalvar(false)}
            style={{ fontSize: FONT.xs, color: C.textMuted, background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'Inter',sans-serif" }}
          >Cancelar</button>
        </div>
      </Modal>
    </div>
  );
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function KPIBox({ label, value, color }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '14px 18px' }}>
      <div style={{ fontSize: FONT.xs, color: C.textMuted, marginBottom: 6, fontWeight: 500 }}>{label}</div>
      <div style={{ fontSize: FONT.xl, fontWeight: 700, color }}>{value}</div>
    </div>
  );
}

function grupoColor(grupo) {
  const map = {
    'Receitas': C.rec,
    'Despesas Fixas': C.desp,
    'Consumo Mensal': C.warn,
    'Dívidas': '#C084FC',
    'Investimentos': C.info,
    'Fluxo Interno': C.textMuted,
  };
  return map[grupo] || C.textMuted;
}
