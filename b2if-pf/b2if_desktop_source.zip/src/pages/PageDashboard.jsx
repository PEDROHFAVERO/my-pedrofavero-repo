import { useState, useMemo, useRef, useCallback } from 'react';
import { C, FONT, RADIUS } from '../design/tokens.js';
import { useApp } from '../context/AppContext.jsx';
import { Btn, Card, fmtBRL, ProgressBar } from '../components/UI.jsx';
import { GRUPOS, MESES, MESES_FULL } from '../data/categorias.js';
import { agruparPorMesCategoria, calcularParcelasFuturas, agruparDespesasPorMesConta, calcularParcelasFuturasPorConta } from '../utils/parser.js';

// ── Abas de topo disponíveis ─────────────────────────────────────────────────
const ABAS_MACRO = [
  { id: 'geral',         label: 'Visão Geral',     grupo: null,                   cor: null },
  { id: 'receitas',      label: 'Receitas',         grupo: GRUPOS.RECEITAS,        cor: null },
  { id: 'fixas',         label: 'Despesas Fixas',   grupo: GRUPOS.FIXAS,           cor: null },
  { id: 'consumo',       label: 'Consumo',          grupo: GRUPOS.CONSUMO,         cor: null },
  { id: 'dividas',       label: 'Dívidas',          grupo: GRUPOS.DIVIDAS,         cor: null },
  { id: 'investimentos', label: 'Investimentos',    grupo: GRUPOS.INVESTIMENTOS,   cor: null },
];

// ── Modo de visualização ──────────────────────────────────────────────────────
export default function PageDashboard() {
  const { clienteAtivo, setPaginaAtual, modoLeitura } = useApp();
  // aba: 'geral' | 'receitas' | 'fixas' | 'consumo' | 'dividas' | 'investimentos'
  // mesesSelecionados: Set de índices (0-11). Set vazio = visão anual.
  const [aba, setAba] = useState('geral');
  const [mesesSelecionados, setMesesSelecionados] = useState(new Set());
  const [filtroConta, setFiltroConta] = useState('');

  // Toggle de mês: adiciona se não está, remove se já está
  const toggleMes = (i) => {
    setMesesSelecionados(prev => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  };

  // Limpa seleção → volta para visão anual
  const limparMeses = () => setMesesSelecionados(new Set());

  const modoMultiMes = aba === 'geral' && mesesSelecionados.size > 0;
  // Compatibilidade: mesAtivo agora é null quando anual, ou o primeiro selecionado (para props legados)
  const mes = mesesSelecionados.size === 1 ? [...mesesSelecionados][0] : null;

  if (!clienteAtivo) return null;
  const { transacoes, categorias, planejamento, anoAtivo, contas } = clienteAtivo;
  const anoStr = String(anoAtivo);
  const planAno = planejamento?.[anoStr] || {};

  // mesAtivo: usado internamente — null quando anual, índice quando single-mês
  const mesAtivo = modoMultiMes ? [...mesesSelecionados][0] : null;

  // ── Filtra transações por conta ────────────────────────────────────────────
  const transacoesFiltradas = useMemo(() =>
    filtroConta ? transacoes.filter(t => t.conta === filtroConta) : transacoes,
  [transacoes, filtroConta]);

  const realizadoPorMes = useMemo(() =>
    agruparPorMesCategoria(transacoesFiltradas, anoAtivo),
  [transacoesFiltradas, anoAtivo]);

  const parcelasFuturas = useMemo(() =>
    calcularParcelasFuturas(transacoes, categorias, anoAtivo),
  [transacoes, categorias, anoAtivo]);

  const grupos = [GRUPOS.RECEITAS, GRUPOS.FIXAS, GRUPOS.CONSUMO, GRUPOS.DIVIDAS, GRUPOS.INVESTIMENTOS];

  // ── Totais de um grupo num mês específico ──────────────────────────────────
  function totaisGrupo(grupo, mes) {
    const cats = categorias.filter(c => c.grupo === grupo);
    const real = realizadoPorMes[mes] || {};
    const plan = planAno[mes] || {};
    const parc = parcelasFuturas[mes] || {};
    const isReceita = grupo === GRUPOS.RECEITAS;
    let projetado = 0, realizado = 0, parcelas = 0;
    for (const c of cats) {
      projetado += plan[c.id]?.projetado || 0;
      realizado += isReceita ? (real[c.id]?.receita || 0) : (real[c.id]?.despesa || 0);
      parcelas  += parc[c.id] || plan[c.id]?.parcelas || 0;
    }
    return { projetado, realizado, parcelas };
  }

  // ── Dados por mês (para tabela anual e gráfico) ───────────────────────────
  const dadosMensais = useMemo(() => MESES.map((m, i) => {
    const rec  = totaisGrupo(GRUPOS.RECEITAS, i);
    const desp = grupos.slice(1).reduce((s, g) => {
      const t = totaisGrupo(g, i);
      return { projetado: s.projetado + t.projetado, realizado: s.realizado + t.realizado, parcelas: s.parcelas + t.parcelas };
    }, { projetado: 0, realizado: 0, parcelas: 0 });
    const temReal = rec.realizado > 0 || desp.realizado > 0;
    return {
      mes: m, mesFull: MESES_FULL[i], idx: i,
      recReal: rec.realizado,   recProj: rec.projetado,
      despReal: desp.realizado, despProj: desp.projetado,
      saldoReal: rec.realizado - desp.realizado,
      saldoProj: rec.projetado - desp.projetado,
      temReal,
    };
  }), [realizadoPorMes, planAno, parcelasFuturas, categorias]);

  // ── Totais anuais acumulados ───────────────────────────────────────────────
  const totaisAnuais = useMemo(() => dadosMensais.reduce((acc, d) => ({
    recReal:   acc.recReal   + d.recReal,
    recProj:   acc.recProj   + d.recProj,
    despReal:  acc.despReal  + d.despReal,
    despProj:  acc.despProj  + d.despProj,
    saldoReal: acc.saldoReal + d.saldoReal,
    saldoProj: acc.saldoProj + d.saldoProj,
  }), { recReal: 0, recProj: 0, despReal: 0, despProj: 0, saldoReal: 0, saldoProj: 0 }),
  [dadosMensais]);

  // ── Dados multi-mês: soma todos os meses selecionados ───────────────────
  // planMes: soma dos projetados dos meses selecionados por catId
  const planMes = useMemo(() => {
    if (!modoMultiMes) return {};
    const acc = {};
    for (const i of mesesSelecionados) {
      const p = planAno[i] || {};
      for (const [catId, val] of Object.entries(p)) {
        if (!acc[catId]) acc[catId] = { projetado: 0, parcelas: 0 };
        acc[catId].projetado += val?.projetado || 0;
        acc[catId].parcelas  += val?.parcelas  || 0;
      }
    }
    return acc;
  }, [modoMultiMes, mesesSelecionados, planAno]);

  // realizadoMes: soma dos realizados dos meses selecionados por catId
  const realizadoMes = useMemo(() => {
    if (!modoMultiMes) return {};
    const acc = {};
    for (const i of mesesSelecionados) {
      const r = realizadoPorMes[i] || {};
      for (const [catId, val] of Object.entries(r)) {
        if (!acc[catId]) acc[catId] = { receita: 0, despesa: 0 };
        acc[catId].receita  += val?.receita  || 0;
        acc[catId].despesa  += val?.despesa  || 0;
      }
    }
    return acc;
  }, [modoMultiMes, mesesSelecionados, realizadoPorMes]);

  // parcelasMes: soma das parcelas dos meses selecionados por catId
  const parcelasMes = useMemo(() => {
    if (!modoMultiMes) return {};
    const acc = {};
    for (const i of mesesSelecionados) {
      const p = parcelasFuturas[i] || {};
      for (const [catId, val] of Object.entries(p)) {
        acc[catId] = (acc[catId] || 0) + val;
      }
    }
    return acc;
  }, [modoMultiMes, mesesSelecionados, parcelasFuturas]);

  // totaisGrupoMulti: soma dos totais de grupo nos meses selecionados
  const totaisGrupoMulti = useCallback((grupo) => {
    if (!modoMultiMes) return { realizado: 0, projetado: 0, parcelas: 0 };
    return [...mesesSelecionados].reduce((acc, i) => {
      const t = totaisGrupo(grupo, i);
      return { realizado: acc.realizado + t.realizado, projetado: acc.projetado + t.projetado, parcelas: acc.parcelas + t.parcelas };
    }, { realizado: 0, projetado: 0, parcelas: 0 });
  }, [modoMultiMes, mesesSelecionados, totaisGrupo]);

  const recMes  = modoMultiMes ? totaisGrupoMulti(GRUPOS.RECEITAS) : { realizado: 0, projetado: 0, parcelas: 0 };
  const despMes = modoMultiMes
    ? grupos.slice(1).reduce((s, g) => { const t = totaisGrupoMulti(g); return { projetado: s.projetado + t.projetado, realizado: s.realizado + t.realizado, parcelas: s.parcelas + t.parcelas }; }, { projetado: 0, realizado: 0, parcelas: 0 })
    : { realizado: 0, projetado: 0, parcelas: 0 };

  const saldoRealizado = recMes.realizado - despMes.realizado;
  const saldoProjetado = recMes.projetado - despMes.projetado;
  const taxaPoupanca   = recMes.realizado > 0 ? ((recMes.realizado - despMes.realizado) / recMes.realizado * 100) : 0;

  const totalParcelasMes = Object.values(parcelasMes).reduce((s, v) => s + v, 0);
  const totalParcelasFut = Array.from({ length: 12 }, (_, i) =>
    Object.values(parcelasFuturas[i] || {}).reduce((s, v) => s + v, 0));

  const maxBarValue = Math.max(...dadosMensais.map(d => Math.max(d.recReal, d.despReal)), 1);

  // ── Dados por conta para o gráfico de gastos por conta ────────────────────
  const despesasPorMesConta = useMemo(() =>
    agruparDespesasPorMesConta(transacoesFiltradas, anoAtivo),
  [transacoesFiltradas, anoAtivo]);

  const parcelasFuturasPorConta = useMemo(() =>
    calcularParcelasFuturasPorConta(transacoes, anoAtivo),
  [transacoes, anoAtivo]);

  // Projetado total por mês (do planejamento) para o modo Projetado
  const projetadoPorMes = useMemo(() =>
    MESES.map((_, i) => {
      return grupos.slice(1).reduce((s, g) => s + totaisGrupo(g, i).projetado, 0);
    }),
  [planAno, categorias]);

  // ── Subheader label ────────────────────────────────────────────────────────
  const abaLabel = ABAS_MACRO.find(a => a.id === aba)?.label || 'Visão Geral';
  const subLabel = aba === 'geral'
    ? (modoMultiMes
        ? `${clienteAtivo.nome} · ${
            [...mesesSelecionados].sort((a,b)=>a-b).map(i => MESES[i]).join(', ')
          } ${anoAtivo}`
        : `${clienteAtivo.nome} · Visão Anual ${anoAtivo}`)
    : `${clienteAtivo.nome} · ${abaLabel} ${anoAtivo}`;

  return (
    <div className="mb-page" style={{ padding: '28px 32px', maxWidth: 1300, margin: '0 auto' }}>

      {/* ── Header ────────────────────────────────────────────────────────── */}
      <div className="mb-page-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ fontSize: FONT.xl, fontWeight: 800, color: C.text }}>Dashboard</div>
          <div style={{ fontSize: FONT.sm, color: C.textMuted }}>{subLabel}</div>
        </div>
        <div className="mb-header-actions" style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          <select value={filtroConta} onChange={e => setFiltroConta(e.target.value)}
            style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '8px 12px', color: C.text, fontSize: FONT.sm, fontFamily: "'Inter',sans-serif", outline: 'none' }}>
            <option value="">Todas as contas</option>
            {contas.map(c => <option key={c.id} value={c.nome}>{c.nome}</option>)}
          </select>
          <Btn variant="ghost" size="sm" onClick={() => window.print()}>🖨️ Imprimir PDF</Btn>
        </div>
      </div>

      {/* ── Barra de abas principal ───────────────────────────────────────── */}
      <div className="mb-abas-macro" style={{ display: 'flex', gap: 4, marginBottom: 16, borderBottom: `2px solid ${C.border}`, paddingBottom: 0, overflowX: 'auto' }}>
        {ABAS_MACRO.map(a => {
          const ativo = aba === a.id;
          const corAba = a.id === 'geral' ? C.brand
            : a.id === 'receitas'      ? C.rec
            : a.id === 'fixas'         ? C.grupoFixas
            : a.id === 'consumo'       ? C.grupoConsumo
            : a.id === 'dividas'       ? C.grupoDividas
            : C.grupoInvestimentos;
          return (
            <button key={a.id} onClick={() => { setAba(a.id); setMes(null); }} style={{
              padding: '9px 18px',
              background: 'transparent',
              color: ativo ? corAba : C.textMuted,
              fontWeight: ativo ? 700 : 500,
              fontSize: FONT.sm,
              cursor: 'pointer',
              fontFamily: "'Inter',sans-serif",
              border: 'none',
              borderBottom: ativo ? `3px solid ${corAba}` : '3px solid transparent',
              marginBottom: -2,
              whiteSpace: 'nowrap',
              transition: 'color 0.15s',
            }}>{a.label}</button>
          );
        })}
      </div>

      {/* ── Navegação de meses (só na aba Visão Geral) ───────────────────── */}
      {aba === 'geral' && (
        <div style={{ display: 'flex', gap: 5, marginBottom: 28, flexWrap: 'wrap', alignItems: 'center' }}>
          {/* Botão Ano */}
          <button onClick={limparMeses} style={{
            padding: '7px 16px', borderRadius: RADIUS.md,
            background: !modoMultiMes ? C.brand : C.card,
            color: !modoMultiMes ? C.bg : C.text,
            fontWeight: !modoMultiMes ? 800 : 600,
            fontSize: FONT.sm, cursor: 'pointer', fontFamily: "'Inter',sans-serif",
            border: `1px solid ${!modoMultiMes ? C.brand : C.border}`,
            letterSpacing: '0.04em',
          }}>Ano</button>

          {/* Divisor */}
          <div style={{ width: 1, height: 24, background: C.border, margin: '0 4px' }} />

          {/* Botões de mês — toggle multi-seleção */}
          {MESES.map((m, i) => {
            const d = dadosMensais[i];
            const ativo = mesesSelecionados.has(i);
            return (
              <button key={i} onClick={() => toggleMes(i)} style={{
                padding: '7px 13px', borderRadius: RADIUS.md,
                background: ativo ? C.brand : C.card,
                color: ativo ? C.bg : d.temReal ? (d.saldoReal >= 0 ? C.rec : C.desp) : C.textMuted,
                fontWeight: ativo ? 700 : 500,
                fontSize: FONT.sm, cursor: 'pointer', fontFamily: "'Inter',sans-serif",
                border: `1px solid ${ativo ? C.brand : d.temReal ? (d.saldoReal >= 0 ? C.rec + '50' : C.desp + '50') : C.border}`,
                outline: ativo ? `2px solid ${C.brand}55` : 'none',
                outlineOffset: 1,
              }}>{m}</button>
            );
          })}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          ABA: VISÃO GERAL — ANUAL
      ══════════════════════════════════════════════════════════════════════ */}
      {aba === 'geral' && !modoMultiMes && (
        <VistaAnual
          dadosMensais={dadosMensais}
          totaisAnuais={totaisAnuais}
          maxBarValue={maxBarValue}
          onMesClick={i => toggleMes(i)}
          anoAtivo={anoAtivo}
          totaisGrupo={totaisGrupo}
          grupos={grupos}
          contas={contas}
          despesasPorMesConta={despesasPorMesConta}
          parcelasFuturasPorConta={parcelasFuturasPorConta}
          projetadoPorMes={projetadoPorMes}
          totalParcelasFut={totalParcelasFut}
        />
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          ABA: VISÃO GERAL — MENSAL
      ══════════════════════════════════════════════════════════════════════ */}
      {modoMultiMes && (
        <VistaMensal
          mesAtivo={mesAtivo}
          mesesSelecionados={mesesSelecionados}
          grupos={grupos}
          totaisGrupo={totaisGrupoMulti}
          categorias={categorias}
          recMes={recMes} despMes={despMes}
          saldoRealizado={saldoRealizado} saldoProjetado={saldoProjetado}
          taxaPoupanca={taxaPoupanca}
          totalParcelasMes={totalParcelasMes}
          totalParcelasFut={totalParcelasFut}
          dadosMensais={dadosMensais}
          maxBarValue={maxBarValue}
          planMes={planMes} realizadoMes={realizadoMes} parcelasMes={parcelasMes}
          onMesClick={i => toggleMes(i)}
          vistaAtiva={mes}
        />
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          ABAS DE MACRO: Receitas | Despesas Fixas | Consumo | Dívidas | Invest.
      ══════════════════════════════════════════════════════════════════════ */}
      {aba !== 'geral' && (() => {
        const abaInfo = ABAS_MACRO.find(a => a.id === aba);
        return (
          <VistaMacro
            grupo={abaInfo.grupo}
            label={abaInfo.label}
            dadosMensais={dadosMensais}
            totaisGrupo={totaisGrupo}
            categorias={categorias}
            planAno={planAno}
            realizadoPorMes={realizadoPorMes}
            parcelasFuturas={parcelasFuturas}
            anoAtivo={anoAtivo}
          />
        );
      })()}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTE: Vista Anual
// ══════════════════════════════════════════════════════════════════════════════
function VistaAnual({ dadosMensais, totaisAnuais, maxBarValue, onMesClick, anoAtivo, totaisGrupo, grupos, contas, despesasPorMesConta, parcelasFuturasPorConta, projetadoPorMes, totalParcelasFut }) {
  const mesesComReal = dadosMensais.filter(d => d.temReal).length;

  // ── Dados por grupo por mês para o gráfico de linhas ──────────────────────
  const SERIES = useMemo(() => [
    { grupo: GRUPOS.RECEITAS,     cor: C.grupoReceitas,     label: 'Receitas'        },
    { grupo: GRUPOS.FIXAS,        cor: C.grupoFixas,        label: 'Despesas Fixas'  },
    { grupo: GRUPOS.CONSUMO,      cor: C.grupoConsumo,      label: 'Consumo'         },
    { grupo: GRUPOS.DIVIDAS,      cor: C.grupoDividas,      label: 'Dívidas'         },
    { grupo: GRUPOS.INVESTIMENTOS,cor: C.grupoInvestimentos,label: 'Investimentos'   },
  ], []);

  const seriesData = useMemo(() => SERIES.map(s => ({
    ...s,
    pontos: MESES.map((_, i) => {
      const t = totaisGrupo(s.grupo, i);
      const isReceita = s.grupo === GRUPOS.RECEITAS;
      const valor = isReceita ? t.realizado : t.realizado;
      const proj  = isReceita ? t.projetado  : t.projetado;
      const temReal = dadosMensais[i].temReal;
      // Valor efetivo: realizado se tem dados reais, projetado se não tem mas existe proj
      const v = temReal ? valor : (proj > 0 ? proj : null);
      return { v, isProj: !temReal && proj > 0, mesIdx: i };
    }),
  })), [totaisGrupo, dadosMensais, SERIES]);

  return (
    <>
      {/* ── KPIs anuais ─────────────────────────────────────────────────── */}
      <div className="mb-grid-5" style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14, marginBottom: 28 }}>
        <KPICard label="Receitas no Ano" value={fmtBRL(totaisAnuais.recReal)}
          sub={`Proj: ${fmtBRL(totaisAnuais.recProj)}`} color={C.rec} />
        <KPICard label="Despesas no Ano" value={fmtBRL(totaisAnuais.despReal)}
          sub={`Proj: ${fmtBRL(totaisAnuais.despProj)}`} color={C.desp} />
        <KPICard label="Saldo Acumulado" value={fmtBRL(totaisAnuais.saldoReal)}
          sub={`Proj: ${fmtBRL(totaisAnuais.saldoProj)}`}
          color={totaisAnuais.saldoReal >= 0 ? C.rec : C.desp} />
        <KPICard label="Média Mensal (Saldo)"
          value={fmtBRL(mesesComReal > 0 ? totaisAnuais.saldoReal / mesesComReal : 0)}
          sub={`${mesesComReal} meses realizados`}
          color={totaisAnuais.saldoReal >= 0 ? C.rec : C.desp} />
        <KPICard label="Taxa de Economia"
          value={totaisAnuais.recReal > 0 ? `${((totaisAnuais.saldoReal / totaisAnuais.recReal) * 100).toFixed(1)}%` : '—'}
          sub={totaisAnuais.recReal > 0 && (totaisAnuais.saldoReal / totaisAnuais.recReal) >= 0.1 ? '✅ Meta atingida' : '⚠️ Abaixo de 10%'}
          color={totaisAnuais.recReal > 0 && (totaisAnuais.saldoReal / totaisAnuais.recReal) >= 0.1 ? C.green : C.yellow} />
      </div>

      {/* ── Gráfico de Linhas + Parcelamentos (lado a lado) ─────────────── */}
      <div className="mb-grid-main" style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20, marginBottom: 20 }}>
        <GraficoLinhas seriesData={seriesData} dadosMensais={dadosMensais} onMesClick={onMesClick} anoAtivo={anoAtivo} />
        <GraficoParcelamentos totalParcelasFut={totalParcelasFut} anoAtivo={anoAtivo} />
      </div>

      {/* ── Gráfico de barras anual ──────────────────────────────────────── */}
      <GraficoBarras dadosMensais={dadosMensais} maxBarValue={maxBarValue} onMesClick={onMesClick} anoAtivo={anoAtivo} projetadoPorMes={projetadoPorMes} totalParcelasFut={totalParcelasFut} />

      {/* ── Gráfico de Gastos por Conta ─────────────────────────────────── */}
      <GraficoContasMensais
        contas={contas}
        despesasPorMesConta={despesasPorMesConta}
        parcelasFuturasPorConta={parcelasFuturasPorConta}
        projetadoPorMes={projetadoPorMes}
        dadosMensais={dadosMensais}
        onMesClick={onMesClick}
        anoAtivo={anoAtivo}
      />

      {/* ── Tabela Jan → Dez ────────────────────────────────────────────── */}
      {(() => {
        // Macros de despesa na ordem desejada
        const MACROS = [
          { grupo: GRUPOS.FIXAS,         label: 'Desp. Fixas',   cor: C.grupoFixas        },
          { grupo: GRUPOS.CONSUMO,        label: 'Consumo',       cor: C.grupoConsumo      },
          { grupo: GRUPOS.DIVIDAS,        label: 'Dívidas',       cor: C.grupoDividas      },
          { grupo: GRUPOS.INVESTIMENTOS,  label: 'Invest.',       cor: C.grupoInvestimentos},
        ];

        // Totais por macro: separado em realizado e realizado+projetado
        const totalsMacroReal = MACROS.map(m =>
          dadosMensais.reduce((acc, d, i) => {
            const t = totaisGrupo(m.grupo, i);
            return acc + (d.temReal ? t.realizado : 0);
          }, 0)
        );
        // Todo = realizado nos meses reais + projetado nos meses futuros (sem misturar)
        const totalsMacroTodo = MACROS.map(m =>
          dadosMensais.reduce((acc, d, i) => {
            const t = totaisGrupo(m.grupo, i);
            return acc + (d.temReal ? t.realizado : t.projetado);
          }, 0)
        );

        // Totais saldo: só realizado vs realizado+projetado
        const totalSaldoReal = totaisAnuais.saldoReal;
        const totalSaldoTodo = dadosMensais.reduce((acc, d) =>
          acc + (d.temReal ? d.saldoReal : d.saldoProj), 0);

        // Total receitas realizado e realizado+projetado
        const totalRecReal = totaisAnuais.recReal;
        const totalRecTodo = dadosMensais.reduce((acc, d) =>
          acc + (d.temReal ? d.recReal : d.recProj), 0);

        // Helper: percentual frente à receita base — omite se base < 1 (evita % absurdos)
        const Pct = ({ valor, base }) => {
          if (!base || base < 1 || !valor) return null;
          const raw = valor / base * 100;
          const p = Math.round(raw); // sem casas decimais
          if (!p) return null;
          const label = (valor < 0 ? '-' : '') + Math.abs(p) + '%';
          return (
            <span style={{ fontSize: FONT.xs, color: C.textMuted, fontWeight: 500, marginLeft: 6, fontStyle: 'normal', opacity: 0.75 }}>
              {label}
            </span>
          );
        };

        // Helper célula do rodapé: valor principal (realizado) + secundário (real+proj)
        const TotalCell = ({ real, todo, cor }) => (
          <td style={{ padding: '13px 12px', textAlign: 'right', verticalAlign: 'middle' }}>
            <div style={{ fontWeight: 800, color: cor, fontSize: FONT.sm }}>{fmtBRL(real)}</div>
            {Math.abs(todo - real) > 0.5 && (
              <div style={{ fontWeight: 500, color: C.textMuted, fontSize: FONT.sm, fontStyle: 'italic', marginTop: 2, opacity: 0.7 }}>
                {fmtBRL(todo)}
              </div>
            )}
          </td>
        );

        const thStyle = (center) => ({
          padding: '10px 12px',
          textAlign: center ? 'center' : 'right',
          color: C.textMuted,
          fontWeight: 600,
          fontSize: FONT.xs,
          borderBottom: `1px solid ${C.border}`,
          whiteSpace: 'nowrap',
        });

        return (
          <Card padding="0" style={{ marginBottom: 20, overflow: 'hidden' }}>
            <div style={{ padding: '18px 20px 14px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text }}>
                Fluxo Mensal
              </div>
              <div style={{ fontSize: FONT.xs, color: C.textMuted }}>Clique em um mês para ver o detalhe</div>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: FONT.sm }}>
              <thead>
                <tr style={{ background: C.bg }}>
                  <th style={{ ...thStyle(false), textAlign: 'left' }}>Mês</th>
                  <th style={thStyle(false)}>Receitas</th>
                  {MACROS.map(m => (
                    <th key={m.grupo} style={{ ...thStyle(false), color: m.cor }}>{m.label}</th>
                  ))}
                  <th style={thStyle(false)}>Saldo</th>
                  <th style={{ ...thStyle(true) }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {dadosMensais.map((d, i) => {
                  const isProj = !d.temReal;
                  const statusIcon = d.temReal ? (d.saldoReal >= 0 ? '✅' : '🔴') : (d.recProj > 0 || d.despProj > 0 ? '📋' : '—');
                  // Base de receita do mês para calcular %
                  const recBase = d.temReal ? d.recReal : d.recProj;

                  // Valor de cada macro neste mês
                  const macroVals = MACROS.map(m => {
                    const t = totaisGrupo(m.grupo, i);
                    return { v: d.temReal ? t.realizado : t.projetado };
                  });

                  const saldo = d.temReal ? d.saldoReal : d.saldoProj;
                  const saldoCor = saldo >= 0 ? C.rec : C.desp;

                  return (
                    <tr key={i}
                      onClick={() => onMesClick(i)}
                      style={{ borderBottom: `1px solid ${C.border}20`, cursor: 'pointer', transition: 'background 0.15s' }}
                      onMouseEnter={e => e.currentTarget.style.background = C.brand + '12'}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                    >
                      {/* Mês */}
                      <td style={{ padding: '11px 12px', fontWeight: d.temReal ? 700 : 500, color: d.temReal ? C.text : C.textMuted }}>
                        {d.mesFull}
                      </td>
                      {/* Receitas */}
                      <td style={{ padding: '11px 12px', textAlign: 'right', fontWeight: d.temReal ? 600 : 400, fontStyle: isProj ? 'italic' : 'normal', color: d.temReal ? C.rec : C.textMuted }}>
                        {d.temReal ? fmtBRL(d.recReal) : (d.recProj > 0 ? fmtBRL(d.recProj) : '—')}
                      </td>
                      {/* Macros com % */}
                      {macroVals.map((mv, mi) => (
                        <td key={mi} style={{ padding: '11px 12px', textAlign: 'right', fontWeight: d.temReal ? 600 : 400, fontStyle: isProj ? 'italic' : 'normal', color: mv.v > 0 ? (d.temReal ? MACROS[mi].cor : C.textMuted) : C.textDim }}>
                          {mv.v > 0 ? (
                            <>{fmtBRL(mv.v)}<Pct valor={mv.v} base={recBase} /></>
                          ) : '—'}
                        </td>
                      ))}
                      {/* Saldo com % */}
                      <td style={{ padding: '11px 12px', textAlign: 'right', fontWeight: 700, fontStyle: isProj ? 'italic' : 'normal', color: isProj ? C.textMuted : saldoCor }}>
                        {saldo !== 0 ? (
                          <>{fmtBRL(saldo)}<Pct valor={saldo} base={recBase} /></>
                        ) : '—'}
                      </td>
                      {/* Status */}
                      <td style={{ padding: '11px 12px', textAlign: 'center', fontSize: FONT.base }}>
                        {statusIcon}
                        {isProj && <span style={{ fontSize: FONT.xs, color: C.textMuted, marginLeft: 4 }}>proj.</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              {/* ── Totais anuais ───────────────────────────────────────── */}
              <tfoot>
                <tr style={{ background: C.brand + '14', borderTop: `2px solid ${C.brand}30` }}>
                  <td style={{ padding: '13px 12px', fontWeight: 800, color: C.text, fontSize: FONT.sm }}>
                    TOTAL
                  </td>
                  {/* Receitas */}
                  <TotalCell real={totalRecReal} todo={totalRecTodo} cor={C.rec} />
                  {/* Macros */}
                  {MACROS.map((m, mi) => (
                    <TotalCell key={mi} real={totalsMacroReal[mi]} todo={totalsMacroTodo[mi]} cor={m.cor} />
                  ))}
                  {/* Saldo */}
                  <TotalCell real={totalSaldoReal} todo={totalSaldoTodo} cor={totalSaldoReal >= 0 ? C.rec : C.desp} />
                  <td />
                </tr>
              </tfoot>
            </table>
          </Card>
        );
      })()}

    </>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTE: Vista Macro (Receitas / Despesas Fixas / Consumo / Dívidas / Invest.)
// ══════════════════════════════════════════════════════════════════════════════
function VistaMacro({ grupo, label, dadosMensais, totaisGrupo, categorias, planAno, realizadoPorMes, parcelasFuturas, anoAtivo }) {
  const isReceita = grupo === GRUPOS.RECEITAS;

  // Cor do grupo
  const corGrupo = grupo === GRUPOS.RECEITAS      ? C.rec
    : grupo === GRUPOS.FIXAS         ? C.grupoFixas
    : grupo === GRUPOS.CONSUMO       ? C.grupoConsumo
    : grupo === GRUPOS.DIVIDAS       ? C.grupoDividas
    : grupo === GRUPOS.INVESTIMENTOS ? C.grupoInvestimentos
    : C.textMuted;

  // Categorias deste grupo
  const cats = categorias.filter(c => c.grupo === grupo);

  // ── KPIs anuais do grupo ──────────────────────────────────────────────────
  const totaisAno = useMemo(() => {
    let real = 0, proj = 0, parc = 0;
    for (let i = 0; i < 12; i++) {
      const t = totaisGrupo(grupo, i);
      real += t.realizado;
      proj += t.projetado;
      parc += t.parcelas;
    }
    return { real, proj, parc };
  }, [grupo, totaisGrupo]);

  // Execução orçamentária correta:
  //   execPct   = Real(ano) ÷ Proj(ano inteiro) × 100   → quanto % do ano já foi realizado
  //   esperado  = meses realizados ÷ 12 × 100            → quanto % deveria ter sido realizado no tempo
  //   ritmo     = execPct ÷ esperado × 100               → 100% = exatamente no ritmo
  //
  // Semáforo compara o ritmo real com o ritmo esperado pelo calendário:
  //   ≥ 92% do esperado → 🟢  dentro do ritmo
  //   80–92%            → 🟡  levemente abaixo
  //   < 80%             → 🔴  abaixo do ritmo previsto
  //   > 115%            → 🔴  acima do ritmo previsto
  const { execPct, esperadoPct, ritmoPct } = useMemo(() => {
    const mesesReais = dadosMensais.filter(d => d.temReal).length;
    if (mesesReais === 0 || totaisAno.proj === 0) return { execPct: null, esperadoPct: null, ritmoPct: null };
    const execPct    = totaisAno.real / totaisAno.proj * 100;
    const esperadoPct = mesesReais / 12 * 100;
    const ritmoPct   = execPct / esperadoPct * 100; // 100% = no ritmo perfeito
    return { execPct, esperadoPct, ritmoPct };
  }, [grupo, totaisGrupo, dadosMensais, totaisAno]);

  // ── Dados mensais por categoria ───────────────────────────────────────────
  // Para cada mês: array de { cat, real, proj, parc, isProj }
  const dadosPorMes = useMemo(() => MESES.map((_, mi) => {
    const temReal = dadosMensais[mi].temReal;
    const planMes = planAno[mi] || {};
    const realMes = realizadoPorMes[mi] || {};
    const parcMes = parcelasFuturas[mi] || {};
    return cats.map(cat => {
      const real = isReceita ? (realMes[cat.id]?.receita || 0) : (realMes[cat.id]?.despesa || 0);
      const proj = planMes[cat.id]?.projetado || 0;
      const parc = parcMes[cat.id] || planMes[cat.id]?.parcelas || 0;
      return { cat, real, proj, parc, temReal };
    });
  }), [cats, planAno, realizadoPorMes, parcelasFuturas, dadosMensais, isReceita]);

  // Totais por categoria (realizado e projetado anual)
  const totaisPorCat = useMemo(() => cats.map(cat => {
    let real = 0, proj = 0, parc = 0;
    for (let i = 0; i < 12; i++) {
      const row = dadosPorMes[i].find(r => r.cat.id === cat.id);
      if (row) { real += row.real; proj += row.proj; parc += row.parc; }
    }
    return { cat, real, proj, parc };
  }), [cats, dadosPorMes]);

  const thS = { padding: '9px 10px', textAlign: 'right', color: C.textMuted, fontWeight: 600, fontSize: FONT.xs, borderBottom: `1px solid ${C.border}`, whiteSpace: 'nowrap' };

  return (
    <>
      {/* ── KPIs ──────────────────────────────────────────────────────────── */}
      <div className="mb-grid-4" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 28 }}>
        <KPICard label={`${label} — Realizado`} value={fmtBRL(totaisAno.real)} color={corGrupo}
          sub={`Proj: ${fmtBRL(totaisAno.proj)}`} />
        <KPICard label="Execução Orçamentária"
          value={execPct !== null ? `${execPct.toFixed(1)}%` : '—'}
          color={ritmoPct === null ? C.textMuted
            : ritmoPct > 115  ? C.desp
            : ritmoPct >= 92  ? C.rec
            : ritmoPct >= 80  ? C.yellow
            : C.desp}
          sub={ritmoPct === null ? 'Sem projeção'
            : `Esperado: ${esperadoPct.toFixed(1)}% · ${
                ritmoPct > 115  ? '🔴 Acima do ritmo'
              : ritmoPct >= 92  ? '🟢 No ritmo previsto'
              : ritmoPct >= 80  ? '🟡 Levemente abaixo'
              : '🔴 Abaixo do ritmo'}`} />
        <KPICard label="Média Mensal (Realizado)"
          value={fmtBRL(totaisAno.real / Math.max(dadosMensais.filter(d => d.temReal).length, 1))}
          color={corGrupo}
          sub={`${dadosMensais.filter(d => d.temReal).length} meses realizados`} />
        {totaisAno.parc > 0
          ? <KPICard label="Parcelas Futuras" value={fmtBRL(totaisAno.parc)} color="#C084FC" sub="comprometido em parcelamentos" />
          : <KPICard label="Projeção Anual" value={fmtBRL(totaisAno.proj)} color={C.textMuted} sub="total orçado no ano" />
        }
      </div>

      {/* ── Tabela Jan → Dez por Categoria ───────────────────────────────── */}
      <Card padding="0" style={{ marginBottom: 20, overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px 12px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text }}>
            {label} — {anoAtivo}
          </div>
          <div style={{ fontSize: FONT.xs, color: C.textMuted }}>Realizado · Projetado por mês</div>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: FONT.xs, minWidth: 900 }}>
            <thead>
              <tr style={{ background: C.bg }}>
                <th style={{ ...thS, textAlign: 'left', width: 160, paddingLeft: 16 }}>Categoria</th>
                {MESES.map((m, i) => (
                  <th key={i} style={{ ...thS, color: dadosMensais[i].temReal ? C.text : C.textMuted }}>{m}</th>
                ))}
                <th style={{ ...thS, color: corGrupo }}>Total</th>
              </tr>
            </thead>
            <tbody>
              {totaisPorCat.map(({ cat, real: catReal, proj: catProj }) => {
                // Omite categorias sem nenhum dado no ano
                if (catReal === 0 && catProj === 0) return null;
                return (
                  <tr key={cat.id} style={{ borderBottom: `1px solid ${C.border}14` }}
                    onMouseEnter={e => e.currentTarget.style.background = C.brand + '0a'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                    <td style={{ padding: '9px 10px 9px 16px', color: C.text, fontWeight: 500, whiteSpace: 'nowrap' }}>{cat.nome}</td>
                    {dadosPorMes.map((mesDados, mi) => {
                      const row = mesDados.find(r => r.cat.id === cat.id);
                      if (!row) return <td key={mi} style={{ padding: '9px 10px', textAlign: 'right', color: C.textDim }}>—</td>;
                      const { real, proj, parc, temReal } = row;
                      const mostrar = temReal ? real : proj;
                      if (mostrar === 0 && parc === 0) return <td key={mi} style={{ padding: '9px 10px', textAlign: 'right', color: C.textDim }}>—</td>;
                      return (
                        <td key={mi} style={{ padding: '9px 10px', textAlign: 'right', fontStyle: temReal ? 'normal' : 'italic' }}>
                          {/* Valor principal */}
                          <div style={{ color: temReal ? corGrupo : C.textMuted, fontWeight: temReal ? 600 : 400 }}>
                            {fmtBRL(mostrar)}
                          </div>
                          {/* Projeção em cinza abaixo, se tem real e proj > 0 */}
                          {temReal && proj > 0 && Math.abs(real - proj) > 0.5 && (
                            <div style={{ color: C.textDim, fontSize: '0.85em', fontStyle: 'italic' }}>
                              {fmtBRL(proj)}
                            </div>
                          )}
                          {/* Parcelas em roxo se não tem real */}
                          {!temReal && parc > 0 && (
                            <div style={{ color: '#C084FC', fontSize: '0.85em' }}>📌 {fmtBRL(parc)}</div>
                          )}
                        </td>
                      );
                    })}
                    {/* Total da categoria */}
                    <td style={{ padding: '9px 10px', textAlign: 'right', fontWeight: 700, color: corGrupo, borderLeft: `1px solid ${C.border}30` }}>
                      {fmtBRL(catReal || catProj)}
                      {catReal > 0 && catProj > 0 && Math.abs(catReal - catProj) > 0.5 && (
                        <div style={{ color: C.textDim, fontSize: '0.85em', fontWeight: 400, fontStyle: 'italic' }}>{fmtBRL(catProj)}</div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            {/* ── Totais anuais ─────────────────────────────────────────── */}
            <tfoot>
              <tr style={{ background: corGrupo + '14', borderTop: `2px solid ${corGrupo}30` }}>
                <td style={{ padding: '11px 10px 11px 16px', fontWeight: 800, color: C.text, fontSize: FONT.sm }}>TOTAL</td>
                {MESES.map((_, mi) => {
                  const t = totaisGrupo(grupo, mi);
                  const d = dadosMensais[mi];
                  const v = d.temReal ? t.realizado : t.projetado;
                  return (
                    <td key={mi} style={{ padding: '11px 10px', textAlign: 'right', fontWeight: 700, color: d.temReal ? corGrupo : C.textMuted, fontStyle: d.temReal ? 'normal' : 'italic', fontSize: FONT.sm }}>
                      {v > 0 ? fmtBRL(v) : '—'}
                    </td>
                  );
                })}
                <td style={{ padding: '11px 10px', textAlign: 'right', fontWeight: 800, color: corGrupo, fontSize: FONT.sm, borderLeft: `1px solid ${C.border}30` }}>
                  {fmtBRL(totaisAno.real || totaisAno.proj)}
                  {totaisAno.real > 0 && totaisAno.proj > 0 && Math.abs(totaisAno.real - totaisAno.proj) > 0.5 && (
                    <div style={{ color: C.textDim, fontSize: '0.85em', fontWeight: 400, fontStyle: 'italic' }}>{fmtBRL(totaisAno.proj)}</div>
                  )}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>
    </>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTE: Gráfico de Barras Anual
// ══════════════════════════════════════════════════════════════════════════════
function GraficoBarras({ dadosMensais, maxBarValue, onMesClick, anoAtivo, projetadoPorMes, totalParcelasFut }) {
  const [hoveredBar, setHoveredBar] = useState(null);
  // hoveredBar: { mesIdx, side: 'rec'|'desp', valor, x, y } | null

  // Saldo acumulado progressivo: meses reais usam saldoReal; meses futuros usam recProj - despProj
  const saldoAcumulado = useMemo(() => {
    let acc = 0;
    return dadosMensais.map((d, i) => {
      const saldoMes = d.temReal
        ? d.saldoReal
        : (d.recProj || 0) - (projetadoPorMes?.[i] || 0);
      acc += saldoMes;
      return acc;
    });
  }, [dadosMensais, projetadoPorMes]);

  // Escala Y: máximo entre real, projetado e parcelamentos futuros
  const escalaMax = useMemo(() => {
    let m = 1;
    dadosMensais.forEach((d, i) => {
      m = Math.max(m, d.recReal, d.despReal,
        projetadoPorMes ? projetadoPorMes[i] || 0 : 0,
        // receita projetada
        d.recProj || 0,
        totalParcelasFut ? totalParcelasFut[i] || 0 : 0,
      );
    });
    return m * 1.08;
  }, [dadosMensais, projetadoPorMes, totalParcelasFut]);

  const BAR_H = 140; // altura útil das barras em px
  const pct = v => `${Math.max(0, (v / escalaMax) * BAR_H)}px`;

  const fmtSemCentavos = v => 'R$ ' + Math.round(Math.abs(v)).toLocaleString('pt-BR');

  return (
    <Card padding="20px 24px" style={{ marginBottom: 20 }}>
      {/* Título */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text }}>
          Receitas x Despesas
        </div>
        {/* Legenda */}
        <div style={{ display: 'flex', gap: 14, fontSize: FONT.xs, color: C.textMuted }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 10, height: 10, background: C.rec, borderRadius: 2, display: 'inline-block' }} />Receitas
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 10, height: 10, background: C.desp, borderRadius: 2, display: 'inline-block' }} />Despesas
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 10, height: 10, background: C.text, borderRadius: 2, display: 'inline-block', opacity: 0.15 }} />Projetado
          </span>

        </div>
      </div>

      {/* Barras — todos os filhos com position:absolute ancorados em bottom:0 dentro de um container fixo BAR_H */}
      <div style={{ display: 'flex', gap: 6 }}>
        {dadosMensais.map((d, i) => {
          const parcFut = totalParcelasFut?.[i] || 0;
          const recProj = d.recProj || 0;
          const despProj = projetadoPorMes?.[i] || 0;
          const acum = saldoAcumulado[i];
          const hov = hoveredBar?.mesIdx === i;

          // Alturas em px (números, não strings) para poder usar em cálculos
          const hRecProj  = Math.max(0, (recProj  / escalaMax) * BAR_H);
          const hRecReal  = Math.max(0, ((d.recReal  || 0) / escalaMax) * BAR_H);
          const hDespProj = Math.max(0, (despProj / escalaMax) * BAR_H);
          const hDespReal = Math.max(0, ((d.despReal || 0) / escalaMax) * BAR_H);
          const hParcFut  = Math.max(0, (parcFut  / escalaMax) * BAR_H);

          const TT = ({ color, children }) => (
            <div style={{ position: 'absolute', bottom: 'calc(100% + 6px)', left: '50%', transform: 'translateX(-50%)',
              background: C.card, border: `1px solid ${color}66`, borderRadius: RADIUS.sm,
              padding: '5px 10px', fontSize: FONT.sm, color, fontWeight: 700,
              whiteSpace: 'nowrap', pointerEvents: 'none', zIndex: 20,
              boxShadow: '0 2px 8px rgba(0,0,0,0.5)' }}>
              {children}
            </div>
          );

          return (
            <div key={i}
              onClick={() => onMesClick(i)}
              style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', cursor: 'pointer' }}>

              {/* Container fixo BAR_H — todas as barras absolutas com bottom:0 */}
              <div style={{ width: '100%', height: BAR_H, display: 'flex', justifyContent: 'center', alignItems: 'flex-end', gap: 2 }}>

                {/* ── Coluna Receitas ── */}
                <div style={{ width: '46%', height: BAR_H, position: 'relative' }}>
                  {/* Sombra projetada (sempre presente se há projeção) */}
                  {hRecProj > 0 && (
                    <div onMouseEnter={() => setHoveredBar({ mesIdx: i, side: 'recProj', valor: recProj })}
                         onMouseLeave={() => setHoveredBar(null)}
                         style={{ position: 'absolute', bottom: 0, left: 0, right: 0,
                           height: hRecProj, background: C.rec,
                           opacity: hov && hoveredBar?.side === 'recProj' ? 0.45 : 0.28,
                           borderRadius: '3px 3px 0 0', zIndex: 0, cursor: 'pointer', transition: 'opacity 0.15s' }}>
                      {hov && hoveredBar?.side === 'recProj' && <TT color={C.rec}>{fmtSemCentavos(recProj)}</TT>}
                    </div>
                  )}
                  {/* Barra real (por cima da sombra) */}
                  {d.temReal && hRecReal > 0 && (
                    <div onMouseEnter={() => setHoveredBar({ mesIdx: i, side: 'rec', valor: d.recReal })}
                         onMouseLeave={() => setHoveredBar(null)}
                         style={{ position: 'absolute', bottom: 0, left: 0, right: 0,
                           height: hRecReal, background: C.rec,
                           opacity: hov && hoveredBar?.side === 'rec' ? 1 : 0.85,
                           borderRadius: '3px 3px 0 0', zIndex: 1, transition: 'opacity 0.15s' }}>
                      {hov && hoveredBar?.side === 'rec' && <TT color={C.rec}>{fmtSemCentavos(d.recReal)}</TT>}
                      {/* Linha branca só quando real > projetado */}
                      {hRecProj > 0 && hRecReal > hRecProj && (
                        <div onMouseEnter={() => setHoveredBar({ mesIdx: i, side: 'recMarca', valor: recProj })}
                             onMouseLeave={() => setHoveredBar(null)}
                             style={{ position: 'absolute', left: 0, right: 0, bottom: hRecProj,
                               height: 2, background: 'rgba(255,255,255,0.80)', zIndex: 3, cursor: 'crosshair' }}>
                          {hov && hoveredBar?.side === 'recMarca' && <TT color={C.rec}>Proj: {fmtSemCentavos(recProj)}</TT>}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* ── Coluna Despesas ── */}
                <div style={{ width: '46%', height: BAR_H, position: 'relative' }}>
                  {/* Sombra projetada */}
                  {hDespProj > 0 && (
                    <div onMouseEnter={() => setHoveredBar({ mesIdx: i, side: 'despProj', valor: despProj })}
                         onMouseLeave={() => setHoveredBar(null)}
                         style={{ position: 'absolute', bottom: 0, left: 0, right: 0,
                           height: hDespProj, background: C.desp,
                           opacity: hov && hoveredBar?.side === 'despProj' ? 0.45 : 0.28,
                           borderRadius: '3px 3px 0 0', zIndex: 0, cursor: 'pointer', transition: 'opacity 0.15s' }}>
                      {hov && hoveredBar?.side === 'despProj' && <TT color={C.desp}>{fmtSemCentavos(despProj)}</TT>}
                    </div>
                  )}
                  {/* Parcelas futuras (meses sem real) */}
                  {!d.temReal && hParcFut > 0 && (
                    <div onMouseEnter={() => setHoveredBar({ mesIdx: i, side: 'parc', valor: parcFut })}
                         onMouseLeave={() => setHoveredBar(null)}
                         style={{ position: 'absolute', bottom: 0, left: 0, right: 0,
                           height: hParcFut, background: C.desp,
                           opacity: hov && hoveredBar?.side === 'parc' ? 1 : 0.85,
                           borderRadius: '3px 3px 0 0', zIndex: 1, transition: 'opacity 0.15s' }}>
                      {hov && hoveredBar?.side === 'parc' && <TT color={C.desp}>{fmtSemCentavos(parcFut)}</TT>}
                    </div>
                  )}
                  {/* Barra real (por cima de tudo) */}
                  {d.temReal && hDespReal > 0 && (
                    <div onMouseEnter={() => setHoveredBar({ mesIdx: i, side: 'desp', valor: d.despReal })}
                         onMouseLeave={() => setHoveredBar(null)}
                         style={{ position: 'absolute', bottom: 0, left: 0, right: 0,
                           height: hDespReal, background: C.desp,
                           opacity: hov && hoveredBar?.side === 'desp' ? 1 : 0.85,
                           borderRadius: '3px 3px 0 0', zIndex: 1, transition: 'opacity 0.15s' }}>
                      {hov && hoveredBar?.side === 'desp' && <TT color={C.desp}>{fmtSemCentavos(d.despReal)}</TT>}
                      {/* Linha branca só quando real > projetado */}
                      {hDespProj > 0 && hDespReal > hDespProj && (
                        <div onMouseEnter={() => setHoveredBar({ mesIdx: i, side: 'despMarca', valor: despProj })}
                             onMouseLeave={() => setHoveredBar(null)}
                             style={{ position: 'absolute', left: 0, right: 0, bottom: hDespProj,
                               height: 2, background: 'rgba(255,255,255,0.80)', zIndex: 3, cursor: 'crosshair' }}>
                          {hov && hoveredBar?.side === 'despMarca' && <TT color={C.desp}>Proj: {fmtSemCentavos(despProj)}</TT>}
                        </div>
                      )}
                    </div>
                  )}
                </div>

              </div>

              {/* Rótulo do mês */}
              <div style={{ fontSize: FONT.xs, color: C.textMuted, fontWeight: 500, marginTop: 4, minHeight: 16 }}>{d.mes}</div>

              {/* Saldo do mês — real ou projetado */}
              {(() => {
                const saldo = d.temReal ? d.saldoReal : (d.recProj || 0) - (projetadoPorMes?.[i] || 0);
                const isProj = !d.temReal;
                const cor = saldo > 0 ? C.rec : saldo < 0 ? C.desp : C.textMuted;
                return (
                  <div style={{ fontSize: FONT.sm, color: isProj ? cor + 'AA' : cor, fontWeight: 600, lineHeight: 1.4, fontStyle: isProj ? 'italic' : 'normal', minHeight: 18 }}>
                    {saldo !== 0
                      ? (saldo > 0 ? '+' : '') + 'R$ ' + Math.round(Math.abs(saldo)).toLocaleString('pt-BR')
                      : <span style={{ color: C.textMuted }}>—</span>}
                  </div>
                );
              })()}

              {/* Saldo acumulado — sempre visível (real=sólido / projetado=itálico) */}
              {(() => {
                const isProj = !d.temReal;
                const cor = acum > 0 ? C.rec : acum < 0 ? C.desp : C.textMuted;
                return (
                  <div style={{ fontSize: FONT.sm, color: isProj ? cor + 'AA' : cor, fontWeight: 600, lineHeight: 1.4, fontStyle: isProj ? 'italic' : 'normal', minHeight: 18 }}>
                    {acum !== 0 ? (acum > 0 ? '+' : '') + 'R$ ' + Math.round(Math.abs(acum)).toLocaleString('pt-BR') : '—'}
                  </div>
                );
              })()}
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTE: Gráfico de Gastos por Conta (barras empilhadas)
// ══════════════════════════════════════════════════════════════════════════════

// Paleta de cores para as contas (até 8 contas)
const CORES_CONTA = [
  '#60A5FA', // azul
  '#F472B6', // rosa
  '#34D399', // verde menta
  '#FBBF24', // âmbar
  '#A78BFA', // violeta
  '#F87171', // vermelho
  '#38BDF8', // azul claro
  '#FB923C', // laranja
];

function GraficoContasMensais({ contas, despesasPorMesConta, parcelasFuturasPorConta, projetadoPorMes, dadosMensais, onMesClick, anoAtivo }) {
  const [tooltip, setTooltip] = useState(null);
  const svgRef = useRef(null);

  // Lista de nomes de contas ordenada pela que tem mais gastos
  const nomesContas = useMemo(() => {
    const totais = {};
    for (let m = 0; m < 12; m++) {
      const mes = despesasPorMesConta[m] || {};
      for (const [conta, v] of Object.entries(mes)) {
        totais[conta] = (totais[conta] || 0) + v;
      }
    }
    return Object.keys(totais).sort((a, b) => totais[b] - totais[a]);
  }, [despesasPorMesConta]);

  // Mapa conta → cor
  const corConta = useMemo(() => {
    const map = {};
    nomesContas.forEach((n, i) => { map[n] = CORES_CONTA[i % CORES_CONTA.length]; });
    return map;
  }, [nomesContas]);

  // Dados por mês: segmentos coloridos (real+parc por conta) + sombra projetada
  const dadosMes = useMemo(() => MESES.map((_, i) => {
    const real = despesasPorMesConta[i] || {};
    const parc = parcelasFuturasPorConta[i] || {};
    // Empilha real + parcelamentos por conta (mesma cor, sem distinção)
    const segmentos = {};
    for (const [c, v] of Object.entries(real)) segmentos[c] = (segmentos[c] || 0) + v;
    for (const [c, v] of Object.entries(parc)) segmentos[c] = (segmentos[c] || 0) + v;
    const totalColorido = Object.values(segmentos).reduce((s, v) => s + v, 0);
    const proj = projetadoPorMes[i] || 0;
    return { segmentos, totalColorido, proj };
  }), [despesasPorMesConta, parcelasFuturasPorConta, projetadoPorMes]);

  // Escala Y: máximo entre projetado e total colorido em qualquer mês
  const maxVal = useMemo(() =>
    Math.max(...dadosMes.map(d => Math.max(d.totalColorido, d.proj)), 1) * 1.08,
  [dadosMes]);

  // SVG dimensions — altura maior para acomodar rótulo + total abaixo
  const W = 1000, H = 260;
  const PAD = { top: 16, right: 32, bottom: 52, left: 76 }; // bottom maior para 2 linhas
  const chartW = W - PAD.left - PAD.right;
  const chartH = H - PAD.top - PAD.bottom;
  const barW = chartW / 12;
  const barPad = barW * 0.16;

  const xOf = i => PAD.left + i * barW;
  const yOf = v => PAD.top + chartH - (v / maxVal) * chartH;
  const hOf = v => Math.max(0, (v / maxVal) * chartH);

  // Rótulos Y
  const gridVals = useMemo(() => {
    const count = 4;
    return Array.from({ length: count }, (_, k) => (maxVal / count) * (k + 1));
  }, [maxVal]);

  // Formata valor sem centavos: R$ 8.200
  const fmtSemCentavos = v =>
    'R$ ' + Math.round(v).toLocaleString('pt-BR');

  const handleMouseMove = useCallback((e) => {
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const svgX = ((e.clientX - rect.left) / rect.width) * W;
    const rawI = (svgX - PAD.left) / barW;
    const mesIdx = Math.max(0, Math.min(11, Math.floor(rawI)));
    const d = dadosMes[mesIdx];
    if (!d || (d.totalColorido === 0 && d.proj === 0)) { setTooltip(null); return; }
    const ttX = (e.clientX - rect.left) / rect.width;
    const ttY = (e.clientY - rect.top) / rect.height;
    setTooltip({ ttX, ttY, mesIdx, segmentos: d.segmentos, totalColorido: d.totalColorido, proj: d.proj });
  }, [dadosMes]);

  const handleMouseLeave = useCallback(() => setTooltip(null), []);
  const handleClick = useCallback((e) => {
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const svgX = ((e.clientX - rect.left) / rect.width) * W;
    const mesIdx = Math.max(0, Math.min(11, Math.floor((svgX - PAD.left) / barW)));
    onMesClick(mesIdx);
  }, [onMesClick]);

  return (
    <Card padding="20px 24px" style={{ marginBottom: 20 }}>
      {/* Cabeçalho */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text }}>
          Gastos por Conta — {anoAtivo}
        </div>
      </div>

      {/* Legenda */}
      <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginBottom: 14 }}>
        {nomesContas.map(n => (
          <span key={n} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: FONT.xs }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: corConta[n], display: 'inline-block' }} />
            <span style={{ color: C.textMuted }}>{n}</span>
          </span>
        ))}
        <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: FONT.xs }}>
          <span style={{ width: 10, height: 10, borderRadius: 2, background: C.textDim, opacity: 0.35, display: 'inline-block' }} />
          <span style={{ color: C.textDim, fontStyle: 'italic' }}>Projetado</span>
        </span>
      </div>

      {/* SVG */}
      <div style={{ position: 'relative' }}>
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`}
          style={{ width: '100%', height: 'auto', display: 'block', cursor: 'pointer' }}
          onMouseMove={handleMouseMove} onMouseLeave={handleMouseLeave} onClick={handleClick}>

          {/* Rótulos Y */}
          {gridVals.map((v, k) => (
            <text key={k} x={PAD.left - 8} y={yOf(v) + 4} textAnchor="end"
              fill={C.textDim} fontSize="9" fontFamily="Inter,sans-serif">
              {v >= 1000 ? `${(v / 1000).toFixed(v >= 10000 ? 0 : 1)}k` : v.toFixed(0)}
            </text>
          ))}

          {/* Linha de base */}
          <line x1={PAD.left} y1={PAD.top + chartH} x2={PAD.left + chartW} y2={PAD.top + chartH}
            stroke={C.border} strokeWidth="0.8" opacity="0.5" />

          {/* Barras por mês */}
          {dadosMes.map((d, i) => {
            const x = xOf(i) + barPad;
            const w = barW - barPad * 2;
            const baseY = PAD.top + chartH;

            // 1. Sombra do projetado — desenhada PRIMEIRO (atrás)
            const hProj = hOf(d.proj);
            const segOrdem = nomesContas.filter(n => (d.segmentos[n] || 0) > 0);
            // 2. Barras coloridas (real+parc) — por cima da sombra
            let yAcum = baseY;

            return (
              <g key={i}>
                {/* Sombra projetada */}
                {hProj > 0 && (
                  <rect x={x} y={baseY - hProj} width={w} height={hProj}
                    fill={C.text} opacity={0.1} rx="3" />
                )}
                {/* Segmentos coloridos empilhados */}
                {segOrdem.map((conta, si) => {
                  const v = d.segmentos[conta] || 0;
                  if (v <= 0) return null;
                  const h = hOf(v);
                  yAcum -= h;
                  const isTop = si === segOrdem.length - 1;
                  return (
                    <rect key={conta} x={x} y={yAcum} width={w} height={h}
                      fill={corConta[conta]} opacity={0.88}
                      rx={isTop ? '3' : '0'}
                      style={{ transition: 'opacity 0.15s' }}
                    />
                  );
                })}
              </g>
            );
          })}

          {/* Rótulo mês + total abaixo das barras */}
          {dadosMes.map((d, i) => {
            const cx = xOf(i) + barW / 2;
            const total = d.totalColorido;
            return (
              <g key={i}>
                {/* Nome do mês */}
                <text x={cx} y={PAD.top + chartH + 14} textAnchor="middle"
                  fill={C.textDim} fontSize="10" fontFamily="Inter,sans-serif">
                  {MESES[i]}
                </text>
                {/* Total (só se houver valor) */}
                {total > 0 && (
                  <text x={cx} y={PAD.top + chartH + 28} textAnchor="middle"
                    fill={C.textMuted} fontSize="8.5" fontFamily="Inter,sans-serif" fontWeight="600">
                    {fmtSemCentavos(total)}
                  </text>
                )}
              </g>
            );
          })}

          {/* Linha vertical tooltip */}
          {tooltip && (
            <line x1={xOf(tooltip.mesIdx) + barW / 2} y1={PAD.top}
              x2={xOf(tooltip.mesIdx) + barW / 2} y2={PAD.top + chartH}
              stroke={C.brand} strokeWidth="1" strokeDasharray="3 3" opacity="0.6" />
          )}
        </svg>

        {/* Tooltip */}
        {tooltip && (() => {
          const left = tooltip.ttX > 0.72 ? 'auto' : `${tooltip.ttX * 100}%`;
          const right = tooltip.ttX > 0.72 ? `${(1 - tooltip.ttX) * 100}%` : 'auto';
          return (
            <div style={{
              position: 'absolute',
              top: `${Math.min(tooltip.ttY * 100, 50)}%`,
              left, right,
              transform: tooltip.ttX > 0.72 ? 'translateX(0)' : 'translateX(10px)',
              background: C.card, border: `1px solid ${C.border}`,
              borderRadius: RADIUS.md, padding: '10px 14px',
              pointerEvents: 'none', zIndex: 10, minWidth: 200,
              boxShadow: '0 4px 20px rgba(0,0,0,0.5)',
            }}>
              <div style={{ fontSize: FONT.sm, fontWeight: 700, color: C.text, marginBottom: 8 }}>
                {MESES_FULL[tooltip.mesIdx]}
              </div>
              {/* Contas coloridas */}
              {nomesContas.filter(n => (tooltip.segmentos[n] || 0) > 0).map(n => (
                <div key={n} style={{ display: 'flex', justifyContent: 'space-between', gap: 16, marginBottom: 4 }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: FONT.xs, color: C.textMuted }}>
                    <span style={{ width: 8, height: 8, borderRadius: 2, background: corConta[n], display: 'inline-block' }} />
                    {n}
                  </span>
                  <span style={{ fontSize: FONT.xs, fontWeight: 700, color: corConta[n] }}>
                    {fmtSemCentavos(tooltip.segmentos[n])}
                  </span>
                </div>
              ))}
              {/* Total realizado+parc */}
              <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 6, marginTop: 4, display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: FONT.xs, color: C.textMuted, fontWeight: 600 }}>Total realizado</span>
                <span style={{ fontSize: FONT.xs, fontWeight: 800, color: C.text }}>{fmtSemCentavos(tooltip.totalColorido)}</span>
              </div>
              {/* Projetado (se houver) */}
              {tooltip.proj > 0 && (
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                  <span style={{ fontSize: FONT.xs, color: C.textDim, fontStyle: 'italic' }}>Projetado</span>
                  <span style={{ fontSize: FONT.xs, color: C.textDim, fontStyle: 'italic' }}>{fmtSemCentavos(tooltip.proj)}</span>
                </div>
              )}
              <div style={{ fontSize: 10, color: C.textDim, marginTop: 6, textAlign: 'center' }}>clique para abrir o mês</div>
            </div>
          );
        })()}
      </div>
    </Card>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTE: Parcelamentos por Mês
// ══════════════════════════════════════════════════════════════════════════════
function GraficoParcelamentos({ totalParcelasFut, anoAtivo }) {
  const max = Math.max(1, ...totalParcelasFut.map(v => v || 0));
  const fmtVal = v => 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <Card padding="20px 24px" style={{ marginBottom: 20, display: 'flex', flexDirection: 'column' }}>
      <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text, marginBottom: 4 }}>
        Parcelamentos
      </div>
      <div style={{ fontSize: FONT.xs, color: C.textMuted, marginBottom: 16 }}>
        Valores já comprometidos em parcelamentos
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
        {MESES.map((mes, i) => {
          const val = totalParcelasFut[i] || 0;
          const pct = Math.max(0, (val / max) * 100);
          return (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              {/* Label do mês */}
              <div style={{ width: 28, fontSize: FONT.xs, color: C.textMuted, fontWeight: 500, flexShrink: 0 }}>
                {mes}
              </div>
              {/* Barra */}
              <div style={{ flex: 1, height: 8, background: C.border, borderRadius: RADIUS.full, overflow: 'hidden' }}>
                <div style={{
                  height: '100%',
                  width: `${pct}%`,
                  background: val > 0 ? '#A78BFA' : 'transparent',
                  borderRadius: RADIUS.full,
                  transition: 'width 0.3s ease',
                }} />
              </div>
              {/* Valor */}
              <div style={{ width: 90, textAlign: 'right', fontSize: FONT.xs, color: val > 0 ? '#A78BFA' : C.textMuted, fontWeight: 600, flexShrink: 0 }}>
                {val > 0 ? fmtVal(val) : '—'}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTE: Gráfico de Linhas SVG
// ══════════════════════════════════════════════════════════════════════════════
function GraficoLinhas({ seriesData, dadosMensais, onMesClick, anoAtivo }) {
  const [tooltip, setTooltip] = useState(null);
  // tooltip: { x, y, mesIdx, itens: [{label, cor, valor, isProj}] } | null

  // Dimensões do SVG (coordenadas internas)
  const W = 1000, H = 320;
  const PAD = { top: 28, right: 32, bottom: 40, left: 76 };
  const chartW = W - PAD.left - PAD.right;
  const chartH = H - PAD.top  - PAD.bottom;

  // Valor máximo entre todos os pontos (para escala Y)
  const maxVal = useMemo(() => {
    let m = 0;
    seriesData.forEach(s => s.pontos.forEach(p => { if (p.v !== null && p.v > m) m = p.v; }));
    return m > 0 ? m * 1.25 : 1000; // +25% de margem no topo — abre espaço entre linhas
  }, [seriesData]);

  // Converte índice de mês (0-11) e valor para coordenadas SVG
  const xOf = i => PAD.left + (i / 11) * chartW;
  const yOf = v => PAD.top  + chartH - (v / maxVal) * chartH;

  // Gera os segmentos de polyline para uma série (descontinua onde v===null)
  function buildSegments(pontos) {
    const segments = [];
    let seg = [];
    pontos.forEach(p => {
      if (p.v !== null) {
        seg.push(p);
      } else {
        if (seg.length >= 1) segments.push([...seg]);
        seg = [];
      }
    });
    if (seg.length >= 1) segments.push(seg);
    return segments;
  }

  // Linhas de grade Y (4 divisões)
  const gridLines = useMemo(() => {
    const count = 4;
    return Array.from({ length: count + 1 }, (_, k) => {
      const v = (maxVal / count) * k;
      return { v, y: yOf(v) };
    });
  }, [maxVal]);

  // Handler: exibe tooltip no mês mais próximo ao cursor
  const svgRef = useRef(null);
  const handleMouseMove = useCallback((e) => {
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    // Converte px de tela para coordenadas SVG
    const scaleX = W / rect.width;
    const svgX = (e.clientX - rect.left) * scaleX;
    const rawI = ((svgX - PAD.left) / chartW) * 11;
    const mesIdx = Math.max(0, Math.min(11, Math.round(rawI)));

    const itens = seriesData
      .map(s => ({ label: s.label, cor: s.cor, valor: s.pontos[mesIdx].v, isProj: s.pontos[mesIdx].isProj }))
      .filter(it => it.valor !== null);

    if (!itens.length) { setTooltip(null); return; }

    // Posição do tooltip em % do container (para usar no div overlay)
    const ttX = (e.clientX - rect.left) / rect.width;
    const ttY = (e.clientY - rect.top)  / rect.height;
    setTooltip({ ttX, ttY, mesIdx, itens });
  }, [seriesData]);

  const handleMouseLeave = useCallback(() => setTooltip(null), []);
  const handleClick = useCallback(() => {
    if (tooltip) onMesClick(tooltip.mesIdx);
  }, [tooltip, onMesClick]);

  return (
    <Card padding="20px 24px" style={{ marginBottom: 0 }}>
      <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text, marginBottom: 4 }}>
        Evolução Financeira — {anoAtivo}
      </div>
      {/* Legenda */}
      <div style={{ display: 'flex', gap: 18, flexWrap: 'wrap', marginBottom: 14 }}>
        {seriesData.map(s => (
          <span key={s.grupo} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: FONT.xs, color: C.textMuted }}>
            <span style={{ width: 22, height: 3, background: s.cor, borderRadius: 2, display: 'inline-block' }} />
            <span style={{ color: s.cor, fontWeight: 600 }}>{s.label}</span>
          </span>
        ))}
      </div>

      {/* SVG + tooltip overlay */}
      <div className="mb-chart-area" style={{ position: 'relative' }}>
        <svg
          ref={svgRef}
          viewBox={`0 0 ${W} ${H}`}
          style={{ width: '100%', height: 'auto', display: 'block', cursor: 'crosshair', minHeight: 200 }}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          onClick={handleClick}
        >
          {/* Rótulos do eixo Y — sem grade, texto sutil */}
          {gridLines.map(({ v, y }, k) => (
            k === 0 ? null : (
              <text key={k} x={PAD.left - 8} y={y + 4} textAnchor="end"
                fill={C.textDim} fontSize="9" fontFamily="Inter,sans-serif">
                {v >= 1000 ? `${(v / 1000).toFixed(v >= 10000 ? 0 : 1)}k` : v.toFixed(0)}
              </text>
            )
          ))}

          {/* Linha de base sutil */}
          <line x1={PAD.left} y1={PAD.top + chartH} x2={PAD.left + chartW} y2={PAD.top + chartH}
            stroke={C.border} strokeWidth="0.8" opacity="0.5" />

          {/* Rótulos do eixo X (meses) */}
          {MESES.map((m, i) => (
            <text key={i} x={xOf(i)} y={H - 4} textAnchor="middle"
              fill={C.textDim} fontSize="10" fontFamily="Inter,sans-serif">
              {m}
            </text>
          ))}

          {/* Séries */}
          {seriesData.map(s => {
            const segments = buildSegments(s.pontos);
            return (
              <g key={s.grupo}>
                {segments.map((seg, si) => {
                  // Um segmento pode ser misto (real+proj), precisa separar
                  // Varre os pontos do segmento e parte em sub-segmentos real/proj
                  const subSegs = [];
                  let cur = [];
                  let curProj = seg[0].isProj;
                  seg.forEach(p => {
                    if (p.isProj !== curProj) {
                      // Ao mudar de tipo, inclui o ponto atual em ambos para continuidade
                      cur.push(p);
                      subSegs.push({ pts: [...cur], isProj: curProj });
                      cur = [cur[cur.length - 1]]; // conecta
                      curProj = p.isProj;
                    } else {
                      cur.push(p);
                    }
                  });
                  if (cur.length) subSegs.push({ pts: cur, isProj: curProj });

                  return subSegs.map((ss, ssi) => {
                    if (ss.pts.length < 2) {
                      // Ponto único: desenha só o círculo (sem linha)
                      const p = ss.pts[0];
                      return (
                        <circle key={`${si}-${ssi}`}
                          cx={xOf(p.mesIdx)} cy={yOf(p.v)}
                          r="2.5" fill={s.cor}
                          opacity={ss.isProj ? 0.55 : 0.9}
                        />
                      );
                    }
                    const pts = ss.pts.map(p => `${xOf(p.mesIdx)},${yOf(p.v)}`).join(' ');
                    return (
                      <polyline key={`${si}-${ssi}`}
                        points={pts}
                        fill="none"
                        stroke={s.cor}
                        strokeWidth="1.5"
                        strokeDasharray={ss.isProj ? '5 4' : 'none'}
                        opacity={ss.isProj ? 0.6 : 1}
                        strokeLinejoin="round"
                        strokeLinecap="round"
                      />
                    );
                  });
                })}

                {/* Pontos (circles) em cada mês com dado — menores e sutis */}
                {s.pontos.map((p, i) => p.v === null ? null : (
                  <circle key={i}
                    cx={xOf(i)} cy={yOf(p.v)}
                    r="2.5"
                    fill={p.isProj ? C.bg : s.cor}
                    stroke={s.cor}
                    strokeWidth="1.2"
                    opacity={p.isProj ? 0.6 : 0.9}
                  />
                ))}
              </g>
            );
          })}

          {/* Linha vertical do tooltip */}
          {tooltip && (
            <line
              x1={xOf(tooltip.mesIdx)} y1={PAD.top}
              x2={xOf(tooltip.mesIdx)} y2={PAD.top + chartH}
              stroke={C.brand} strokeWidth="1.5" strokeDasharray="3 3" opacity="0.8"
            />
          )}
        </svg>

        {/* Tooltip overlay (div flutuante) */}
        {tooltip && (() => {
          const left = tooltip.ttX > 0.75 ? 'auto' : `${tooltip.ttX * 100}%`;
          const right = tooltip.ttX > 0.75 ? `${(1 - tooltip.ttX) * 100}%` : 'auto';
          return (
            <div style={{
              position: 'absolute',
              top: `${Math.min(tooltip.ttY * 100, 60)}%`,
              left, right,
              transform: tooltip.ttX > 0.75 ? 'translateX(0)' : 'translateX(8px)',
              background: C.card,
              border: `1px solid ${C.border}`,
              borderRadius: RADIUS.md,
              padding: '10px 14px',
              pointerEvents: 'none',
              zIndex: 10,
              minWidth: 180,
              boxShadow: '0 4px 20px rgba(0,0,0,0.5)',
            }}>
              <div style={{ fontSize: FONT.sm, fontWeight: 700, color: C.text, marginBottom: 8 }}>
                {MESES_FULL[tooltip.mesIdx]}
              </div>
              {tooltip.itens.map(it => (
                <div key={it.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 16, marginBottom: 4 }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: FONT.xs, color: it.cor }}>
                    <span style={{ width: 8, height: 8, borderRadius: '50%', background: it.cor, display: 'inline-block' }} />
                    {it.label}
                    {it.isProj && <span style={{ color: C.textDim, fontStyle: 'italic' }}> proj.</span>}
                  </span>
                  <span style={{ fontSize: FONT.xs, fontWeight: 700, color: it.cor }}>
                    {fmtBRL(it.valor)}
                  </span>
                </div>
              ))}
              <div style={{ fontSize: 10, color: C.textDim, marginTop: 6, textAlign: 'center' }}>
                clique para abrir o mês
              </div>
            </div>
          );
        })()}
      </div>
    </Card>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTE: Vista Mensal (igual ao original)
// ══════════════════════════════════════════════════════════════════════════════
function VistaMensal({
  mesAtivo, mesesSelecionados, grupos, totaisGrupo, categorias,
  recMes, despMes, saldoRealizado, saldoProjetado, taxaPoupanca,
  totalParcelasMes, totalParcelasFut,
  dadosMensais, maxBarValue,
  planMes, realizadoMes, parcelasMes,
  onMesClick, vistaAtiva,
}) {
  // Label dinâmico: único mês ou múltiplos
  const mesesLabel = mesesSelecionados && mesesSelecionados.size > 1
    ? [...mesesSelecionados].sort((a,b)=>a-b).map(i => MESES[i]).join(', ')
    : mesAtivo !== null ? MESES_FULL[mesAtivo] : '';
  const saldoLabel = mesesSelecionados && mesesSelecionados.size > 1 ? 'Saldo do Período' : 'Saldo do Mês';
  return (
    <>
      {/* ── KPIs mensais ────────────────────────────────────────────────── */}
      <div className="mb-grid-5" style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14, marginBottom: 28 }}>
        <KPICard label="Receitas" value={fmtBRL(recMes.realizado)} sub={`Proj: ${fmtBRL(recMes.projetado)}`} color={C.rec} />
        <KPICard label="Despesas" value={fmtBRL(despMes.realizado)} sub={`Proj: ${fmtBRL(despMes.projetado)}`} color={C.desp} />
        <KPICard label="Saldo do Período" value={fmtBRL(saldoRealizado)} sub={`Proj: ${fmtBRL(saldoProjetado)}`} color={saldoRealizado >= 0 ? C.rec : C.desp} />
        <KPICard label="Taxa de Economia" value={`${taxaPoupanca.toFixed(1)}%`} sub={taxaPoupanca >= 10 ? '✅ Meta atingida' : '⚠️ Abaixo de 10%'} color={taxaPoupanca >= 10 ? C.green : C.yellow} />
        <KPICard label="Parcelas do Mês" value={fmtBRL(totalParcelasMes)} sub="comprometido em parcelamentos" color="#C084FC" />
      </div>

      <div className="mb-grid-main" style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 20, marginBottom: 20 }}>
        {/* ── Realizado vs Projetado ──────────────────────────────────────── */}
        <Card padding="20px">
          <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text, marginBottom: 16 }}>
            Realizado vs. Projetado — {mesesLabel}
          </div>
          {grupos.map(grupo => {
            const t = totaisGrupo(grupo, mesAtivo);
            const isReceita = grupo === GRUPOS.RECEITAS;
            const isInvestimento = grupo === GRUPOS.INVESTIMENTOS;
            const isBomPassar = isReceita || isInvestimento;
            const temProj = t.projetado > 0;
            const temReal = (t.realizado + t.parcelas) > 0;
            const pct = temProj ? (t.realizado / t.projetado) * 100 : 100;
            // se não tem projeção mas tem realizado → barra cheia na cor padrão
            const pctCor = !temProj
              ? (isReceita ? C.rec : C.desp)
              : pct >= 100 ? (isBomPassar ? C.info : C.desp)
              : C.rec;
            return (
              <div key={grupo} style={{ marginBottom: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, alignItems: 'center' }}>
                  <span style={{ fontSize: FONT.sm, fontWeight: 600, color: C.text }}>{grupo}</span>
                  <div style={{ display: 'flex', gap: 14, fontSize: FONT.xs, color: C.textMuted }}>
                    {t.parcelas > 0 && <span style={{ color: '#C084FC' }}>Parcelas: {fmtBRL(t.parcelas)}</span>}
                    <span>Real: <strong style={{ color: isReceita ? C.rec : C.desp }}>{fmtBRL(t.realizado)}</strong></span>
                    <span>Proj: <strong style={{ color: C.text }}>{fmtBRL(t.projetado)}</strong></span>
                    <span style={{ minWidth: 36, textAlign: 'right', fontWeight: pct >= 100 ? 700 : 500, color: pctCor }}>
                      {temProj ? `${pct.toFixed(0)}%` : '—'}
                    </span>
                  </div>
                </div>
                {(temProj || temReal) && (
                  <ProgressBar
                    value={temProj ? t.realizado + t.parcelas : 1}
                    max={temProj ? t.projetado : 1}
                    height={7}
                    color={pctCor}
                  />
                )}
              </div>
            );
          })}
        </Card>

        {/* ── Endividamento Futuro ─────────────────────────────────────────── */}
        <Card padding="20px">
          <div style={{ fontSize: FONT.base, fontWeight: 700, color: C.text, marginBottom: 4 }}>Endividamento Futuro</div>
          <div style={{ fontSize: FONT.xs, color: C.textMuted, marginBottom: 16 }}>Valores já comprometidos em parcelamentos</div>
          {MESES.map((m, i) => {
            const total = totalParcelasFut[i];
            const maxP  = Math.max(...totalParcelasFut, 1);
            return (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <span style={{ width: 28, fontSize: FONT.xs, color: vistaAtiva === i ? C.brand : C.textMuted, fontWeight: vistaAtiva === i ? 700 : 400 }}>{m}</span>
                <div style={{ flex: 1, background: C.bg, borderRadius: RADIUS.full, height: 6, overflow: 'hidden' }}>
                  <div style={{ width: `${(total / maxP) * 100}%`, height: '100%', background: total > 0 ? '#C084FC' : C.border, borderRadius: RADIUS.full }} />
                </div>
                <span style={{ fontSize: FONT.xs, color: total > 0 ? '#C084FC' : C.textDim, width: 70, textAlign: 'right', fontWeight: total > 0 ? 600 : 400 }}>
                  {total > 0 ? fmtBRL(total) : '—'}
                </span>
              </div>
            );
          })}
        </Card>
      </div>

      {/* ── Detalhamento por categoria ───────────────────────────────────── */}
      <div className="mb-grid-2" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {grupos.map(grupo => {
          const cats = categorias.filter(c => c.grupo === grupo);
          const isReceita = grupo === GRUPOS.RECEITAS;
          const catsComDados = cats.filter(c => {
            const r = realizadoMes[c.id];
            const p = planMes[c.id]?.projetado || 0;
            return (r?.despesa || r?.receita || 0) > 0 || p > 0;
          });
          if (!catsComDados.length) return null;
          return (
            <Card key={grupo} padding="18px 20px">
              <div style={{ fontWeight: 700, color: grupoColor(grupo), fontSize: FONT.sm, marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.07em' }}>
                {grupo}
              </div>
              {catsComDados.map(cat => {
                const proj = planMes[cat.id]?.projetado || 0;
                const parc = parcelasMes[cat.id] || planMes[cat.id]?.parcelas || 0;
                const real = isReceita ? (realizadoMes[cat.id]?.receita || 0) : (realizadoMes[cat.id]?.despesa || 0);
                const temProj = proj > 0;
                const temReal = (real + parc) > 0;
                const pct  = temProj ? ((real + parc) / proj) * 100 : 100;
                const isBomPassar = isReceita || grupo === GRUPOS.INVESTIMENTOS;
                const pctCor = !temProj
                  ? (isReceita ? C.rec : C.desp)
                  : pct >= 100 ? (isBomPassar ? C.info : C.desp)
                  : C.rec;
                const emoji = !temProj ? '' : pct >= 100 ? (isBomPassar ? '🔵' : '🔴') : '🟢';
                return (
                  <div key={cat.id} style={{ marginBottom: 10 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, alignItems: 'center' }}>
                      <span style={{ fontSize: FONT.xs, color: C.text }}>{cat.nome}</span>
                      <div style={{ display: 'flex', gap: 10, alignItems: 'center', fontSize: FONT.xs }}>
                        {parc > 0 && <span style={{ color: '#C084FC' }}>📌 {fmtBRL(parc)}</span>}
                        <span style={{ color: isReceita ? C.rec : C.desp, fontWeight: 600 }}>{fmtBRL(real)}</span>
                        {proj > 0 && <span style={{ color: C.textMuted }}>/ {fmtBRL(proj)}</span>}
                        {proj > 0 && <span style={{ fontSize: 12 }}>{emoji}</span>}
                      </div>
                    </div>
                    {(temProj || temReal) && (
                      <ProgressBar
                        value={temProj ? real + parc : 1}
                        max={temProj ? proj : 1}
                        height={4}
                        color={pctCor}
                      />
                    )}
                  </div>
                );
              })}
            </Card>
          );
        })}
      </div>
    </>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function KPICard({ label, value, sub, color }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: RADIUS.md, padding: '16px 18px' }}>
      <div style={{ fontSize: FONT.xs, color: C.textMuted, marginBottom: 6, fontWeight: 500 }}>{label}</div>
      <div style={{ fontSize: FONT.xl, fontWeight: 700, color, lineHeight: 1, marginBottom: 4 }}>{value}</div>
      {sub && <div style={{ fontSize: FONT.xs, color: C.textDim }}>{sub}</div>}
    </div>
  );
}

function grupoColor(grupo) {
  const map = {
    'Receitas': C.rec,
    'Despesas Fixas': C.desp,
    'Consumo Mensal': C.warn,
    'Dívidas': '#C084FC',
    'Investimentos': C.info,
    'Fluxo Interno': C.textMuted,
  };
  return map[grupo] || C.textMuted;
}
