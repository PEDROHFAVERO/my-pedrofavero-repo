import { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase.js';
import { EDGE_FN_URL, SUPABASE_ANON_KEY } from '../lib/appConfig.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [sessao, setSessao] = useState(null);
  // sessao = { user, perfil, clienteId (só para role=cliente) }
  const [carregando, setCarregando] = useState(true);

  // ── Restaura sessão ao carregar ─────────────────────────────────────────────
  useEffect(() => {
    // Timeout de segurança: se o Supabase não responder em 8s, libera a tela de login
    const timeout = setTimeout(() => setCarregando(false), 8000);

    supabase.auth.getSession().then(({ data: { session } }) => {
      clearTimeout(timeout);
      if (session) {
        resolverSessao(session.user).then(s => {
          setSessao(s);
          setCarregando(false);
        });
      } else {
        setCarregando(false);
      }
    }).catch(() => { clearTimeout(timeout); setCarregando(false); });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        resolverSessao(session.user).then(s => setSessao(s));
      } else {
        setSessao(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  // Resolve qual perfil o usuário tem: manager, planejador ou cliente
  async function resolverSessao(user) {
    // 1. Verifica primeiro se é cliente (cliente_acessos tem prioridade para evitar
    //    que um usuário cliente seja tratado como planejador por erro de RLS)
    const { data: acesso, error: erroAcesso } = await supabase
      .from('cliente_acessos')
      .select('cliente_id, nome')
      .eq('user_id', user.id)
      .maybeSingle();

    console.log('[resolverSessao] cliente_acessos:', { acesso, erroAcesso, userId: user.id });

    if (acesso) {
      return {
        user,
        perfil: { id: user.id, nome: acesso.nome, email: user.email, role: 'cliente', ativo: true },
        clienteId: acesso.cliente_id,
      };
    }

    // 2. Tenta planejadores (manager ou planejador)
    const { data: perfil, error: erroPerfil } = await supabase
      .from('planejadores')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();

    console.log('[resolverSessao] planejadores:', { perfil, erroPerfil, userId: user.id });

    if (perfil) {
      return { user, perfil, clienteId: null };
    }

    return { user, perfil: null, clienteId: null };
  }

  // ── Login ──────────────────────────────────────────────────────────────────
  async function login(email, senha) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password: senha });
    if (error) throw new Error(error.message);

    const s = await resolverSessao(data.user);
    if (!s.perfil) throw new Error('Usuário não encontrado no sistema. Contacte o seu planejador.');
    if (!s.perfil.ativo) throw new Error('Conta desativada. Contacte o seu planejador.');
    setSessao(s);
    return s.perfil;
  }

  // ── Logout ─────────────────────────────────────────────────────────────────
  async function logout() {
    await supabase.auth.signOut();
    setSessao(null);
  }

  // ── Criar planejador (apenas Manager) ──────────────────────────────────────
  async function criarPlanejador({ nome, email, senha }) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password: senha,
      options: { data: { nome } },
    });
    if (error) throw new Error(error.message);
    if (!data.user) throw new Error('Erro ao criar usuário. Tente novamente.');

    const { error: err2 } = await supabase.from('planejadores').insert({
      id: data.user.id,
      nome,
      email,
      role: 'planejador',
    });
    if (err2) throw new Error(err2.message);

    return data.user;
  }

  // ── Listar planejadores (apenas Manager) ───────────────────────────────────
  async function listarPlanejadores() {
    const { data, error } = await supabase
      .from('planejadores')
      .select('*')
      .eq('role', 'planejador')
      .order('criado_em', { ascending: true });
    if (error) throw new Error(error.message);
    return data || [];
  }

  // ── Renomear planejador ─────────────────────────────────────────────────────
  async function renomearPlanejador(id, novoNome) {
    const { error } = await supabase
      .from('planejadores')
      .update({ nome: novoNome })
      .eq('id', id);
    if (error) throw new Error(error.message);
  }

  // ── Ativar / Desativar planejador ───────────────────────────────────────────
  async function toggleAtivoPlanejador(id, ativo) {
    const { error } = await supabase
      .from('planejadores')
      .update({ ativo })
      .eq('id', id);
    if (error) throw new Error(error.message);
  }

  // ── Resetar senha (envia email de reset via Supabase) ──────────────────────
  async function resetarSenha(email) {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin,
    });
    if (error) throw new Error(error.message);
  }

  // ── Excluir planejador (apenas Manager) ────────────────────────────────────
  async function excluirPlanejador(id) {
    const { error } = await supabase
      .from('planejadores')
      .delete()
      .eq('id', id);
    if (error) throw new Error(error.message);
  }

  // ── Helper: chama a Edge Function admin-cliente ──────────────────────────
  async function chamarAdminFn(body) {
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
    console.log('[adminFn] session:', sessionData?.session, 'error:', sessionError);
    
    if (!sessionData?.session) {
      throw new Error('Sessão expirada. Faça login novamente.');
    }

    const FN_URL = EDGE_FN_URL;
    const ANON_KEY = SUPABASE_ANON_KEY;

    console.log('[adminFn] chamando:', FN_URL, 'body:', body);

    let res;
    try {
      res = await fetch(FN_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionData.session.access_token}`,
          'apikey': ANON_KEY,
        },
        body: JSON.stringify(body),
      });
    } catch (fetchErr) {
      console.error('[adminFn] fetch falhou:', fetchErr);
      throw new Error('Não foi possível conectar à função. Verifique sua conexão.');
    }

    const text = await res.text();
    console.log('[adminFn] resposta raw:', res.status, text);

    let json;
    try { json = JSON.parse(text); } catch { json = { error: text }; }

    if (!res.ok || json.error) throw new Error(json.error || `Erro HTTP ${res.status}`);
    return json;
  }

  // ── Criar acesso de cliente ─────────────────────────────────────────────────
  async function criarAcessoCliente({ clienteId, nome, email, senha }) {
    return chamarAdminFn({ action: 'criar', clienteId, nome, email, senha });
  }

  // ── Listar acessos de um cliente ────────────────────────────────────────────
  async function listarAcessosCliente(clienteId) {
    const { data, error } = await supabase
      .from('cliente_acessos')
      .select('id, user_id, nome, criado_em')
      .eq('cliente_id', clienteId)
      .order('criado_em', { ascending: true });
    if (error) throw new Error(error.message);
    return data || [];
  }

  // ── Resetar senha de acesso cliente ────────────────────────────────────────
  async function resetarSenhaCliente(userId, novaSenha) {
    return chamarAdminFn({ action: 'resetar_senha', userId, novaSenha });
  }

  // ── Excluir acesso de cliente ───────────────────────────────────────────────
  async function excluirAcessoCliente(userId) {
    return chamarAdminFn({ action: 'excluir', userId });
  }

  const value = {
    sessao,
    carregando,
    login,
    logout,
    criarPlanejador,
    listarPlanejadores,
    renomearPlanejador,
    toggleAtivoPlanejador,
    resetarSenha,
    excluirPlanejador,
    criarAcessoCliente,
    listarAcessosCliente,
    resetarSenhaCliente,
    excluirAcessoCliente,
    isManager:    sessao?.perfil?.role === 'manager',
    isPlanejador: sessao?.perfil?.role === 'planejador',
    isCliente:    sessao?.perfil?.role === 'cliente',
    logado: !!sessao,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider');
  return ctx;
}
