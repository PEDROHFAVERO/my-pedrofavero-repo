import { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '../lib/supabase.js';
import {
  criarClienteVazio, lerClienteDoLink, sincronizarCategorias, gerarId,
} from '../utils/clienteStorage.js';

const HubContext     = createContext(null);
const ClienteContext = createContext(null);

// ── Helpers Supabase ──────────────────────────────────────────────────────────

// Retorna o planejador_id efetivo:
// - se Manager está visualizando outro planejador → usa esse ID
// - caso contrário → usa o ID do usuário logado
function getPlanejadorId() {
  try {
    const viewing = localStorage.getItem('manager_viewing');
    if (viewing) return JSON.parse(viewing).id;
  } catch {}
  return null; // será preenchido pelo caller com user.id
}

async function carregarClientesSupabase(planejadorId) {
  const { data, error } = await supabase
    .from('clientes')
    .select('id, nome, dados, criado_em, atualizado_em')
    .eq('planejador_id', planejadorId)
    .order('criado_em', { ascending: true });
  if (error) throw error;
  return (data || []).map(row => ({
    ...row.dados,
    id: row.id,
    nome: row.nome,
    criadoEm: row.criado_em,
    atualizadoEm: row.atualizado_em,
  }));
}

async function salvarClienteSupabase(planejadorId, cliente) {
  const { id, nome, criadoEm, atualizadoEm, ...dados } = cliente;
  const { error } = await supabase
    .from('clientes')
    .upsert({
      id,
      planejador_id: planejadorId,
      nome,
      dados,
    }, { onConflict: 'id' });
  if (error) throw error;
}

async function removerClienteSupabase(clienteId) {
  const { error } = await supabase
    .from('clientes')
    .delete()
    .eq('id', clienteId);
  if (error) throw error;
}

// ── Provider ──────────────────────────────────────────────────────────────────

export function AppProvider({ children, userId, clienteIdFixo = null, modoClienteFixo = false }) {
  // userId: vem do AuthContext (usuário logado)
  // clienteIdFixo: quando role=cliente, o cliente já é determinado no login
  // modoClienteFixo: true → modo leitura total, só dashboard+categorizador
  const planejadorId = getPlanejadorId() || userId;

  const [hub, setHub]                         = useState({ clientes: [] });
  const [clienteAtivo, setClienteAtivoState]  = useState(null);
  const [modoLeitura, setModoLeitura]         = useState(modoClienteFixo);
  const [modoCliente, setModoCliente]         = useState(modoClienteFixo);
  const [paginaAtual, setPaginaAtualState]    = useState(modoClienteFixo ? 'dashboard' : 'hub');
  const [hubCarregado, setHubCarregado]       = useState(false);

  // Persiste página ativa no localStorage para sobreviver ao reload
  const setPaginaAtual = useCallback((pagina) => {
    setPaginaAtualState(pagina);
    try { localStorage.setItem('b2if_pagina_ativa', pagina); } catch {}
  }, []);

  const debounceRef  = useRef(null);
  const hubRef       = useRef(hub);
  const [salvando, setSalvando] = useState(false); // feedback visual
  useEffect(() => { hubRef.current = hub; }, [hub]);

  // ── Carrega clientes do Supabase ao montar ──────────────────────────────────
  useEffect(() => {
    if (!planejadorId) return;

    // Modo cliente fixo: carrega diretamente o cliente vinculado ao login
    if (modoClienteFixo && clienteIdFixo) {
      supabase
        .from('clientes')
        .select('id, nome, dados, criado_em, atualizado_em')
        .eq('id', clienteIdFixo)
        .single()
        .then(({ data, error }) => {
          console.log('[AppContext] carregar cliente fixo:', { data, error, clienteIdFixo });
          if (data && !error) {
            const cliente = {
              ...data.dados,
              id: data.id,
              nome: data.nome,
              criadoEm: data.criado_em,
              atualizadoEm: data.atualizado_em,
            };
            setClienteAtivoState(cliente);
          } else {
            console.error('[AppContext] falha ao carregar cliente:', error);
          }
          setHubCarregado(true);
        });
      return;
    }

    // Verifica link de leitura primeiro
    const clienteLink = lerClienteDoLink();
    if (clienteLink) {
      setClienteAtivoState(clienteLink);
      setModoLeitura(true);
      setPaginaAtual('dashboard');
      setHubCarregado(true);
      return;
    }

    carregarClientesSupabase(planejadorId).then(clientes => {
      const novoHub = { clientes };
      setHub(novoHub);
      hubRef.current = novoHub;

      // Restaura sessão anterior: cliente e página salvos no localStorage
      try {
        const clienteIdSalvo = localStorage.getItem('b2if_cliente_ativo_id');
        const paginaSalva    = localStorage.getItem('b2if_pagina_ativa');
        if (clienteIdSalvo) {
          const c = clientes.find(x => x.id === clienteIdSalvo);
          if (c) {
            const cAtualizado = { ...JSON.parse(JSON.stringify(c)), categorias: sincronizarCategorias(c.categorias) };
            setClienteAtivoState(cAtualizado);
            // Restaura página válida (dashboard, categorizador, planejador)
            const paginasValidas = ['dashboard', 'categorizador', 'planejador'];
            if (paginaSalva && paginasValidas.includes(paginaSalva)) {
              setPaginaAtualState(paginaSalva);
            } else {
              setPaginaAtualState('dashboard');
            }
          }
        }
      } catch {}

      setHubCarregado(true);
    }).catch(err => {
      console.error('Erro ao carregar clientes:', err);
      setHubCarregado(true);
    });
  }, [planejadorId]);

  // ── Debounce salvar no Supabase (300ms) ────────────────────────────────────
  const agendarSalvarCliente = useCallback((cliente) => {
    if (modoLeitura || !planejadorId) return;
    clearTimeout(debounceRef.current);
    setSalvando(true);
    debounceRef.current = setTimeout(() => {
      salvarClienteSupabase(planejadorId, cliente)
        .catch(console.error)
        .finally(() => setSalvando(false));
    }, 300);
  }, [modoLeitura, planejadorId]);

  // Flush ao sair
  useEffect(() => {
    const flush = () => {
      if (clienteAtivo && !modoLeitura && planejadorId) {
        salvarClienteSupabase(planejadorId, clienteAtivo).catch(console.error);
      }
    };
    window.addEventListener('beforeunload', flush);
    const onVis = () => { if (document.visibilityState === 'hidden') flush(); };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      window.removeEventListener('beforeunload', flush);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [clienteAtivo, modoLeitura, planejadorId]);

  // ── Ações de Hub ────────────────────────────────────────────────────────────
  const criarCliente = useCallback(async (nome) => {
    const novo = criarClienteVazio(nome);
    await salvarClienteSupabase(planejadorId, novo);
    setHub(h => {
      const next = { ...h, clientes: [...h.clientes, novo] };
      hubRef.current = next;
      return next;
    });
    setClienteAtivoState(novo);
    // Persiste ID no localStorage para sobreviver ao reload
    try { localStorage.setItem('b2if_cliente_ativo_id', novo.id); } catch {}
    setPaginaAtual('dashboard');
    return novo;
  }, [planejadorId, setPaginaAtual]);

  const abrirCliente = useCallback((clienteId) => {
    const c = hubRef.current.clientes.find(x => x.id === clienteId);
    if (c) {
      const cAtualizado = { ...JSON.parse(JSON.stringify(c)), categorias: sincronizarCategorias(c.categorias) };
      setClienteAtivoState(cAtualizado);
      try { localStorage.setItem('b2if_cliente_ativo_id', clienteId); } catch {}
      setPaginaAtual('dashboard');
    }
  }, [setPaginaAtual]);

  const removerCliente = useCallback(async (clienteId) => {
    await removerClienteSupabase(clienteId);
    setHub(h => {
      const next = { ...h, clientes: h.clientes.filter(c => c.id !== clienteId) };
      hubRef.current = next;
      return next;
    });
    setClienteAtivoState(prev => {
      if (prev?.id === clienteId) { setPaginaAtual('hub'); return null; }
      return prev;
    });
  }, []);

  const setClienteAtivo = useCallback((clienteAtualizado) => {
    setClienteAtivoState(clienteAtualizado);
    // Persiste ID do cliente ativo para restaurar após reload
    try {
      if (clienteAtualizado?.id) {
        localStorage.setItem('b2if_cliente_ativo_id', clienteAtualizado.id);
      }
    } catch {}
    if (modoLeitura) return;
    setHub(h => {
      const next = {
        ...h,
        clientes: h.clientes.map(c =>
          c.id === clienteAtualizado.id
            ? { ...clienteAtualizado, atualizadoEm: new Date().toISOString() }
            : c
        ),
      };
      hubRef.current = next;
      return next;
    });
    agendarSalvarCliente(clienteAtualizado);
  }, [modoLeitura, agendarSalvarCliente]);

  const salvarClienteAtivo = useCallback(() => {
    if (clienteAtivo && !modoLeitura && planejadorId) {
      salvarClienteSupabase(planejadorId, clienteAtivo).catch(console.error);
    }
  }, [clienteAtivo, modoLeitura, planejadorId]);

  const voltarHub = useCallback(() => {
    setClienteAtivoState(null);
    setPaginaAtual('hub');
    try {
      localStorage.removeItem('b2if_cliente_ativo_id');
      localStorage.removeItem('b2if_pagina_ativa');
    } catch {}
  }, [setPaginaAtual]);

  // ── Valores dos contextos ───────────────────────────────────────────────────
  const hubValue = { hub, criarCliente, abrirCliente, removerCliente, setClienteAtivo, hubCarregado };

  const clienteValue = {
    clienteAtivo, setClienteAtivo,
    modoLeitura, modoCliente, paginaAtual, setPaginaAtual,
    salvarClienteAtivo, voltarHub,
    salvando,  // true enquanto aguarda o debounce/save no Supabase
  };

  return (
    <HubContext.Provider value={hubValue}>
      <ClienteContext.Provider value={clienteValue}>
        {children}
      </ClienteContext.Provider>
    </HubContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(ClienteContext);
  if (!ctx) throw new Error('useApp deve ser usado dentro de AppProvider');
  return ctx;
}

export function useHub() {
  const ctx = useContext(HubContext);
  if (!ctx) throw new Error('useHub deve ser usado dentro de AppProvider');
  return ctx;
}
