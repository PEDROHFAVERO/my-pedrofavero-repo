// Design System Tokens — configuração via env (white-label)
import { BRAND_COLOR, BRAND_COLOR_DARK, BRAND_COLOR_LIGHT } from '../lib/appConfig.js';

export const C = {
  // Backgrounds
  bg: '#0B0F1A',
  bgMid: '#0F1420',
  card: '#131929',
  cardHover: '#1A2235',
  border: '#1E2D45',
  borderLight: '#243352',

  // Text
  text: '#E8EDF5',
  textMuted: '#7A90B0',
  textDim: '#4A6080',

  // Brand — lidos do appConfig (env VITE_BRAND_COLOR)
  brand: BRAND_COLOR,
  brandDark: BRAND_COLOR_DARK,
  brandLight: BRAND_COLOR_LIGHT,

  // Semânticas
  rec: '#22D3A0',      // receita / positivo
  recBg: '#0D2E25',
  desp: '#F87171',     // despesa / negativo
  despBg: '#2E1515',
  warn: '#FBBF24',     // atenção / amarelo
  warnBg: '#2E2510',
  info: '#60A5FA',     // informação / azul
  infoBg: '#0F1E35',

  // Semáforo
  green: '#22C55E',
  greenBg: '#0A2E1A',
  yellow: '#EAB308',
  yellowBg: '#2A2000',
  red: '#EF4444',
  redBg: '#2E0A0A',

  // Grupos macro
  grupoReceitas: '#22D3A0',
  grupoFixas: '#F87171',
  grupoConsumo: '#FBBF24',
  grupoDividas: '#C084FC',
  grupoInvestimentos: '#60A5FA',

  // Misc
  white: '#FFFFFF',
  black: '#000000',
  overlay: 'rgba(0,0,0,0.6)',
};

export const RADIUS = {
  sm: '6px',
  md: '10px',
  lg: '14px',
  xl: '18px',
  full: '9999px',
};

export const SHADOW = {
  card: '0 2px 12px rgba(0,0,0,0.4)',
  modal: '0 8px 40px rgba(0,0,0,0.7)',
  glow: '0 0 20px rgba(0,184,169,0.15)',
};

export const FONT = {
  family: "'Inter', system-ui, -apple-system, sans-serif",
  xs: '10px',
  sm: '12px',
  md: '13px',
  base: '14px',
  lg: '16px',
  xl: '20px',
  xxl: '24px',
  h1: '28px',
};
