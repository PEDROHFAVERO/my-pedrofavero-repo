import { useApp, useHub } from './context/AppContext.jsx';
import { AppProvider } from './context/AppContext.jsx';
import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import { C, FONT, RADIUS } from './design/tokens.js';
import { APP_NAME, LOGO_URL } from './lib/appConfig.js';
import { lazy, Suspense, useState } from 'react';

// lazy: cada página só é carregada quando acessada pela 1ª vez
const PageHub            = lazy(() => import('./pages/PageHub.jsx'));
const PageDashboard      = lazy(() => import('./pages/PageDashboard.jsx'));
const PagePlanejador     = lazy(() => import('./pages/PagePlanejador.jsx'));
const PageCategorizador  = lazy(() => import('./pages/PageCategorizador.jsx'));
const PageBotWhatsapp    = lazy(() => import('./pages/PageBotWhatsapp.jsx'));
const PageLogin          = lazy(() => import('./pages/PageLogin.jsx'));
const PageManagerHub     = lazy(() => import('./pages/PageManagerHub.jsx'));

// ── NavBar (visível quando há um cliente aberto) ──────────────────────────────
function NavBar({ modoCliente }) {
  const { clienteAtivo, paginaAtual, setPaginaAtual, voltarHub, modoLeitura } = useApp();
  const { sessao, logout } = useAuth();

  // Detecta se Manager está visualizando hub de planejador
  const managerViewing = (() => {
    try { return JSON.parse(localStorage.getItem('manager_viewing') || 'null'); } catch { return null; }
  })();

  if (!clienteAtivo) return null;

  // Modo cliente: só Dashboard e Fluxo Financeiro, sem aba Hub
  const abas = modoCliente
    ? [
        { id: 'dashboard',     label: '📊 Dashboard' },
        { id: 'categorizador', label: '💸 Fluxo Financeiro' },
      ]
    : [
        { id: 'hub',            label: '📁 Hub' },
        { id: 'dashboard',      label: '📊 Dashboard' },
        { id: 'planejador',     label: '🎯 Planejador' },
        ...(!modoLeitura ? [{ id: 'categorizador', label: '💸 Fluxo Financeiro' }] : []),
        ...(!modoLeitura ? [{ id: 'bot-whatsapp',  label: '📱 Bot WhatsApp' }]    : []),
      ];

  return (
    <div className="mb-navbar-outer" style={{ background: C.card, borderBottom: `1px solid ${C.border}`, padding: '0 32px', position: 'sticky', top: 0, zIndex: 50 }}>
      <div className="mb-navbar-inner" style={{ maxWidth: 1300, margin: '0 auto', display: 'flex', alignItems: 'center', height: 52 }}>
        {/* Logo */}
        <div className="mb-navbar-logo" style={{ display: 'flex', alignItems: 'center', gap: 10, marginRight: 28 }}>
          <img src={LOGO_URL} alt={APP_NAME} style={{ width: 32, height: 32, objectFit: 'contain' }} />
          <span style={{ fontSize: FONT.sm, fontWeight: 700, color: C.text }}>{APP_NAME}</span>
        </div>

        {/* Abas */}
        <div className="mb-navbar-tabs" style={{ display: 'flex', flex: 1, gap: 2 }}>
          {abas.map(a => (
            <button key={a.id}
              onClick={() => a.id === 'hub' ? voltarHub() : setPaginaAtual(a.id)}
              style={{
                padding: '0 16px', height: 52, border: 'none', background: 'transparent',
                color: (a.id !== 'hub' && paginaAtual === a.id) ? C.brand : C.textMuted,
                fontWeight: (a.id !== 'hub' && paginaAtual === a.id) ? 700 : 500,
                fontSize: FONT.sm, cursor: 'pointer', fontFamily: "'Inter',sans-serif",
                borderBottom: (a.id !== 'hub' && paginaAtual === a.id) ? `2px solid ${C.brand}` : '2px solid transparent',
              }}
            >{a.label}</button>
          ))}
        </div>

        {/* Ações */}
        <div className="mb-navbar-actions" style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {modoLeitura && !modoCliente && (
            <span style={{ fontSize: FONT.xs, color: C.yellow, background: C.yellowBg, padding: '3px 10px', borderRadius: RADIUS.full, fontWeight: 600 }}>
              👁 Modo Leitura
            </span>
          )}

          {/* Nome do cliente no modo cliente */}
          {modoCliente && (
            <span style={{ fontSize: FONT.xs, color: C.textMuted, maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {sessao?.perfil?.nome}
            </span>
          )}

          {!modoCliente && !modoLeitura && (
            <span style={{ fontSize: FONT.xs, color: C.textMuted, maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {clienteAtivo.nome}
            </span>
          )}

          {/* Botão voltar ao painel Manager */}
          {managerViewing && (
            <button
              onClick={() => { localStorage.removeItem('manager_viewing'); window.location.reload(); }}
              style={{
                fontSize: FONT.xs, color: C.brand, background: C.brand + '15',
                border: `1px solid ${C.brand}44`, borderRadius: RADIUS.sm,
                padding: '4px 12px', cursor: 'pointer', fontFamily: "'Inter',sans-serif", fontWeight: 600,
              }}
            >← Painel Manager</button>
          )}

          {/* Sair */}
          {!managerViewing && (
            <button
              onClick={logout}
              style={{ fontSize: FONT.xs, color: C.textMuted, background: 'transparent', border: `1px solid ${C.border}`, borderRadius: RADIUS.sm, padding: '4px 12px', cursor: 'pointer', fontFamily: "'Inter',sans-serif" }}
            >Sair</button>
          )}
        </div>
      </div>

      {/* Barra de contexto quando Manager está visualizando planejador */}
      {managerViewing && (
        <div className="mb-manager-bar" style={{ background: C.brand + '12', borderTop: `1px solid ${C.brand}30`, padding: '5px 0', textAlign: 'center' }}>
          <span style={{ fontSize: FONT.xs, color: C.brand }}>
            👀 Visualizando hub de <strong>{managerViewing.nome}</strong> ({managerViewing.email})
          </span>
        </div>
      )}
    </div>
  );
}

// ── Spinner ───────────────────────────────────────────────────────────────────
function PageSpinner() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', color: C.textMuted, fontSize: FONT.sm, background: C.bg, fontFamily: "'Inter',sans-serif" }}>
      Carregando...
    </div>
  );
}

// ── Router para planejador/manager ───────────────────────────────────────────
function Router() {
  const { paginaAtual, clienteAtivo } = useApp();
  const { hubCarregado } = useHub();

  const [visitadas, setVisitadas] = useState(() => new Set([paginaAtual]));

  if (!visitadas.has(paginaAtual)) {
    setVisitadas(prev => new Set([...prev, paginaAtual]));
  }

  // Aguarda carregamento do Supabase antes de exibir o Hub,
  // evitando que o reload mostre o Hub quando o usuário tinha um cliente aberto
  if (!hubCarregado) return <PageSpinner />;

  if (!clienteAtivo) {
    return (
      <Suspense fallback={<PageSpinner />}>
        <HubWrapper />
      </Suspense>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: C.bg, fontFamily: "'Inter', system-ui, sans-serif", color: C.text }}>
      <NavBar modoCliente={false} />
      <Suspense fallback={<PageSpinner />}>
        {visitadas.has('hub')            && <div style={{ display: paginaAtual === 'hub'            ? 'block' : 'none' }}><PageHub /></div>}
        {visitadas.has('dashboard')      && <div style={{ display: paginaAtual === 'dashboard'      ? 'block' : 'none' }}><PageDashboard /></div>}
        {visitadas.has('planejador')     && <div style={{ display: paginaAtual === 'planejador'     ? 'block' : 'none' }}><PagePlanejador /></div>}
        {visitadas.has('categorizador')  && <div style={{ display: paginaAtual === 'categorizador'  ? 'block' : 'none' }}><PageCategorizador /></div>}
        {visitadas.has('bot-whatsapp')   && <div style={{ display: paginaAtual === 'bot-whatsapp'   ? 'block' : 'none' }}><PageBotWhatsapp /></div>}
      </Suspense>
    </div>
  );
}

// ── Router para cliente (somente leitura) ────────────────────────────────────
function RouterCliente() {
  const { paginaAtual, clienteAtivo } = useApp();
  const { hubCarregado } = useHub();
  const { logout } = useAuth();

  const [visitadas, setVisitadas] = useState(() => new Set(['dashboard']));

  if (!visitadas.has(paginaAtual)) {
    setVisitadas(prev => new Set([...prev, paginaAtual]));
  }

  // Enquanto carrega
  if (!hubCarregado) return <PageSpinner />;

  // Carregou mas cliente não encontrado (RLS bloqueou ou dados inconsistentes)
  if (!clienteAtivo) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh', gap: 16, fontFamily: "'Inter',sans-serif", color: '#94a3b8', background: C.bg }}>
        <span style={{ fontSize: 14 }}>Não foi possível carregar seus dados.</span>
        <span style={{ fontSize: 12, color: '#64748b' }}>Tente novamente ou contacte seu planejador.</span>
        <button onClick={logout} style={{ marginTop: 8, padding: '8px 20px', background: 'transparent', border: `1px solid ${C.border}`, borderRadius: 6, color: '#94a3b8', cursor: 'pointer', fontSize: 13 }}>Sair</button>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: C.bg, fontFamily: "'Inter', system-ui, sans-serif", color: C.text }}>
      <NavBar modoCliente={true} />
      <Suspense fallback={<PageSpinner />}>
        {visitadas.has('dashboard')     && <div style={{ display: paginaAtual === 'dashboard'     ? 'block' : 'none' }}><PageDashboard /></div>}
        {visitadas.has('categorizador') && <div style={{ display: paginaAtual === 'categorizador' ? 'block' : 'none' }}><PageCategorizador /></div>}
      </Suspense>
    </div>
  );
}

// Wrapper para mostrar o Hub com botão de logout quando não há cliente aberto
function HubWrapper() {
  const { logout } = useAuth();
  const managerViewing = (() => {
    try { return JSON.parse(localStorage.getItem('manager_viewing') || 'null'); } catch { return null; }
  })();

  return (
    <div style={{ minHeight: '100vh', background: C.bg, fontFamily: "'Inter', system-ui, sans-serif", color: C.text }}>
      {/* Mini header no hub sem cliente ativo */}
      <div style={{ background: C.card, borderBottom: `1px solid ${C.border}`, padding: '0 32px' }}>
        <div style={{ maxWidth: 1300, margin: '0 auto', display: 'flex', alignItems: 'center', height: 52, gap: 12 }}>
          <img src={LOGO_URL} alt={APP_NAME} style={{ width: 28, height: 28, objectFit: 'contain' }} />
          <span style={{ fontSize: FONT.sm, fontWeight: 700, color: C.text }}>{APP_NAME}</span>
          <div style={{ flex: 1 }} />
          {managerViewing && (
            <>
              <span style={{ fontSize: FONT.xs, color: C.brand }}>
                👀 Hub de <strong>{managerViewing.nome}</strong>
              </span>
              <button
                onClick={() => { localStorage.removeItem('manager_viewing'); window.location.reload(); }}
                style={{ fontSize: FONT.xs, color: C.brand, background: C.brand + '15', border: `1px solid ${C.brand}44`, borderRadius: RADIUS.sm, padding: '4px 12px', cursor: 'pointer', fontFamily: "'Inter',sans-serif", fontWeight: 600 }}
              >← Painel Manager</button>
            </>
          )}
          {!managerViewing && (
            <button onClick={logout} style={{ fontSize: FONT.xs, color: C.textMuted, background: 'transparent', border: `1px solid ${C.border}`, borderRadius: RADIUS.sm, padding: '4px 12px', cursor: 'pointer', fontFamily: "'Inter',sans-serif" }}>
              Sair
            </button>
          )}
        </div>
      </div>
      <PageHub />
    </div>
  );
}

// ── Raiz da aplicação ─────────────────────────────────────────────────────────
function AppRoot() {
  const { sessao, carregando, isManager, isCliente } = useAuth();

  if (carregando) return <PageSpinner />;

  // Não logado → tela de login
  if (!sessao) {
    return (
      <Suspense fallback={<PageSpinner />}>
        <PageLogin />
      </Suspense>
    );
  }

  // Manager sem visualizar planejador → painel de gestão
  const managerViewing = (() => {
    try { return localStorage.getItem('manager_viewing'); } catch { return null; }
  })();

  if (isManager && !managerViewing) {
    return (
      <Suspense fallback={<PageSpinner />}>
        <PageManagerHub />
      </Suspense>
    );
  }

  // Cliente → AppProvider com clienteId fixo, modoLeitura=true, página inicial dashboard
  if (isCliente) {
    return (
      <AppProvider userId={sessao.user.id} clienteIdFixo={sessao.clienteId} modoClienteFixo={true}>
        <RouterCliente />
      </AppProvider>
    );
  }

  // Planejador ou Manager visualizando hub → fluxo normal
  return (
    <AppProvider userId={sessao.user.id}>
      <Router />
    </AppProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppRoot />
    </AuthProvider>
  );
}
