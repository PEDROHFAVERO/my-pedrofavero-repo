import { CATEGORIAS_PADRAO, REGRAS_PADRAO } from '../data/categorias.js';

// IDs de categorias antigas que foram removidas do padrão e NÃO devem ser preservadas
const IDS_LEGADOS_REMOVIDOS = new Set([
  'transferencia', 'saque', 'recarga', 'de_outras',
]);

// ── Sincroniza categorias do cliente com o padrão atual ───────────────────────
// Garante que categorias padrão removidas/alteradas sejam atualizadas,
// preservando categorias customizadas (não presentes no padrão e não legadas).
export function sincronizarCategorias(categoriasCliente = []) {
  const idspadrao = new Set(CATEGORIAS_PADRAO.map(c => c.id));
  // Mantém apenas categorias realmente customizadas pelo usuário:
  // - não estão no padrão atual
  // - não são IDs legados que foram removidos
  const customizadas = categoriasCliente.filter(
    c => !idspadrao.has(c.id) && !IDS_LEGADOS_REMOVIDOS.has(c.id)
  );
  // Retorna padrão atualizado + customizadas
  return [...JSON.parse(JSON.stringify(CATEGORIAS_PADRAO)), ...customizadas];
}

// ── Estado inicial de um cliente ──────────────────────────────────────────────
export function criarClienteVazio(nome = 'Novo Cliente') {
  return {
    id: gerarId(),
    nome,
    criadoEm: new Date().toISOString(),
    atualizadoEm: new Date().toISOString(),
    categorias: JSON.parse(JSON.stringify(CATEGORIAS_PADRAO)),
    regras: JSON.parse(JSON.stringify(REGRAS_PADRAO)),
    contas: [],          // { id, nome, banco, tipo }
    transacoes: [],      // array de transações categorizadas
    planejamento: {},    // { 2026: { jan: { catId: { projetado, parcelas } } } }
    anoAtivo: new Date().getFullYear(),
  };
}

// ── Persistência no Hub (localStorage) ───────────────────────────────────────
const HUB_KEY = 'b2if_pf_hub';

export function carregarHub() {
  try {
    const raw = localStorage.getItem(HUB_KEY);
    if (!raw) return { clientes: [] };
    return JSON.parse(raw);
  } catch {
    return { clientes: [] };
  }
}

export function salvarHub(hub) {
  localStorage.setItem(HUB_KEY, JSON.stringify(hub));
}

export function adicionarClienteHub(hub, cliente) {
  return { ...hub, clientes: [...hub.clientes, cliente] };
}

export function removerClienteHub(hub, clienteId) {
  return { ...hub, clientes: hub.clientes.filter(c => c.id !== clienteId) };
}

export function atualizarClienteHub(hub, cliente) {
  return {
    ...hub,
    clientes: hub.clientes.map(c =>
      c.id === cliente.id ? { ...cliente, atualizadoEm: new Date().toISOString() } : c
    ),
  };
}

// ── Export / Import de cliente (arquivo JSON) ─────────────────────────────────
export function exportarCliente(cliente) {
  const blob = new Blob(
    [JSON.stringify(cliente, null, 2)],
    { type: 'application/json' }
  );
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `b2if_${slugify(cliente.nome)}_${hoje()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function importarClienteDeArquivo(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const dados = JSON.parse(e.target.result);
        // validação mínima
        if (!dados.id || !dados.nome || !dados.transacoes) {
          reject(new Error('Arquivo inválido: não parece um cliente B2IF PF'));
          return;
        }
        resolve(dados);
      } catch {
        reject(new Error('Erro ao ler arquivo JSON'));
      }
    };
    reader.readAsText(file);
  });
}

// ── Link de leitura ───────────────────────────────────────────────────────────
export function gerarLinkLeitura(cliente) {
  const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(cliente))));
  return `${window.location.origin}${window.location.pathname}?view=${encoded}`;
}

export function lerClienteDoLink() {
  try {
    const params = new URLSearchParams(window.location.search);
    const encoded = params.get('view');
    if (!encoded) return null;
    return JSON.parse(decodeURIComponent(escape(atob(encoded))));
  } catch {
    return null;
  }
}

// ── Utilitários ───────────────────────────────────────────────────────────────
export function gerarId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function slugify(str) {
  return str.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '');
}

function hoje() {
  return new Date().toISOString().slice(0, 10);
}
